^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package mola_state_estimation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.4.2 (2026-06-04)
------------------

2.4.1 (2026-06-02)
------------------

2.4.0 (2026-05-11)
------------------
* Merge pull request `#30 <https://github.com/MOLAorg/mola_state_estimation/issues/30>`_ from MOLAorg/bump-cmake-version
  bump min req cmake version to 3.22
* bump min req cmake version to 3.22
* Contributors: Jose Luis Blanco-Claraco

2.3.1 (2026-05-04)
------------------

2.3.0 (2026-04-29)
------------------

2.2.0 (2026-03-03)
------------------

2.1.0 (2026-02-14)
------------------

2.0.1 (2026-01-15)
------------------

2.0.0 (2026-01-14)
------------------
* Merge pull request `#5 <https://github.com/MOLAorg/mola_state_estimation/issues/5>`_ from MOLAorg/feature/fuse-gnss-imu-odom
  Refactor: new packages mola_georeferencing, mola_gtsam_factors, functional smoother state estimator
* Refactor to expose all gtsam factors into a new library 'mola_gtsam_factors'
* Contributors: Jose Luis Blanco-Claraco

* Merge pull request `#5 <https://github.com/MOLAorg/mola_state_estimation/issues/5>`_ from MOLAorg/feature/fuse-gnss-imu-odom
  Refactor: new packages mola_georeferencing, mola_gtsam_factors, functional smoother state estimator
* Refactor to expose all gtsam factors into a new library 'mola_gtsam_factors'
* Contributors: Jose Luis Blanco-Claraco

1.11.1 (2025-10-20)
-------------------

1.11.0 (2025-10-05)
-------------------
 * Remove mola_imu_preintegration to its own repository.

1.10.0 (2025-09-07)
-------------------

1.9.0 (2025-06-06)
------------------

1.8.1 (2025-05-25)
------------------
* package.xml: update license tag to BSD-3-Clause
* Contributors: Jose Luis Blanco-Claraco

1.8.0 (2025-03-15)
------------------

1.7.0 (2025-02-22)
------------------

1.6.1 (2025-01-10)
------------------
* Fix package.xml URLs
* Contributors: Jose Luis Blanco-Claraco

1.6.0 (2025-01-03)
------------------
* docs: link to main sphinx page
* add metapackage for easy installation of all packages
* Contributors: Jose Luis Blanco-Claraco

1.5.0 (2024-12-26)
------------------
* Move state estimation packages out of this repo to its own: https://github.com/MOLAorg/mola_state_estimation
* Contributors: Jose Luis Blanco-Claraco
