/*               _
 _ __ ___   ___ | | __ _
| '_ ` _ \ / _ \| |/ _` | Modular Optimization framework for
| | | | | | (_) | | (_| | Localization and mApping (MOLA)
|_| |_| |_|\___/|_|\__,_| https://github.com/MOLAorg/mola

 Copyright (C) 2018-2026 Jose Luis Blanco, University of Almeria,
                         and individual contributors.
 SPDX-License-Identifier: GPL-3.0
 See LICENSE for full license information.
*/

/**
 * @file   Rosbag2Dataset.h
 * @brief  RawDataSource for datasets in rosbag2 format
 * @author Jose Luis Blanco Claraco
 * @date   Dec 23, 2023
 */
#pragma once

#include <mola_kernel/interfaces/Dataset_UI.h>
#include <mola_kernel/interfaces/OfflineDatasetSource.h>
#include <mola_kernel/interfaces/RawDataSourceBase.h>
#include <mola_kernel/interfaces/TransformTreeSource.h>
#include <mrpt/obs/CSensoryFrame.h>
#include <mrpt/serialization/CArchive.h>

#include <list>

// forward decls to isolate build dependencies downstream:
namespace tf2
{
class BufferCore;
}
namespace rosbag2_cpp::readers
{
class SequentialReader;
}
namespace rosbag2_storage
{
class SerializedBagMessage;
}

namespace mola
{
/** RawDataSource for datasets in rosbag2 format.
 *
 *  It reads a rosbag2 file, and exposes it as a dataset
 *  with N entries, N being the number of messages in the bag.
 *  Reading them via the offline API (OfflineDatasetSource)
 *  returns empty shared_ptr observations for those messages
 *  that do not have a direct mapping to mrpt::obs classes.
 *  The dataset can be also played in an online (real-time, or with a custom
 *  time wrapping) fashion via the RawDataSourceBase API.
 *
 *  See example configuration files to see how to define what topics
 *  to publish, and how to optionally override the sensor poses in the local
 *  robot frame.
 *
 * \ingroup mola_input_rosbag2_grp */
class Rosbag2Dataset : public RawDataSourceBase,
                       public OfflineDatasetSource,
                       public Dataset_UI,
                       public TransformTreeSource
{
  DEFINE_MRPT_OBJECT(Rosbag2Dataset, mola)

 public:
  Rosbag2Dataset();

  // See docs in base class
  void spinOnce() override;

  // See docs in base class:
  size_t datasetSize() const override;

  mrpt::obs::CSensoryFrame::Ptr datasetGetObservations(size_t timestep) const override;

  // Virtual interface of Dataset_UI (see docs in derived class)
  size_t datasetUI_size() const override { return datasetSize(); }
  size_t datasetUI_lastQueriedTimestep() const override
  {
    auto lck = mrpt::lockHelper(dataset_ui_mtx_);
    return last_used_tim_index_;
  }
  double datasetUI_playback_speed() const override
  {
    auto lck = mrpt::lockHelper(dataset_ui_mtx_);
    return time_warp_scale_;
  }
  void datasetUI_playback_speed(double speed) override
  {
    auto lck         = mrpt::lockHelper(dataset_ui_mtx_);
    time_warp_scale_ = speed;
  }
  bool datasetUI_paused() const override
  {
    auto lck = mrpt::lockHelper(dataset_ui_mtx_);
    return paused_;
  }
  void datasetUI_paused(bool paused) override
  {
    auto lck = mrpt::lockHelper(dataset_ui_mtx_);
    paused_  = paused;
  }
  void datasetUI_teleport(size_t timestep) override
  {
    auto lck       = mrpt::lockHelper(dataset_ui_mtx_);
    teleport_here_ = timestep;
  }

  // Virtual interface of TransformTreeSource (see docs in base class)
  std::optional<TransformTree> transform_tree(
      const std::string&                            root,
      const std::optional<mrpt::Clock::time_point>& timestamp = std::nullopt) const override;

  std::string transform_tree_default_root() const override { return base_link_frame_id_; }

 protected:
  // See docs in base class
  void initialize_rds(const Yaml& cfg) override;

 private:
  bool initialized_ = false;

  /// Ordered list of bag paths (directories or .db3/.mcap files).
  /// Populated from a scalar or sequence `rosbag_filename` YAML entry.
  std::vector<std::string> rosbag_filenames_;

  /// Per-bag storage identifier ("sqlite3" or "mcap"), auto-detected or
  /// overridden by the YAML `rosbag_storage_id` key (applied to all bags).
  std::vector<std::string> rosbag_storage_ids_;

  /// User-supplied storage ID override ("" = auto-detect per bag).
  std::string rosbag_storage_id_override_;

  /// Index into rosbag_filenames_ of the bag the reader is currently on.
  size_t current_bag_idx_ = 0;

  /// Message count per bag; sum == bagMessageCount_.
  std::vector<size_t> per_bag_msg_counts_;

  std::string rosbag_serialization_ = "cdr";
  std::string base_link_frame_id_   = "base_link";

  /// Topic name in the bag containing `tf2_msgs/TFMessage`. Default: `/tf`.
  /// Change this if your bag uses namespaced tf topics (e.g. `/robot1/tf`).
  std::string tf_topic_ = "/tf";

  /// Topic name in the bag containing static `tf2_msgs/TFMessage`. Default: `/tf_static`.
  std::string tf_static_topic_ = "/tf_static";

  std::optional<mrpt::Clock::time_point> rosbag_begin_time_;
  size_t                                 read_ahead_length_ = 15;

  /// Optional limit on dataset replay duration, counted from the first
  /// published message [seconds]. 0 (default) means unlimited (play the
  /// whole bag). Useful for quick validation runs on long bags.
  double max_duration_sec_ = 0;

  std::optional<mrpt::Clock::time_point> last_play_wallclock_time_;
  double                                 last_dataset_time_ = 0;

  std::shared_ptr<rosbag2_cpp::readers::SequentialReader> reader_;
  size_t                                                  bagMessageCount_ = 0;

  /// Opens the bag at rosbag_filenames_[bag_idx], sets reader_ and
  /// current_bag_idx_. Called from initialize_rds() and doReadAhead().
  void openBag(size_t bag_idx);

  /// Returns the auto-detected or user-overridden storage identifier for
  /// the bag at the given path (used in openBag()).
  static std::string detectStorageId(const std::string& path, const std::string& user_override);

  using SF = mrpt::obs::CSensoryFrame;

  SF::Ptr to_mrpt(const rosbag2_storage::SerializedBagMessage& rosmsg);

  void doReadAhead(
      const std::optional<size_t>& requestedIndex = std::nullopt, bool skipBufferAhead = false);

  // timestep in this class is just the index of the message in the rosbag:
  struct DatasetEntry
  {
    SF::Ptr obs;

    /// empty if obs == nullptr
    std::optional<mrpt::Clock::time_point> timestamp;
  };

  /** At initialization
   *
   */
  mutable std::vector<std::optional<DatasetEntry>> read_ahead_;
  size_t                                           rosbag_next_idx_       = 0;
  size_t                                           rosbag_next_idx_write_ = 0;
  std::set<std::string>                            already_pub_sensor_labels_;
  mutable std::deque<size_t>                       unload_queue_;  //!< read_ahead_ indices

  // Methods and variables for the ROS->MRPT conversion
  // -------------------------------------------------------
  using Obs = std::vector<mrpt::obs::CObservation::Ptr>;

  using CallbackFunction = std::function<Obs(const rosbag2_storage::SerializedBagMessage&)>;

  std::map<std::string, std::vector<CallbackFunction>> lookup_;
  std::set<std::string>                                unhandledTopics_;

  std::shared_ptr<tf2::BufferCore> tfBuffer_;

  template <bool isStatic>
  Obs toTf(const rosbag2_storage::SerializedBagMessage& rosmsg);

  /// sensor_msgs/msg/CompressedImage -> CObservationImage. Handled locally
  /// (not via mrpt::ros2bridge::rosbag2ToImage()) since that helper only
  /// understands the raw, uncompressed sensor_msgs/msg/Image wire format.
  Obs toCompressedImage(
      std::string_view label, const rosbag2_storage::SerializedBagMessage& rosmsg,
      const std::optional<mrpt::poses::CPose3D>& fixedSensorPose);

#if MRPT_ROS2_BRIDGE_VERSION < 0x030400

  Obs toPointCloud2(
      std::string_view label, const rosbag2_storage::SerializedBagMessage& rosmsg,
      const std::optional<mrpt::poses::CPose3D>& fixedSensorPose);

  Obs toLidar2D(
      std::string_view msg, const rosbag2_storage::SerializedBagMessage& rosmsg,
      const std::optional<mrpt::poses::CPose3D>& fixedSensorPose);

  Obs toRotatingScan(
      std::string_view msg, const rosbag2_storage::SerializedBagMessage& rosmsg,
      const std::optional<mrpt::poses::CPose3D>& fixedSensorPose);

  Obs toIMU(
      std::string_view msg, const rosbag2_storage::SerializedBagMessage& rosmsg,
      const std::optional<mrpt::poses::CPose3D>& fixedSensorPose);

  Obs toGPS(
      std::string_view msg, const rosbag2_storage::SerializedBagMessage& rosmsg,
      const std::optional<mrpt::poses::CPose3D>& fixedSensorPose);

  Obs toOdometry(std::string_view msg, const rosbag2_storage::SerializedBagMessage& rosmsg);

  Obs toImage(
      std::string_view msg, const rosbag2_storage::SerializedBagMessage& rosmsg,
      const std::optional<mrpt::poses::CPose3D>& fixedSensorPose);

  bool findOutSensorPose(
      mrpt::poses::CPose3D& des, const std::string& target_frame, const std::string& source_frame,
      const std::optional<mrpt::poses::CPose3D>& fixedSensorPose, const std::string_view label);
#endif

  Obs catchExceptions(const std::function<Obs()>& f);

  void autoUnloadOldEntries() const;

  mutable timestep_t    last_used_tim_index_ = 0;
  bool                  paused_              = false;
  double                time_warp_scale_     = 1.0;
  std::optional<size_t> teleport_here_;
  mutable std::mutex    dataset_ui_mtx_;
};

}  // namespace mola
