/*               _
 _ __ ___   ___ | | __ _
| '_ ` _ \ / _ \| |/ _` | Modular Optimization framework for
| | | | | | (_) | | (_| | Localization and mApping (MOLA)
|_| |_| |_|\___/|_|\__,_| https://github.com/MOLAorg/mola

 Copyright (C) 2018-2026 Jose Luis Blanco, University of Almeria,
                         and individual contributors.
 SPDX-License-Identifier: GPL-3.0
 See LICENSE for full license information.
*/

/**
 * @file   BridgeROS2.h
 * @brief  Bridge between MOLA-ROS2
 * @author Jose Luis Blanco Claraco
 * @date   Sep 7, 2023
 */
#pragma once

// MOLA virtual interfaces:
#include <mola_kernel/Georeferencing.h>
#include <mola_kernel/interfaces/ExecutableBase.h>
#include <mola_kernel/interfaces/LocalizationSourceBase.h>
#include <mola_kernel/interfaces/MapServer.h>
#include <mola_kernel/interfaces/MapSourceBase.h>
#include <mola_kernel/interfaces/RawDataConsumer.h>
#include <mola_kernel/interfaces/RawDataSourceBase.h>
#include <mola_kernel/interfaces/Relocalization.h>
#include <mola_kernel/interfaces/TransformTreeSource.h>

// MRPT:
#include <mrpt/maps/COccupancyGridMap2D.h>
#include <mrpt/obs/CObservationGPS.h>
#include <mrpt/obs/CObservationIMU.h>
#include <mrpt/obs/CObservationImage.h>
#include <mrpt/obs/CObservationPointCloud.h>

// ROS & others
#include <atomic>
#include <nav_msgs/msg/odometry.hpp>
#include <optional>
#include <rclcpp/node.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <sensor_msgs/msg/imu.hpp>
#include <sensor_msgs/msg/laser_scan.hpp>
#include <sensor_msgs/msg/nav_sat_fix.hpp>
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <tf2_ros/buffer.hpp>
#include <tf2_ros/static_transform_broadcaster.hpp>
#include <tf2_ros/transform_broadcaster.hpp>
#include <tf2_ros/transform_listener.hpp>

#if defined(HAS_GPS_MSGS)
#include <gps_msgs/msg/gps_fix.hpp>
#endif

// MOLA <-> ROS services:
#include <mola_msgs/srv/map_load.hpp>
#include <mola_msgs/srv/map_save.hpp>
#include <mola_msgs/srv/mola_runtime_param_get.hpp>
#include <mola_msgs/srv/mola_runtime_param_set.hpp>
#include <mola_msgs/srv/relocalize_from_state_estimator.hpp>
#include <mola_msgs/srv/relocalize_near_pose.hpp>

namespace mola
{
/** A bridge to read sensor observations from ROS 2 topics and forwarding them
 * to other MOLA subsystems, and to publish MOLA topics, localization, and maps
 * to ROS 2.
 *
 * ## Bridge ROS2=>MOLA
 * The MOLA nodelet execution rate (Hz) determines the rate of publishing
 * odometry observations, if enabled.
 * All other subscribed sensors are forwarded to the MOLA system without delay
 * as they are received from ROS.
 *
 * ## Bridge MOLA=>ROS2
 *  - Publish datasets from any of the MOLA dataset input modules to ROS 2.
 *  - Expose the results of a MOLA SLAM/odometry system to the rest of a ROS 2
 *    system.
 *
 * Every few seconds, this module will peek the MOLA subsystem for modules of
 * these types, and subscribes to all their outputs:
 *  - mola::RawDataSourceBase: For all their sensor readings (as
 *    children classes of mrpt::obs::CObservation). See list of mappings below.
 *  - mola::LocalizationSourceBase: For SLAM/odometry method outputs.
 *  - mola::MapSourceBase: For SLAM/odometry metric maps. Point maps are
 *    published as sensor_msgs/PointCloud2
 *
 * The following mappings are currently implemented between MOLA=>ROS2:
 *  - mrpt::obs::CObservation2DRangeScan  ==> sensor_msgs/LaserScan
 *  - mrpt::obs::CObservationPointCloud   ==> sensor_msgs/PointCloud2
 *  - mrpt::obs::CObservationImage        ==> sensor_msgs/Image
 *  - mrpt::obs::CObservationRobotPose    ==> nav_msgs/Odometry with
 *    frame_id=the robot (default: `base_link`) and parent frame the global one
 *    (default:`map`, may make sense to change to `odom` depending on your
 *    application). It will be also published as a transform to `/tf`.
 *
 * For all sensors, the mrpt::obs::CObservation::sensorPose will be also
 * broadcasted to `/tf` with respect to the vehicle frame (default:
 * `base_link`).
 *
 * See example launch files in `mola_demos` and in `mola_lidar_odometry`.
 *
 * \ingroup mola_bridge_ros2_grp
 */
class BridgeROS2 : public RawDataSourceBase,
                   public mola::RawDataConsumer,
                   public mola::TransformTreeSource
{
  DEFINE_MRPT_OBJECT(BridgeROS2, mola)

 public:
  BridgeROS2();
  ~BridgeROS2() override;

  // Virtual interface of TransformTreeSource (see docs in base class)
  std::optional<TransformTree> transform_tree(
      const std::string&                            root,
      const std::optional<mrpt::Clock::time_point>& timestamp = std::nullopt) const override;

  std::string transform_tree_default_root() const override { return params_.base_link_frame; }

  // disabled copy & move ctors:
  BridgeROS2(const BridgeROS2&)            = delete;
  BridgeROS2(BridgeROS2&&)                 = delete;
  BridgeROS2& operator=(const BridgeROS2&) = delete;
  BridgeROS2& operator=(BridgeROS2&&)      = delete;

  // See docs in base class
  void spinOnce() override;

  // RawDataConsumer implementation:
  void onNewObservation(const CObservation::ConstPtr& o) override;

 protected:
  // See docs in base class
  void initialize_rds(const Yaml& cfg) override;

 private:
  std::thread rosNodeThread_;

  struct Params
  {
    /// tf frame name with respect to sensor poses are measured, and also used for publishing
    /// SLAM/localization results (read below).
    std::string base_link_frame = "base_link";

    /// If not empty, the node will broadcast a static /tf from base_footprint to
    /// base_link with the TF base_footprint_to_base_link_tf at start
    /// up.
    /// Normally: "base_footprint"
    std::string base_footprint_frame;  // Disabled by default

    /// YAML format: "[x y z yaw pitch roll]" (meters & degrees)
    mrpt::math::TPose3D base_footprint_to_base_link_tf = {0, 0, 0, 0, 0, 0};

    /// Used for:
    /// (a) importing odometry to MOLA if ``forward_ros_tf_as_mola_odometry_observations=true``
    /// (b) querying ``${odom_frame} => ${base_link_frame}`` when
    ///     ``publish_localization_following_rep105=true``.
    std::string odom_frame = "odom";

    /// tf frame used for:
    /// (a) See ``publish_tf_from_robot_pose_observations``
    /// (b) To follow REP105 (``publish_localization_following_rep105``), this must match
    ///     the frame used as reference in the LocalizationSource (e.g. mola_lidar_odometry)
    std::string reference_frame = "map";

    /// How to publish localization to /tf:
    /// - ``false``(direct mode): reference_frame ("map") -> base_link ("base_link")
    ///   Note that reference_frame in this case comes from the localization source module
    ///   (e.g. mola_lidar_odometry), it is not configured here.
    ///
    ///  - ``true`` (indirect mode), following ROS [REP
    ///  105](https://ros.org/reps/rep-0105.html):
    ///   ``map -> odom``  (such as "map -> odom -> base_link" = "map -> base_link")
    bool publish_localization_following_rep105 = true;

    /// If enabled, during spinOnce(), the tf ``${odom_frame} => ${base_link_frame}`` will
    /// be queried and forwarded as an `CObservationOdometry` reading to the MOLA subsystem:
    bool forward_ros_tf_as_mola_odometry_observations = false;

    /// If enabled, SLAM/Localization results will be published as nav_msgs/Odometry messages.
    bool publish_odometry_msgs_from_slam = true;

    // Which source will be forwarded (empty=any)
    std::string publish_odometry_msgs_from_slam_source;

    /// If enabled, SLAM/Localization results will be published as tf messages, for frames
    /// according to explained above for `publish_localization_following_rep105`.
    bool publish_tf_from_slam = true;

    // Which source will be forwarded (empty=any)
    std::string publish_tf_from_slam_source;

    /// If enabled, SLAM/Localization results in geo-referenced maps will be published as
    /// geographic_msgs/GeoPoseStamped messages.
    bool publish_geo_referenced_poses_from_slam = true;

    /// If enabled, robot pose observations (typically, ground truth from datasets), will be
    /// forwarded to ROS as /tf messages: ``${reference_frame} => ${base_link}``
    bool publish_tf_from_robot_pose_observations = true;

    std::string relocalize_from_topic = "/initialpose";  //!< Default in RViz

    /// If true, the original dataset timestamps will be used to publish.
    /// Otherwise, the wallclock time will be used.
    bool publish_in_sim_time = false;

    /// Future-dating offset [s] applied to the broadcast stamp of the
    /// REP-105 localization /tf (``map -> odom``). The stamp is set to
    /// ``rosNode->now() + transform_tolerance``, allowing downstream
    /// consumers to ``lookupTransform(map, base_link, now())`` without
    /// tf2 ``ExtrapolationException``s. Ignored in direct-publish mode
    /// (``map -> base_link``), where the TF is stamped at the scan
    /// acquisition time so consumers can correlate the pose with the
    /// sensor data that produced it (and ``publish_in_sim_time`` is
    /// honored).
    double transform_tolerance = 0.1;  // [s]

    /// Period [s] at which the latest computed REP-105 localization /tf
    /// (``map -> odom``) is re-broadcast on a wall timer, independent of
    /// localization update rate. This keeps the TF buffer always populated
    /// for downstream consumers even when the localizer runs slower than
    /// the consumer query rate. Set to ``0`` to disable the rebroadcast
    /// loop (the TF is then only published when a new localization update
    /// arrives). Only effective in REP-105 mode: in direct-publish mode
    /// (``map -> base_link``) the rebroadcast is skipped to avoid
    /// re-stamping a stale pose as "current" when the localizer stalls --
    /// in that mode there is no ``odom -> base_link`` edge carrying real
    /// motion, so the robot would silently appear frozen-but-fresh.
    double transform_publish_period = 0.05;  // [s]

    double period_publish_new_map     = 5.0;  // [s]
    double period_publish_static_tfs  = 1.0;  // [s]
    double period_publish_diagnostics = 1.0;  // [s]

    double period_check_new_mola_subs = 1.0;  // [s]

    int wait_for_tf_timeout_milliseconds = 100;

    std::string georef_map_reference_frame = "map";
    std::string georef_map_utm_frame       = "utm";
    std::string georef_map_enu_frame       = "enu";

    /// If true (default), subscribed nav_msgs/Odometry messages are converted to
    /// mrpt::obs::CObservationRobotPose (full SE(3) pose + 6x6 covariance), suitable for
    /// multi-source fusion in the state estimation smoother.
    /// If false, they are converted to mrpt::obs::CObservationOdometry (2D pose, no covariance),
    /// which is more appropriate for 2D SLAM/mapping pipelines.
    bool odometry_as_robot_pose_observation = true;
  };

  Params params_;

  // Yaml is NOT a reference on purpose.
  void ros_node_thread_main(Yaml cfg);

  // Declared before the members below that hold a reference to *rosNode_
  // (TransformListener/TransformBroadcaster take rclcpp::Node&, not a
  // shared_ptr, see ros_node_thread_main()), so rosNode_ outlives them.
  std::shared_ptr<rclcpp::Node> rosNode_;
  std::mutex                    rosNodeMtx_;

  // std::shared_ptr<tf2_ros::Buffer>            tf_buffer_;
  std::shared_ptr<tf2::BufferCore>            tf_buffer_;
  std::shared_ptr<tf2_ros::TransformListener> tf_listener_;

  std::shared_ptr<tf2_ros::TransformBroadcaster>       tf_bc_;
  std::shared_ptr<tf2_ros::StaticTransformBroadcaster> tf_static_bc_;
  std::mutex                                           ros_tf_bc_mtx_;

  rclcpp::Clock::SharedPtr ros_clock_;
  std::mutex               ros_clock_mtx_;

  std::atomic<bool> shouldExit_{false};
  std::atomic<bool> isSpinning_{false};
  std::atomic<bool> owned_rclcpp_{false};  ///< true iff this instance called rclcpp::init()

  /// Returns a copy of the shared_ptr to the ROS 2 node, or empty if not
  /// initialized yet.
  std::shared_ptr<rclcpp::Node> rosNode()
  {
    auto lck = mrpt::lockHelper(rosNodeMtx_);
    return rosNode_;
  }
  std::vector<rclcpp::Subscription<sensor_msgs::msg::PointCloud2>::SharedPtr> subsPointCloud_;
  std::vector<rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr>   subsLaserScan_;
  std::vector<rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr>       subsOdometry_;
  std::vector<rclcpp::Subscription<sensor_msgs::msg::Imu>::SharedPtr>         subsImu_;
  std::vector<rclcpp::Subscription<sensor_msgs::msg::NavSatFix>::SharedPtr>   subsGNSS_;
#if defined(HAS_GPS_MSGS)
  std::vector<rclcpp::Subscription<gps_msgs::msg::GPSFix>::SharedPtr> subsGPSMsg_;
#endif
  rclcpp::Subscription<geometry_msgs::msg::PoseWithCovarianceStamped>::SharedPtr subInitPose_;

  void callbackOnPointCloud2(
      const sensor_msgs::msg::PointCloud2& o, const std::string& outSensorLabel,
      const std::optional<mrpt::poses::CPose3D>& fixedSensorPose);

  void callbackOnLaserScan(
      const sensor_msgs::msg::LaserScan& o, const std::string& outSensorLabel,
      const std::optional<mrpt::poses::CPose3D>& fixedSensorPose);

  void callbackOnImu(
      const sensor_msgs::msg::Imu& o, const std::string& outSensorLabel,
      const std::optional<mrpt::poses::CPose3D>& fixedSensorPose);

  void callbackOnNavSatFix(
      const sensor_msgs::msg::NavSatFix& o, const std::string& outSensorLabel,
      const std::optional<mrpt::poses::CPose3D>& fixedSensorPose);

#if defined(HAS_GPS_MSGS)
  void callbackOnGpsMsg(
      const gps_msgs::msg::GPSFix& o, const std::string& outSensorLabel,
      const std::optional<mrpt::poses::CPose3D>& fixedSensorPose);
#endif

  void callbackOnOdometry(const nav_msgs::msg::Odometry& o, const std::string& outSensorLabel);

  void callbackOnRelocalizeTopic(const geometry_msgs::msg::PoseWithCovarianceStamped& o);

  /// Converts an incoming relocalization pose into the localization
  /// reference_frame, composing reference_frame <- header.frame_id via /tf when
  /// they differ. Returns false (and leaves \a out unspecified) if the required
  /// transform is not available.
  bool relocalizationPoseInReferenceFrame(
      const geometry_msgs::msg::PoseWithCovarianceStamped& o, mrpt::poses::CPose3DPDFGaussian& out);

  bool waitForTransform(
      mrpt::poses::CPose3D& des, const std::string& frame, const std::string& referenceFrame);

  void importRosOdometryToMOLA();

  /// Returns either the wallclock "now" (params_.use_sim_time = false)
  /// or the equivalent of the passed argument in ROS 2 format otherwise.
  rclcpp::Time myNow(const mrpt::Clock::time_point& observationStamp) const;

  /// Generic Map <topic> => publisher
  std::map<std::string, rclcpp::PublisherBase::SharedPtr> rosPubs_;
  std::recursive_mutex                                    rosPubsMtx_;

  /// Gets or creates (upon first use) a publisher for a given type:
  template <typename MSG_TYPE>
  [[nodiscard]] auto get_publisher(const std::string& topic, const rclcpp::QoS& qos)
      -> std::shared_ptr<rclcpp::Publisher<MSG_TYPE>>
  {
    auto lck = mrpt::lockHelper(rosPubsMtx_);

    // Create the publisher the first time an observation arrives:
    const bool is_1st_pub = rosPubs_.find(topic) == rosPubs_.end();
    auto&      pub        = rosPubs_[topic];

    if (is_1st_pub)
    {
      pub = rosNode()->create_publisher<MSG_TYPE>(topic, qos);
    }
    lck.unlock();

    auto ret = std::dynamic_pointer_cast<rclcpp::Publisher<MSG_TYPE>>(pub);
    ASSERT_(ret);
    return ret;
  }

  struct MolaSubs
  {
    // MOLA subscribers:
    std::set<mola::RawDataSourceBase::Ptr>                  dataSources;
    std::set<std::shared_ptr<mola::LocalizationSourceBase>> locSources;
    std::set<std::shared_ptr<mola::MapSourceBase>>          mapSources;
    std::set<std::shared_ptr<mola::Relocalization>>         relocalization;
    std::set<std::shared_ptr<mola::MapServer>>              mapServers;
  };

  MolaSubs   molaSubs_;
  std::mutex molaSubsMtx_;

  // ROS services:
  rclcpp::Service<mola_msgs::srv::RelocalizeFromStateEstimator>::SharedPtr srvRelocSE_;
  rclcpp::Service<mola_msgs::srv::RelocalizeNearPose>::SharedPtr           srvRelocPose_;
  rclcpp::Service<mola_msgs::srv::MapLoad>::SharedPtr                      srvMapLoad_;
  rclcpp::Service<mola_msgs::srv::MapSave>::SharedPtr                      srvMapSave_;
  rclcpp::Service<mola_msgs::srv::MolaRuntimeParamGet>::SharedPtr          srvParamGet_;
  rclcpp::Service<mola_msgs::srv::MolaRuntimeParamSet>::SharedPtr          srvParamSet_;

  void service_relocalize_from_se(
      std::shared_ptr<mola_msgs::srv::RelocalizeFromStateEstimator::Request>  request,
      std::shared_ptr<mola_msgs::srv::RelocalizeFromStateEstimator::Response> response);

  void service_relocalize_near_pose(
      std::shared_ptr<mola_msgs::srv::RelocalizeNearPose::Request>  request,
      std::shared_ptr<mola_msgs::srv::RelocalizeNearPose::Response> response);

  void service_map_load(
      std::shared_ptr<mola_msgs::srv::MapLoad::Request>  request,
      std::shared_ptr<mola_msgs::srv::MapLoad::Response> response);

  void service_map_save(
      std::shared_ptr<mola_msgs::srv::MapSave::Request>  request,
      std::shared_ptr<mola_msgs::srv::MapSave::Response> response);

  void service_param_get(
      std::shared_ptr<mola_msgs::srv::MolaRuntimeParamGet::Request>  request,
      std::shared_ptr<mola_msgs::srv::MolaRuntimeParamGet::Response> response);

  void service_param_set(
      std::shared_ptr<mola_msgs::srv::MolaRuntimeParamSet::Request>  request,
      std::shared_ptr<mola_msgs::srv::MolaRuntimeParamSet::Response> response);

  void onNewLocalization(const mola::LocalizationSourceBase::LocalizationUpdate& l);

  void publishSingleLocalization(const mola::LocalizationSourceBase::LocalizationUpdate& l);

  void onNewMap(const mola::MapSourceBase::MapUpdate& m);

  std::mutex                                                              lastMapMtx_;
  std::multimap<std::string /*map_name*/, mola::MapSourceBase::MapUpdate> lastMaps_;

  // The latest georef info received from any state estimator / SLAM method.
  std::mutex                    georefInfoMtx_;
  std::optional<Georeferencing> georeferencingInfo_;

  std::optional<Georeferencing> georeferencingInfo()
  {
    std::lock_guard<std::mutex> lck(georefInfoMtx_);
    return this->georeferencingInfo_;
  }

  // Different publish localization parts:
  void publishLocalizationTf(const LocalizationSourceBase::LocalizationUpdate& l);
  void publishLocalizationOdom(const LocalizationSourceBase::LocalizationUpdate& l);
  void publishLocalizationQuality(const LocalizationSourceBase::LocalizationUpdate& l);
  void publishLocalizationGeoRef(const LocalizationSourceBase::LocalizationUpdate& l);

  /// Latest computed localization /tf (frame_ids + transform) plus the
  /// metadata needed to re-stamp it correctly on each broadcast.
  /// ``useRep105`` selects the stamping policy: REP-105 mode uses
  /// ``rosNode->now() + transform_tolerance`` (Nav2-style, future-dated,
  /// safe to rebroadcast because ``odom -> base_link`` carries real
  /// motion); direct mode uses ``myNow(scan_timestamp)`` (stamped at scan
  /// time, honoring ``publish_in_sim_time``). Empty until the first
  /// localization update arrives.
  struct CachedLocalizationTf
  {
    geometry_msgs::msg::TransformStamped tf;
    bool                                 useRep105 = false;
    mrpt::Clock::time_point              scan_timestamp;
  };
  std::mutex                          cachedLocalizationTfMtx_;
  std::optional<CachedLocalizationTf> cachedLocalizationTf_;

  /// Re-broadcasts the cached localization /tf with a freshly-computed
  /// stamp (see ``CachedLocalizationTf`` for the stamping policy). Called
  /// immediately on each new localization update, and from the rebroadcast
  /// wall timer when the cached entry is in REP-105 mode. No-op until the
  /// cache is populated. When ``onlyIfRep105`` is true (used from the
  /// periodic timer), non-REP-105 cached entries are skipped to avoid
  /// re-stamping a stale ``map -> base_link`` as "current" while the
  /// localizer is stalled.
  void broadcastCachedLocalizationTf(bool onlyIfRep105 = false);

  // Different publish map parts:
  void timerPubMap();
  void timerPubMapLayer(const std::string& layerName, const MapSourceBase::MapUpdate& mu);

  double lastTimeCheckMolaSubs_ = 0;
  void   doLookForNewMolaSubs();

  void internalOn(const mrpt::obs::CObservationImage& obs);
  void internalOn(const mrpt::obs::CObservation2DRangeScan& obs);
  void internalOn(const mrpt::obs::CObservationPointCloud& obs);
  void internalOn(const mrpt::obs::CObservationRobotPose& obs);
  void internalOn(const mrpt::obs::CObservationGPS& obs);
  void internalOn(const mrpt::obs::CObservationIMU& obs);

  void internalOn(
      const mrpt::obs::CObservationPointCloud& obs, bool isSensorTopic,
      const std::string& sSensorFrameId);

  void internalPublishGridMap(
      const mrpt::maps::COccupancyGridMap2D& m, const std::string& sMapTopicName,
      const std::string& sReferenceFrame, const mrpt::Clock::time_point& timestamp);

  void internalAnalyzeTopicsToSubscribe(const mrpt::containers::yaml& ds_subscribe);

  void publishStaticTFs();
  void publishDiagnostics();
  void publishMetricMapGeoreferencingData(
      const mola::Georeferencing& g, const std::string& georefTopic);
};

}  // namespace mola
