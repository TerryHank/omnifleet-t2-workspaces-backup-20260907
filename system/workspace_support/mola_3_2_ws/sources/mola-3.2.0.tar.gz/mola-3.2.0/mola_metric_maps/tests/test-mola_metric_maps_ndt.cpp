/*               _
 _ __ ___   ___ | | __ _
| '_ ` _ \ / _ \| |/ _` | Modular Optimization framework for
| | | | | | (_) | | (_| | Localization and mApping (MOLA)
|_| |_| |_|\___/|_|\__,_| https://github.com/MOLAorg/mola

 Copyright (C) 2018-2026 Jose Luis Blanco, University of Almeria,
                         and individual contributors.
 SPDX-License-Identifier: GPL-3.0
 See LICENSE for full license information.
*/

/**
 * @file   test-mola_metric_maps_ndt.cpp
 * @brief  Test the 3D NDT map class
 * @author Jose Luis Blanco Claraco
 * @date   Aug 22, 2024
 */

#include <mola_metric_maps/NDT.h>
#include <mrpt/core/get_env.h>
#include <mrpt/obs/CObservation2DRangeScan.h>
#include <mrpt/obs/stock_observations.h>
#include <mrpt/opengl/Scene.h>

#include <iostream>

namespace
{
void test_voxelmap_basic_ops()
{
  mola::NDT map;
  ASSERT_(map.isEmpty());

  map.insertPoint({1.0f, 2.0f, 3.0f}, {.0f, .0f, .0f});
  ASSERT_(!map.isEmpty());
}

void test_voxelmap_insert_2d_scan()
{
  mola::NDT map(0.2 /*voxel size*/);

  mrpt::obs::CObservation2DRangeScan scan2D;
  mrpt::obs::stock_observations::example2DRangeScan(scan2D);

  map.insertObservation(scan2D);

  if (mrpt::get_env<bool>("TEST_GENERATE_3D_SCENES"))
  {
    mrpt::opengl::Scene scene;
    map.renderOptions.point_size = 5.0f;
    scene.insert(map.getVisualization());
    scene.saveToFile("sparsevoxelmap_scan2d.3Dscene");
  }

  {
    size_t nPts = 0;

    const auto lambdaVisitPoints = [&nPts](const mrpt::math::TPoint3Df&) { nPts++; };

    map.visitAllPoints(lambdaVisitPoints);

    ASSERT_EQUAL_(nPts, 267UL);
  }

  // test NN search:
  mrpt::maps::CSimplePointsMap refPts;
  map.visitAllPoints([&](const mrpt::math::TPoint3Df& pt) { refPts.insertPoint(pt); });

  mrpt::maps::CSimplePointsMap queryPts;
  queryPts.insertObservation(
      scan2D, mrpt::poses::CPose3D::FromXYZYawPitchRoll(-0.05, -0.01, -0.01, 0, 0, 0));

// TODO: Update for new NN API!
#if 0
    for (size_t knn = 2; knn < 3; knn++)
    {
        for (size_t i = 0; i < queryPts.size(); i++)
        {
            mrpt::math::TPoint3D query;
            queryPts.getPoint(i, query);

            std::vector<mrpt::math::TPoint3Df> results;
            std::vector<float>                 dists_sqr;
            std::vector<uint64_t>              IDs;
            map.nn_multiple_search(query, knn, results, dists_sqr, IDs);

            std::vector<mrpt::math::TPoint3Df> gt_results;
            std::vector<float>                 gt_dists_sqr;
            std::vector<uint64_t>              gt_IDs;
            refPts.nn_multiple_search(
                query, knn, gt_results, gt_dists_sqr, gt_IDs);

#if 0
            for (size_t k = 0; k < results.size(); k++)
            {
                std::cout << "k: " << k << "/" << knn << " query: " << query
                          << " nn: " << results.at(k) << " ("
                          << std::sqrt(dists_sqr.at(k)) << ") "
                          << " gt: " << gt_results.at(k) << " ("
                          << std::sqrt(gt_dists_sqr.at(k)) << ")" << "\n";
            }
#endif
            for (size_t k = 0; k < results.size(); k++)
            {
                ASSERT_NEAR_(results[k].x, gt_results[k].x, 1e-3f);
                ASSERT_NEAR_(results[k].y, gt_results[k].y, 1e-3f);
                ASSERT_NEAR_(results[k].z, gt_results[k].z, 1e-3f);

                ASSERT_NEAR_(dists_sqr[k], gt_dists_sqr[k], 1e-3f);
            }
        }
    }
#endif
}
}  // namespace

int main([[maybe_unused]] int argc, [[maybe_unused]] char** argv)
{
  try
  {
    test_voxelmap_basic_ops();
    test_voxelmap_insert_2d_scan();
  }
  catch (std::exception& e)
  {
    std::cerr << e.what() << "\n";
    return 1;
  }
}
