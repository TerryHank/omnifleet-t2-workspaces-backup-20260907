/*               _
 _ __ ___   ___ | | __ _
| '_ ` _ \ / _ \| |/ _` | Modular Optimization framework for
| | | | | | (_) | | (_| | Localization and mApping (MOLA)
|_| |_| |_|\___/|_|\__,_| https://github.com/MOLAorg/mola

 A repertory of multi primitive-to-primitive (MP2P) ICP algorithms
 and map building tools. mp2p_icp is part of MOLA.

 Copyright (C) 2018-2026 Jose Luis Blanco, University of Almeria,
                         and individual contributors.
 SPDX-License-Identifier: BSD-3-Clause
*/

/**
 * @file   mm-info/main.cpp
 * @brief  CLI tool to read a map and describe it
 * @author Jose Luis Blanco Claraco
 * @date   Feb 13, 2024
 */

#include <mp2p_icp/metricmap.h>
#include <mrpt/containers/yaml.h>
#include <mrpt/core/Clock.h>
#include <mrpt/system/filesystem.h>
#include <mrpt/system/os.h>

#include <CLI/CLI.hpp>
#include <stdexcept>

// CLI flags:
namespace
{
CLI::App cmd{"mm-info"};

std::string argMapFile;
std::string arg_plugins;
}  // namespace

void run_mm_info()
{
    // Load plugins:
    if (!arg_plugins.empty())
    {
        std::string errMsg;
        const auto& plugins = arg_plugins;
        std::cout << "Loading plugin(s): " << plugins << std::endl;
        if (!mrpt::system::loadPluginModules(plugins, errMsg))
        {
            throw std::runtime_error(errMsg);
        }
    }

    const auto& filInput = argMapFile;

    ASSERT_FILE_EXISTS_(argMapFile);

    std::cout << "[mm-info] Reading input map from: '" << filInput << "'..." << std::endl;
    const double mm_t0 = mrpt::Clock::nowDouble();

    mp2p_icp::metric_map_t mm;
    mm.load_from_file(filInput);

    const double mm_t1 = mrpt::Clock::nowDouble();
    std::cout << "[mm-info] Done read map in " << (mm_t1 - mm_t0) << " sec. Contents:\n"
              << mm.contents_summary() << std::endl;
}

int main(int argc, char** argv)
{
    cmd.add_option("input", argMapFile, "Load this metric map file (*.mm)")->required();
    cmd.add_option(
        "-l,--load-plugins", arg_plugins,
        "One or more (comma separated) *.so files to load as plugins");

    CLI11_PARSE(cmd, argc, argv);

    try
    {
        run_mm_info();
    }
    catch (const std::exception& e)
    {
        std::cerr << e.what() << std::endl;
        return 1;
    }
    return 0;
}
