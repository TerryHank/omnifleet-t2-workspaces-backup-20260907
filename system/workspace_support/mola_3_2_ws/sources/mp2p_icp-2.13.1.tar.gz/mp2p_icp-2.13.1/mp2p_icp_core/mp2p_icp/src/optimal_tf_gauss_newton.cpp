/*               _
 _ __ ___   ___ | | __ _
| '_ ` _ \ / _ \| |/ _` | Modular Optimization framework for
| | | | | | (_) | | (_| | Localization and mApping (MOLA)
|_| |_| |_|\___/|_|\__,_| https://github.com/MOLAorg/mola

 A repertory of multi primitive-to-primitive (MP2P) ICP algorithms
 and map building tools. mp2p_icp is part of MOLA.

 Copyright (C) 2018-2026 Jose Luis Blanco, University of Almeria,
                         and individual contributors.
 SPDX-License-Identifier: BSD-3-Clause
*/

/**
 * @file   optimal_tf_gauss_newton.cpp
 * @brief  Iterative non-linear optimizer for the optimal SE(3) transformation from diverse pairings
 * @author Jose Luis Blanco Claraco
 * @date   Jun 16, 2019
 */

#include <mp2p_icp/errorTerms.h>
#include <mp2p_icp/optimal_tf_gauss_newton.h>
#include <mp2p_icp/robust_kernels.h>
#include <mrpt/poses/Lie/SE.h>

#include <Eigen/Dense>
#include <iostream>

#if defined(MP2P_HAS_TBB)
#include <tbb/blocked_range.h>
#include <tbb/parallel_reduce.h>
#endif

using namespace mp2p_icp;

namespace
{
/** Skew-symmetric matrix of a 3-vector, i.e. [v]_x such that [v]_x·w = v × w */
Eigen::Matrix3d skewSymmetric(const Eigen::Vector3d& v)
{
    Eigen::Matrix3d S;
    // clang-format off
    S <<     0, -v.z(),  v.y(),
         v.z(),      0, -v.x(),
        -v.y(),  v.x(),      0;
    // clang-format on
    return S;
}

/** Orthonormal basis (3x2) of the plane orthogonal to the unit vector u. */
Eigen::Matrix<double, 3, 2> orthonormalComplement(const Eigen::Vector3d& u)
{
    // Seed with the canonical axis least aligned with u, for conditioning:
    int seedAxis = 0;
    u.cwiseAbs().minCoeff(&seedAxis);
    Eigen::Vector3d seed = Eigen::Vector3d::Zero();
    seed[seedAxis]       = 1.0;

    Eigen::Vector3d b1 = u.cross(seed);
    b1.normalize();
    Eigen::Vector3d b2 = u.cross(b1);
    b2.normalize();

    Eigen::Matrix<double, 3, 2> B;
    B.col(0) = b1;
    B.col(1) = b2;
    return B;
}
}  // namespace

bool mp2p_icp::optimal_tf_gauss_newton(
    const Pairings& in, OptimalTF_Result& result, const OptimalTF_GN_Parameters& gnParams)
{
    using std::size_t;

    MRPT_START

    // Run Gauss-Newton steps, using SE(3) relinearization at the current solution:
    ASSERTMSG_(
        gnParams.linearizationPoint.has_value(), "This method requires a linearization point");

    result.optimalPose = gnParams.linearizationPoint.value();

    const robust_sqrt_weight_func_t robustSqrtWeightFunc =
        mp2p_icp::create_robust_kernel(gnParams.kernel, gnParams.kernelParam);

    // Approach B: prior-referenced robust kernel.
    // When enabled, the residual that feeds the robust kernel is blended between
    // the current linearization point and the residual predicted at the prior
    // mean pose, so factors that are inconsistent with the prior Gaussian get
    // down-weighted regardless of the (possibly already corrupted) current
    // iterate. Inert when no prior, no kernel, or blend==0.
    const bool usePriorKernelRef = static_cast<bool>(robustSqrtWeightFunc) &&
                                   gnParams.prior.has_value() && gnParams.kernelPriorRefBlend > 0;
    const double               priorRefBlend = std::clamp(gnParams.kernelPriorRefBlend, 0.0, 1.0);
    const mrpt::poses::CPose3D priorRefPose =
        usePriorKernelRef ? gnParams.prior->mean : mrpt::poses::CPose3D::Identity();

    // Returns the robust square-root weight multiplier for a factor, given its
    // residual squared-norm at the current iterate and at the prior mean pose.
    const auto robustWeight = [&](double curSqrNorm, double priorSqrNorm) -> double
    {
        if (!robustSqrtWeightFunc)
        {
            return 1.0;
        }
        const double arg = usePriorKernelRef
                               ? (1.0 - priorRefBlend) * curSqrNorm + priorRefBlend * priorSqrNorm
                               : curSqrNorm;
        return robustSqrtWeightFunc(arg);
    };

    // Gravity term: precompute the (rotation-independent) horizontal basis B
    // of the plane orthogonal to the map-frame gravity direction, plus the
    // normalized body-frame "up". Only the Jacobian below depends on the
    // current rotation, so this part is hoisted out of the iteration loop.
    std::optional<std::pair<Eigen::Matrix<double, 3, 2>, Eigen::Vector3d>> gravityBasis;
    if (gnParams.gravityPrior.has_value())
    {
        const auto& gp = *gnParams.gravityPrior;
        ASSERTMSG_(gp.sigma_rad > 0, "gravityPrior.sigma_rad must be >0");

        const Eigen::Vector3d u_b_raw(gp.up_body.x, gp.up_body.y, gp.up_body.z);
        const Eigen::Vector3d u_m_raw(gp.up_map.x, gp.up_map.y, gp.up_map.z);
        ASSERTMSG_(
            u_b_raw.norm() > 1e-6 && u_m_raw.norm() > 1e-6,
            "gravityPrior up_body/up_map must be non-null vectors");

        const Eigen::Vector3d u_m = u_m_raw.normalized();
        gravityBasis = std::make_pair(orthonormalComplement(u_m), u_b_raw.normalized());
    }

    const auto nPt2Pt   = in.paired_pt2pt.size();
    const auto nCov2Cov = in.paired_cov2cov.size();
    const auto nPt2Ln   = in.paired_pt2ln.size();
    const auto nPt2Pl   = in.paired_pt2pl.size();
    const auto nPl2Pl   = in.paired_pl2pl.size();
    const auto nLn2Ln   = in.paired_ln2ln.size();

    auto w = gnParams.pairWeights;

    for (size_t iter = 0; iter < gnParams.maxInnerLoopIterations; iter++)
    {
        // Note: Using Matrix<N,1> instead of Vector<N> for compatibility
        //       with Eigen<=3.4 in ROS Noetic.
        Eigen::Matrix<double, 6, 1> g = Eigen::Matrix<double, 6, 1>::Zero();
        Eigen::Matrix<double, 6, 6> H = Eigen::Matrix<double, 6, 6>::Zero();

        // (12x6 Jacobian)
        const auto dDexpe_de = mrpt::poses::Lie::SE<3>::jacob_dDexpe_de(result.optimalPose);

        double errNormSqr = 0;

        //
        // ============== point-to-point ===============
        //
#if defined(MP2P_HAS_TBB)
        // For the TBB lambdas:
        // TBB call structure based on the beautiful implementation in KISS-ICP.
        struct Result
        {
            Result()
            {
                H.setZero();
                g.setZero();
                errNormSqr = 0;
            }

            Result operator+(const Result& other) const
            {
                Result res = *this;
                res.H += other.H;
                res.g += other.g;
                res.errNormSqr += other.errNormSqr;
                return res;
            }

            Eigen::Matrix<double, 6, 6> H;
            Eigen::Matrix<double, 6, 1> g;
            double                      errNormSqr = 0;
        };

        const auto [H_tbb_pt2pt, g_tbb_pt2pt, errNormSqr_tbb_pt2pt] = tbb::parallel_reduce(
            // Range
            tbb::blocked_range<size_t>{0, nPt2Pt},
            // Identity
            Result(),
            // 1st lambda: Parallel computation
            [&](const tbb::blocked_range<size_t>& r, Result res) -> Result
            {
                auto& [H_local, g_local, errNormSqr_local] = res;
                for (size_t idx_pt = r.begin(); idx_pt < r.end(); idx_pt++)
                {
                    // Error:
                    const auto&                             p = in.paired_pt2pt[idx_pt];
                    mrpt::math::CMatrixFixed<double, 3, 12> J1;
                    mrpt::math::CVectorFixedDouble<3>       ret =
                        mp2p_icp::error_point2point(p.local, p.global, result.optimalPose, J1);

                    // Apply robust kernel? (optionally prior-referenced)
                    double weight = w.pt2pt, retSqrNorm = ret.asEigen().squaredNorm();
                    double priorSqrNorm = retSqrNorm;
                    if (usePriorKernelRef)
                    {
                        priorSqrNorm = mp2p_icp::error_point2point(p.local, p.global, priorRefPose)
                                           .asEigen()
                                           .squaredNorm();
                    }
                    weight *= robustWeight(retSqrNorm, priorSqrNorm);

                    // Error and Jacobian:
                    const Eigen::Vector3d err_i = ret.asEigen();
                    errNormSqr_local += weight * retSqrNorm;

                    const Eigen::Matrix<double, 3, 6> Ji = J1.asEigen() * dDexpe_de.asEigen();
                    g_local.noalias() += weight * Ji.transpose() * err_i;
                    H_local.noalias() += weight * Ji.transpose() * Ji;
                }
                return res;
            },
            // 2nd lambda: Parallel reduction
            [](const Result& a, const Result& b) -> Result { return a + b; });

        H          = std::move(H_tbb_pt2pt);
        g          = std::move(g_tbb_pt2pt);
        errNormSqr = errNormSqr_tbb_pt2pt;
#else
        // Point-to-point:
        for (size_t idx_pt = 0; idx_pt < nPt2Pt; idx_pt++)
        {
            // Error:
            const auto&                             p = in.paired_pt2pt[idx_pt];
            mrpt::math::CMatrixFixed<double, 3, 12> J1;
            mrpt::math::CVectorFixedDouble<3>       ret =
                mp2p_icp::error_point2point(p.local, p.global, result.optimalPose, J1);

            // Apply robust kernel? (optionally prior-referenced)
            double weight = w.pt2pt, retSqrNorm = ret.asEigen().squaredNorm();
            double priorSqrNorm = retSqrNorm;
            if (usePriorKernelRef)
            {
                priorSqrNorm = mp2p_icp::error_point2point(p.local, p.global, priorRefPose)
                                   .asEigen()
                                   .squaredNorm();
            }
            weight *= robustWeight(retSqrNorm, priorSqrNorm);

            // Error and Jacobian:
            const Eigen::Vector3d err_i = ret.asEigen();
            errNormSqr += weight * retSqrNorm;

            const Eigen::Matrix<double, 3, 6> Ji = J1.asEigen() * dDexpe_de.asEigen();
            g.noalias() += weight * Ji.transpose() * err_i;
            H.noalias() += weight * Ji.transpose() * Ji;
        }
#endif

        //
        // ============== cov-to-cov ===============
        //
        // Accumulate the cov2cov block separately so we can apply a global
        // scale (generalized-Bayes α and/or Birge-ratio κ) before adding to H/g.
        Eigen::Matrix<double, 6, 6> H_cc    = Eigen::Matrix<double, 6, 6>::Zero();
        Eigen::Matrix<double, 6, 1> g_cc    = Eigen::Matrix<double, 6, 1>::Zero();
        double                      chi2_cc = 0;  // sum of Mahalanobis squared norms
#if defined(MP2P_HAS_TBB)
        const auto [H_tbb_cov2cov, g_tbb_cov2cov, errNormSqr_tbb_cov2cov] = tbb::parallel_reduce(
            // Range
            tbb::blocked_range<size_t>{0, nCov2Cov},
            // Identity
            Result(),
            // 1st lambda: Parallel computation
            [&](const tbb::blocked_range<size_t>& r, Result res) -> Result
            {
                auto& [H_local, g_local, errNormSqr_local] = res;
                for (size_t idx_pairing = r.begin(); idx_pairing < r.end(); idx_pairing++)
                {
                    // Error:
                    const auto&                             p = in.paired_cov2cov[idx_pairing];
                    mrpt::math::CMatrixFixed<double, 3, 12> J1;

                    mrpt::math::CVectorFixedDouble<3> ret =
                        mp2p_icp::error_point2point(p.local, p.global, result.optimalPose, J1);

                    const Eigen::Matrix3d cov_inv = p.cov_inv.asEigen().cast<double>();

                    // Apply robust kernel? (optionally prior-referenced)
                    double weight     = 1.0;
                    double retSqrNorm = ret.transpose() * cov_inv * ret.asEigen();

                    double priorSqrNorm = retSqrNorm;
                    if (usePriorKernelRef)
                    {
                        const auto pr =
                            mp2p_icp::error_point2point(p.local, p.global, priorRefPose);
                        priorSqrNorm = pr.transpose() * cov_inv * pr.asEigen();
                    }
                    weight *= robustWeight(retSqrNorm, priorSqrNorm);

                    // Error and Jacobian:
                    const Eigen::Vector3d err_i = ret.asEigen();
                    errNormSqr_local += weight * retSqrNorm;

                    const Eigen::Matrix<double, 3, 6> Ji = J1.asEigen() * dDexpe_de.asEigen();

                    // Whitening: multiply times \Sigma^{-1/2}
                    g_local.noalias() += weight * Ji.transpose() * cov_inv * err_i;
                    H_local.noalias() += weight * Ji.transpose() * cov_inv * Ji;
                }
                return res;
            },
            // 2nd lambda: Parallel reduction
            [](const Result& a, const Result& b) -> Result { return a + b; });

        H_cc    = H_tbb_cov2cov;
        g_cc    = g_tbb_cov2cov;
        chi2_cc = errNormSqr_tbb_cov2cov;
#else
        // Cov-to-cov:
        for (size_t idx_pairing = 0; idx_pairing < nCov2Cov; idx_pairing++)
        {
            // Error:
            const auto&                             p = in.paired_cov2cov[idx_pairing];
            mrpt::math::CMatrixFixed<double, 3, 12> J1;

            mrpt::math::CVectorFixedDouble<3> ret =
                mp2p_icp::error_point2point(p.local, p.global, result.optimalPose, J1);

            const Eigen::Matrix3d cov_inv = p.cov_inv.asEigen().cast<double>();

            // Apply robust kernel? (optionally prior-referenced)
            double weight     = 1.0;
            double retSqrNorm = ret.transpose() * cov_inv * ret.asEigen();

            double priorSqrNorm = retSqrNorm;
            if (usePriorKernelRef)
            {
                const auto pr = mp2p_icp::error_point2point(p.local, p.global, priorRefPose);
                priorSqrNorm  = pr.transpose() * cov_inv * pr.asEigen();
            }
            weight *= robustWeight(retSqrNorm, priorSqrNorm);

            // Error and Jacobian:
            const Eigen::Vector3d err_i = ret.asEigen();
            chi2_cc += weight * retSqrNorm;

            const Eigen::Matrix<double, 3, 6> Ji = J1.asEigen() * dDexpe_de.asEigen();

            // Whitening: multiply by Σ^{-1/2}
            g_cc.noalias() += weight * Ji.transpose() * cov_inv * err_i;
            H_cc.noalias() += weight * Ji.transpose() * cov_inv * Ji;
        }
#endif
        // Generalized-Bayes / Birge-ratio scaling of the cov2cov data block,
        // to keep a meaningful balance against the prior when many cov2cov
        // pairings carry correlated information not captured by their per-pair
        // modeled covariances. See OptimalTF_GN_Parameters docs.
        {
            double cc_scale = gnParams.cov2cov_alpha;
            if (gnParams.cov2cov_auto_balance_with_prior && gnParams.prior.has_value() &&
                nCov2Cov >= 3)
            {
                const double dof   = std::max(1.0, 3.0 * static_cast<double>(nCov2Cov) - 6.0);
                const double kappa = std::max(1.0, chi2_cc / dof);
                cc_scale /= kappa;
            }
            H.noalias() += cc_scale * H_cc;
            g.noalias() += cc_scale * g_cc;
            errNormSqr += cc_scale * chi2_cc;
        }
        //
        // ============== Point-to-line ===============
        //
        for (size_t idx_pt = 0; idx_pt < nPt2Ln; idx_pt++)
        {
            // Error
            const auto&                             p = in.paired_pt2ln[idx_pt];
            mrpt::math::CMatrixFixed<double, 3, 12> J1;
            mrpt::math::CVectorFixedDouble<3>       ret =
                mp2p_icp::error_point2line(p, result.optimalPose, J1);

            // Apply robust kernel? (optionally prior-referenced)
            double weight = w.pt2ln, retSqrNorm = ret.asEigen().squaredNorm();
            double priorSqrNorm = retSqrNorm;
            if (usePriorKernelRef)
            {
                priorSqrNorm = mp2p_icp::error_point2line(p, priorRefPose).asEigen().squaredNorm();
            }
            weight *= robustWeight(retSqrNorm, priorSqrNorm);

            // Error and Jacobian:
            const Eigen::Vector3d err_i = ret.asEigen();
            errNormSqr += weight * retSqrNorm;

            const Eigen::Matrix<double, 3, 6> Ji = J1.asEigen() * dDexpe_de.asEigen();
            g.noalias() += weight * Ji.transpose() * err_i;
            H.noalias() += weight * Ji.transpose() * Ji;
        }

        //
        // ============== Line-to-Line ===============
        //
        // Minimum angle to approach zero
        for (size_t idx_ln = 0; idx_ln < nLn2Ln; idx_ln++)
        {
            const auto&                             p = in.paired_ln2ln[idx_ln];
            mrpt::math::CMatrixFixed<double, 4, 12> J1;
            mrpt::math::CVectorFixedDouble<4>       ret =
                mp2p_icp::error_line2line(p, result.optimalPose, J1);

            // Apply robust kernel? (optionally prior-referenced)
            double weight = w.ln2ln, retSqrNorm = ret.asEigen().squaredNorm();
            double priorSqrNorm = retSqrNorm;
            if (usePriorKernelRef)
            {
                priorSqrNorm = mp2p_icp::error_line2line(p, priorRefPose).asEigen().squaredNorm();
            }
            weight *= robustWeight(retSqrNorm, priorSqrNorm);

            // Error and Jacobian:
            const Eigen::Vector4d err_i = ret.asEigen();
            errNormSqr += weight * retSqrNorm;

            const Eigen::Matrix<double, 4, 6> Ji = J1.asEigen() * dDexpe_de.asEigen();
            g.noalias() += weight * Ji.transpose() * err_i;
            H.noalias() += weight * Ji.transpose() * Ji;
        }

        //
        // ============== Point-to-plane ===============
        //
#if defined(MP2P_HAS_TBB)
        const auto [H_tbb_pt2pl, g_tbb_pt2pl, errNormSqr_tbb_pl2pl] = tbb::parallel_reduce(
            // Range
            tbb::blocked_range<size_t>{0, nPt2Pl},
            // Identity
            Result(),
            // 1st lambda: Parallel computation
            [&](const tbb::blocked_range<size_t>& r, Result res) -> Result
            {
                auto& [H_local, g_local, errNormSqr_local] = res;
                for (size_t idx_pl = r.begin(); idx_pl < r.end(); idx_pl++)
                {
                    // Error:
                    const auto&                             p = in.paired_pt2pl[idx_pl];
                    mrpt::math::CMatrixFixed<double, 3, 12> J1;
                    mrpt::math::CVectorFixedDouble<3>       ret =
                        mp2p_icp::error_point2plane(p, result.optimalPose, J1);

                    // Apply robust kernel? (optionally prior-referenced)
                    double weight = w.pt2pl, retSqrNorm = ret.asEigen().squaredNorm();
                    double priorSqrNorm = retSqrNorm;
                    if (usePriorKernelRef)
                    {
                        priorSqrNorm =
                            mp2p_icp::error_point2plane(p, priorRefPose).asEigen().squaredNorm();
                    }
                    weight *= robustWeight(retSqrNorm, priorSqrNorm);

                    // Error and Jacobian:
                    const Eigen::Vector3d err_i = ret.asEigen();
                    errNormSqr_local += weight * retSqrNorm;

                    const Eigen::Matrix<double, 3, 6> Ji = J1.asEigen() * dDexpe_de.asEigen();
                    g_local.noalias() += weight * Ji.transpose() * err_i;
                    H_local.noalias() += weight * Ji.transpose() * Ji;
                }
                return res;
            },
            // 2nd lambda: Parallel reduction
            [](const Result& a, const Result& b) -> Result { return a + b; });

        H += H_tbb_pt2pl;
        g += g_tbb_pt2pl;
        errNormSqr += errNormSqr_tbb_pl2pl;
#else
        // Point-to-plane:
        for (size_t idx_pl = 0; idx_pl < nPt2Pl; idx_pl++)
        {
            // Error:
            const auto&                             p = in.paired_pt2pl[idx_pl];
            mrpt::math::CMatrixFixed<double, 3, 12> J1;
            mrpt::math::CVectorFixedDouble<3>       ret =
                mp2p_icp::error_point2plane(p, result.optimalPose, J1);

            // Apply robust kernel? (optionally prior-referenced)
            double weight = w.pt2pl, retSqrNorm = ret.asEigen().squaredNorm();
            double priorSqrNorm = retSqrNorm;
            if (usePriorKernelRef)
            {
                priorSqrNorm = mp2p_icp::error_point2plane(p, priorRefPose).asEigen().squaredNorm();
            }
            weight *= robustWeight(retSqrNorm, priorSqrNorm);

            // Error and Jacobian:
            const Eigen::Vector3d err_i = ret.asEigen();
            errNormSqr += weight * retSqrNorm;

            const Eigen::Matrix<double, 3, 6> Ji = J1.asEigen() * dDexpe_de.asEigen();
            g.noalias() += weight * Ji.transpose() * err_i;
            H.noalias() += weight * Ji.transpose() * Ji;
        }
#endif

        // ============= Plane-to-plane ====================
        // (only direction of normal vectors)
        for (size_t idx_pl = 0; idx_pl < nPl2Pl; idx_pl++)
        {
            // Error term:
            const auto&                             p = in.paired_pl2pl[idx_pl];
            mrpt::math::CMatrixFixed<double, 3, 12> J1;
            mrpt::math::CVectorFixedDouble<3>       ret =
                mp2p_icp::error_plane2plane(p, result.optimalPose, J1);

            // Apply robust kernel? (optionally prior-referenced)
            double weight = w.pl2pl, retSqrNorm = ret.asEigen().squaredNorm();
            double priorSqrNorm = retSqrNorm;
            if (usePriorKernelRef)
            {
                priorSqrNorm = mp2p_icp::error_plane2plane(p, priorRefPose).asEigen().squaredNorm();
            }
            weight *= robustWeight(retSqrNorm, priorSqrNorm);

            const Eigen::Vector3d err_i = ret.asEigen();
            errNormSqr += weight * retSqrNorm;

            const Eigen::Matrix<double, 3, 6> Ji = J1.asEigen() * dDexpe_de.asEigen();
            g.noalias() += weight * Ji.transpose() * err_i;
            H.noalias() += weight * Ji.transpose() * Ji;
        }

        // Prior guess term:
        if (gnParams.prior.has_value())
        {
            const auto& priorMean = gnParams.prior->mean;
            const auto& priorInf  = gnParams.prior->cov_inv;

            // Compute the residual pose error of these pair of nodes + its constraint:
            // SE(3) error = inv(P_prior) * P_current
            //             = (P_current \ominus P_prior)

            const mrpt::poses::CPose3D P1invP2 = result.optimalPose - priorMean;
            auto                       err_i   = mrpt::poses::Lie::SE<3>::log(P1invP2);

            mrpt::math::CMatrixDouble66 df_de2;

            mrpt::poses::Lie::SE<3>::jacob_dDinvP1invP2_de1e2(
                // edge between the two poses:in this case, both should coincide
                mrpt::poses::CPose3D::Identity(),
                // P1:
                priorMean,
                // P2:
                result.optimalPose,
                // df_de1
                std::nullopt,
                // df_de2
                df_de2);

            g.noalias() += (df_de2.transpose() * priorInf.asEigen()) * err_i.asEigen();
            H.noalias() += (df_de2.transpose() * priorInf.asEigen()) * df_de2.asEigen();
        }

        // Gravity ("verticality") term: a rank-2, yaw-free tilt observation.
        //
        // Residual: the horizontal component of the predicted "up" vector,
        //   r(R) = B^T · (R · u_b)  in R^2,
        // with B (3x2) an orthonormal basis of the plane orthogonal to u_m.
        // r = 0 exactly when R·u_b is parallel to u_m, i.e. when the solution
        // is level; for small tilt ‖r‖ is the tilt angle [rad].
        //
        // The solver applies increments on the right, P <- P · Exp(eps), so
        //   d(B^T · R · Exp(w) · u_b)/dw |w=0 = -B^T · R · [u_b]_x
        // and translations do not enter the residual at all.
        //
        // Weighting is ISOTROPIC (1/sigma^2 · I_2): that is what makes the
        // cost invariant to rotation about gravity. The induced 6x6
        // information J^T·W·J then has rank 2, zero translation block, and
        // null space exactly span(u_b) = rotation about the gravity axis,
        // so yaw stays free at ANY attitude (not only near yaw=0).
        if (gravityBasis.has_value())
        {
            const auto& [B, u_b] = *gravityBasis;

            const Eigen::Matrix3d R = result.optimalPose.getRotationMatrix().asEigen();

            const Eigen::Vector2d r_g = B.transpose() * (R * u_b);

            // 2x6 Jacobian: [ 0 (translation) | -B^T·R·[u_b]_x (rotation) ]
            Eigen::Matrix<double, 2, 6> Jg = Eigen::Matrix<double, 2, 6>::Zero();
            Jg.block<2, 3>(0, 3).noalias() = -B.transpose() * R * skewSymmetric(u_b);

            const double w_g =
                1.0 / (gnParams.gravityPrior->sigma_rad * gnParams.gravityPrior->sigma_rad);

            g.noalias() += w_g * Jg.transpose() * r_g;
            H.noalias() += w_g * Jg.transpose() * Jg;
        }

        // ============ Termination criterion =============
        // Target error?
        const double errNorm = std::sqrt(errNormSqr);
        if (errNorm <= gnParams.maxCost)
        {
            break;
        }

        // 3) Solve Gauss-Newton:
        // g = J.transpose() * err;
        // H = J.transpose() * J;
        const Eigen::Matrix<double, 6, 1> delta = -H.ldlt().solve(g);

        // 4) add SE(3) increment:
        const auto dE = mrpt::poses::Lie::SE<3>::exp(mrpt::math::CVectorFixed<double, 6>(delta));

        result.optimalPose = result.optimalPose + dE;

        if (gnParams.verbose)
        {
            std::cout << "[P2P GN] iter:" << iter << " err:" << errNorm
                      << " delta:" << delta.transpose() << "\n";
        }

        // Termination criterion:
        if (delta.norm() < gnParams.minDelta)
        {
            break;
        }

    }  // for each iteration

    return true;

    MRPT_END
}
