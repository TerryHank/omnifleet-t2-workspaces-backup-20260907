/*               _
 _ __ ___   ___ | | __ _
| '_ ` _ \ / _ \| |/ _` | Modular Optimization framework for
| | | | | | (_) | | (_| | Localization and mApping (MOLA)
|_| |_| |_|\___/|_|\__,_| https://github.com/MOLAorg/mola

 A repertory of multi primitive-to-primitive (MP2P) ICP algorithms
 and map building tools. mp2p_icp is part of MOLA.

 Copyright (C) 2018-2026 Jose Luis Blanco, University of Almeria,
                         and individual contributors.
 SPDX-License-Identifier: BSD-3-Clause
*/
/**
 * @file   LogRecord.h
 * @brief  A record of the inputs and outputs of an ICP run.
 * @author Jose Luis Blanco Claraco
 * @date   Sep 15, 2021
 */
#pragma once

#include <mp2p_icp/GravityPrior.h>
#include <mp2p_icp/Pairings.h>
#include <mp2p_icp/Parameters.h>
#include <mp2p_icp/Results.h>
#include <mp2p_icp/metricmap.h>
#include <mrpt/poses/CPose3DPDFGaussianInf.h>
#include <mrpt/serialization/CSerializable.h>
#if MRPT_VERSION >= 0x020f07
#include <mrpt/io/compression_options.h>
#endif

#include <optional>

namespace mp2p_icp
{
/** \addtogroup  mp2p_icp_grp
 * @{ */

/** Details on an ICP run, loadable from the GUI tool icp-log-viewer.
 *
 */
class LogRecord : public mrpt::serialization::CSerializable
{
    DEFINE_SERIALIZABLE(LogRecord, mp2p_icp)

   public:
    LogRecord() = default;

    /** @name Data fields
     * @{ */

    /** The ICP input global and local point clouds: */
    metric_map_t::ConstPtr pcGlobal, pcLocal;

    mrpt::math::TPose3D initialGuessLocalWrtGlobal;

    /** Optional prior pose constraint passed to align(). */
    std::optional<mrpt::poses::CPose3DPDFGaussianInf> prior;

    /** Optional gravity ("verticality") observation passed to align().
     *  Recorded because its effective `sigma_rad` is not necessarily the
     *  configured one: callers may widen it at run time (e.g. mola_lidar_odometry's
     *  `adaptive_sigma`), so the strength the solver actually saw cannot be
     *  reconstructed from the configuration alone.
     */
    std::optional<GravityPrior> gravityPrior;

    mp2p_icp::Parameters          icpParameters;
    mp2p_icp::Results             icpResult;
    std::map<std::string, double> dynamicVariables;

    struct DebugInfoPerIteration
    {
        mrpt::poses::CPose3D optimalPose;  //!< for this ICP iteration
        Pairings             pairings;

        void serializeTo(mrpt::serialization::CArchive& out) const;
        void serializeFrom(mrpt::serialization::CArchive& in);

        DECLARE_TTYPENAME_CLASSNAME(mp2p_icp::LogRecord::DebugInfoPerIteration)
    };
    using iteration_idx_t   = std::size_t;
    using IterationsDetails = std::map<iteration_idx_t, DebugInfoPerIteration>;

    std::optional<IterationsDetails> iterationsDetails;

    /** @} */

    /** @name Methods
     * @{ */

    /** Saves the record object to a file, using MRPT serialization and
     *  using on-the-fly GZIP compression.
     * \return true on success.
     */
#if MRPT_VERSION >= 0x020f07
    [[nodiscard]] bool save_to_file(
        const std::string&                  fileName,
        const mrpt::io::CompressionOptions& co = {mrpt::io::CompressionType::Zstd}) const;
#else
    [[nodiscard]] bool save_to_file(const std::string& fileName) const;
#endif

    /** Loads the record object from a file. See \save_to_file()
     * \return true on success.
     */
    bool load_from_file(const std::string& fileName);

    /** Static method alternative to load_from_file().
     *  Throws on any error.
     *
     * \return The loaded object.
     */
    static LogRecord LoadFromFile(const std::string& fileName)
    {
        LogRecord lr;
        lr.load_from_file(fileName);
        return lr;
    }

    /** @} */
};

/** @} */

}  // namespace mp2p_icp

namespace mrpt::serialization
{
mrpt::serialization::CArchive& operator<<(
    mrpt::serialization::CArchive& out, const mp2p_icp::LogRecord::DebugInfoPerIteration& obj);

mrpt::serialization::CArchive& operator>>(
    mrpt::serialization::CArchive& in, mp2p_icp::LogRecord::DebugInfoPerIteration& obj);

}  // namespace mrpt::serialization
