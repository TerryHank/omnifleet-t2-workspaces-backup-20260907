/*               _
 _ __ ___   ___ | | __ _
| '_ ` _ \ / _ \| |/ _` | Modular Optimization framework for
| | | | | | (_) | | (_| | Localization and mApping (MOLA)
|_| |_| |_|\___/|_|\__,_| https://github.com/MOLAorg/mola

 A repertory of multi primitive-to-primitive (MP2P) ICP algorithms
 and map building tools. mp2p_icp is part of MOLA.

 Copyright (C) 2018-2026 Jose Luis Blanco, University of Almeria,
                         and individual contributors.
 SPDX-License-Identifier: BSD-3-Clause
*/

#pragma once

#include <mp2p_icp/WeightParameters.h>
#include <mp2p_icp/covariance.h>
#include <mrpt/containers/yaml.h>
#include <mrpt/core/bits_math.h>  // DEG2RAD()
#include <mrpt/serialization/CSerializable.h>

#include <cstdint>
#include <functional>
#include <string>

namespace mp2p_icp
{
class metric_map_t;  // Frwd decl
class LogRecord;  // Frwd decl

/** ICP parameters.
 * \sa ICP_Base
 * \ingroup mp2p_icp_grp
 */
struct Parameters : public mrpt::serialization::CSerializable
{
    DEFINE_SERIALIZABLE(Parameters, mp2p_icp)

   public:
    /** @name Termination criteria
        @{ */
    /** Maximum number of ICP iterations to run. */
    uint32_t maxIterations{40};

    /** If the correction in all translation coordinates (X,Y,Z) is below
     * this threshold (in meters), iterations are terminated (Default:1e-6)
     */
    double minAbsStep_trans{5e-4};

    /** If the correction in all rotation coordinates (yaw,pitch,roll) is
     * below this threshold (in radians), iterations are terminated
     * (Default:1e-6) */
    double minAbsStep_rot{1e-4};
    /** @} */

    /** @name Debugging and logging
        @{ */

    /** If true, debug files useful to inspect how ICP works internally will be
     * generated and saved to disk for posterior inspection with a GUI.
     *
     * The same mp2p_icp::LogRecord object saved to disk will be also returned
     * by ICP::align().
     *
     * \sa debugFileNameFormat, saveIterationDetails
     */
    bool generateDebugFiles = false;

    /** If enabled, the intermediary pairings and SE(3) solution for each
     *  ICP step will be also stored in the mp2p_icp::LogRecord to help
     *  investigating how ICP made progress.
     */
    bool saveIterationDetails = false;

    /** If set to N>1, only 1 out of N ICP iterations will be kept.
     *  Applicable if saveIterationDetails is true.
     *  Useful to save tons of disk space for large datasets (!).
     */
    uint32_t decimationIterationDetails = 10;

    /** If set to N>1, only 1 out of N log files will be actually generated.
     *  Useful to save tons of disk space for large datasets (!).
     */
    uint32_t decimationDebugFiles = 1;

    /** Generated files format, if generateDebugFiles is true. */
    std::string debugFileNameFormat =
        "icp-run-$UNIQUE_ID-local-$LOCAL_ID$LOCAL_LABEL-global-$GLOBAL_ID$GLOBAL_LABEL.icplog";

    /** Function to apply to the local and global maps before saving the map to
     * a log file. Useful to apply deletion filters to save space and time.
     */
    std::function<void(mp2p_icp::metric_map_t&)> functor_before_logging_local;
    std::function<void(mp2p_icp::metric_map_t&)> functor_before_logging_global;

    /** Optional function to override `generateDebugFiles`: If the function is provided, and it
     * returns a valid value, it will override `generateDebugFiles` and `decimationDebugFiles`  */
    std::function<std::optional<bool>(const LogRecord&)> functor_should_generate_debug_file;

    bool debugPrintIterationProgress = false;

    /** Quality checkpoints: if the quality is smaller than the given threshold
     * at the prescribed iteration, ICP will be aborted. */
    std::map<uint32_t, double> quality_checkpoints = {{50U, 0.05}, {100U, 0.10}};

    /** If true (default=false), a final matcher pass is run with ICP_ITERATION set to
     *  maxIterations before evaluating quality. This ensures the quality score
     *  reflects pairings at the final (tightest) threshold, regardless of how
     *  early the solver converged. Set to false only to reproduce legacy
     *  behavior. */
    bool force_final_pairings_for_quality = false;

    /** @} */

    /** Parameters for the post-optimization SE(3) covariance estimation
     *  (see mp2p_icp::covariance). Loadable from the optional YAML map
     *  block `covariance:` in the ICP pipeline file. */
    CovarianceParameters covariance_params;

    void load_from(const mrpt::containers::yaml& p);
    void save_to(mrpt::containers::yaml& p) const;
};

}  // namespace mp2p_icp
