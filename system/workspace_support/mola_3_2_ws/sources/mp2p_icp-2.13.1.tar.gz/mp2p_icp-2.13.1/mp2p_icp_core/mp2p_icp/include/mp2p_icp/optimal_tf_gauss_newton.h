/*               _
 _ __ ___   ___ | | __ _
| '_ ` _ \ / _ \| |/ _` | Modular Optimization framework for
| | | | | | (_) | | (_| | Localization and mApping (MOLA)
|_| |_| |_|\___/|_|\__,_| https://github.com/MOLAorg/mola

 A repertory of multi primitive-to-primitive (MP2P) ICP algorithms
 and map building tools. mp2p_icp is part of MOLA.

 Copyright (C) 2018-2026 Jose Luis Blanco, University of Almeria,
                         and individual contributors.
 SPDX-License-Identifier: BSD-3-Clause
*/

/**
 * @file   optimal_tf_gauss_newton.h
 * @brief  Iterative non-linear optimizer for the optimal SE(3) transformation from diverse pairings
 * @author Jose Luis Blanco Claraco
 * @date   Jun 16, 2019
 */
#pragma once

#include <mp2p_icp/GravityPrior.h>
#include <mp2p_icp/OptimalTF_Result.h>
#include <mp2p_icp/PairWeights.h>
#include <mp2p_icp/Pairings.h>
#include <mp2p_icp/robust_kernels.h>
#include <mrpt/poses/CPose3DPDFGaussianInf.h>

namespace mp2p_icp
{
/** \addtogroup  mp2p_icp_grp
 * @{ */
struct OptimalTF_GN_Parameters
{
    OptimalTF_GN_Parameters() = default;

    /** The linerization point (the current relative pose guess) */
    std::optional<mrpt::poses::CPose3D> linearizationPoint;

    /** Optional prior guess of the SE(3) solution, including a mean value
     *  and an inverse covariance (information) matrix, i.e. zeros in the
     * diagonal mean that those prior coordinates should be ignored, a large
     * value means the solution must be close to those coordinates.
     *
     * \note The information matrix is applied to the residual
     * `log(P_prior^-1 · P_cur)` and is therefore expressed in the SE(3) **Lie**
     * tangent: entries [0..2] are x,y,z and [3..5] are the rotation-VECTOR
     * components (w_x, w_y, w_z), i.e. approximately (roll, pitch, yaw) axes.
     * This is NOT MRPT's (x, y, z, yaw, pitch, roll) Euler ordering used by
     * CPose3DPDFGaussian elsewhere: the two swap indices 3 and 5.
     */
    std::optional<mrpt::poses::CPose3DPDFGaussianInf> prior;

    /** Optional gravity ("verticality") observation, INDEPENDENT of `prior`:
     *  a yaw-free, rank-2 tilt constraint that never touches translation.
     *  See mp2p_icp::GravityPrior for the residual and its properties.
     *
     *  Being a function of the current rotation, its linearization is rebuilt
     *  at every Gauss-Newton iteration (unlike a fixed `prior` information).
     */
    std::optional<GravityPrior> gravityPrior;

    /** Minimum SE(3) change to stop iterating. */
    double minDelta = 1e-7;

    /** Maximum cost function; when reached, stop iterating. */
    double maxCost = 0;

    PairWeights pairWeights;

    /** Maximum number of iterations trying to solve for the optimal pose */
    uint32_t maxInnerLoopIterations = 6;

    RobustKernel kernel      = RobustKernel::None;
    double       kernelParam = 1.0;

    /** Reference used to evaluate the residual that feeds the robust kernel,
     *  blended between the current linearization point (β=0) and the residual
     *  predicted at the prior mean pose (β=1):
     *
     *    refSqrNorm = (1-β)·‖r_i(x)‖² + β·‖r_i(prior.mean)‖²
     *
     *  β=0 (default) reproduces the classic behavior, where a factor is judged
     *  only by how much it diverges from the *current* iterate. With β>0 each
     *  factor is (partially) judged by how much it diverges from the prior
     *  Gaussian, so correspondences inconsistent with the prior are
     *  down-weighted even if they look fine at a (possibly already corrupted)
     *  current iterate. Has no effect when no prior is given, no robust kernel
     *  is selected, or β=0. Range: [0,1]. */
    double kernelPriorRefBlend = 0.0;

    /** Generalized (tempered) Bayesian scaling for the cov-to-cov data block:
     *  the cov2cov contribution to H and g is multiplied by `cov2cov_alpha`.
     *  α=1 keeps the standard MAP cost; α<1 down-weights the data likelihood
     *  (e.g. α=1/N turns it into a "mean residual" form). Useful when many
     *  cov-to-cov pairings carry correlated information that the per-pair
     *  modeled covariances do not capture, and the prior is otherwise drowned. */
    double cov2cov_alpha = 1.0;

    /** If true (default) and a prior is provided, automatically balance the
     *  cov2cov data block against the prior using a Birge-ratio-style global
     *  scale of the modeled per-pair covariances:
     *    κ = max(1, χ²_cc / (3·N_cc − 6))
     *  evaluated at each iteration's current residuals; the cov2cov block of
     *  H and g is then scaled by 1/κ. Has no effect when the prior is absent. */
    bool cov2cov_auto_balance_with_prior = true;

    bool verbose = false;
};

/** Gauss-Newton non-linear, iterative optimizer to find the SE(3) optimal
 * transformation between a set of correspondences.
 *
 * This method requires a linearization point in
 * `OptimalTF_GN_Parameters::linearizationPoint`.
 *
 * \return false If the number of pairings is too small for a unique
 * solution, true on success.
 */
[[nodiscard]] bool optimal_tf_gauss_newton(
    const Pairings& in, OptimalTF_Result& result,
    const OptimalTF_GN_Parameters& gnParams = OptimalTF_GN_Parameters());

/** @} */

}  // namespace mp2p_icp
