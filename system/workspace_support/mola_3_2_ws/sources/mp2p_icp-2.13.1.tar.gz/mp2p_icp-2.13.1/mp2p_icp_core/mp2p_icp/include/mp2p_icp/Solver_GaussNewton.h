/*               _
 _ __ ___   ___ | | __ _
| '_ ` _ \ / _ \| |/ _` | Modular Optimization framework for
| | | | | | (_) | | (_| | Localization and mApping (MOLA)
|_| |_| |_|\___/|_|\__,_| https://github.com/MOLAorg/mola

 A repertory of multi primitive-to-primitive (MP2P) ICP algorithms
 and map building tools. mp2p_icp is part of MOLA.

 Copyright (C) 2018-2026 Jose Luis Blanco, University of Almeria,
                         and individual contributors.
 SPDX-License-Identifier: BSD-3-Clause
*/
/**
 * @file   Solver_GaussNewton.h
 * @brief  ICP registration for points and planes
 * @author Jose Luis Blanco Claraco
 * @date   May 11, 2019
 */
#pragma once

#include <mp2p_icp/PairWeights.h>
#include <mp2p_icp/Solver.h>
#include <mp2p_icp/robust_kernels.h>

namespace mp2p_icp
{
/** ICP registration for points, planes, and lines, using an iterative
 * Gauss-Newton numerical solver.
 *
 * \ingroup mp2p_icp_grp
 */
class Solver_GaussNewton : public Solver
{
    DEFINE_MRPT_OBJECT(Solver_GaussNewton, mp2p_icp)

   public:
    uint32_t    maxIterations = 5;
    PairWeights pairWeights;

    RobustKernel robustKernel      = RobustKernel::None;
    double       robustKernelParam = 1.0;
    bool         innerLoopVerbose  = false;  //!< Prints GN inner loop details

    /** Blend [0,1] for the robust kernel residual reference between the current
     *  linearization point (0, default) and the prior mean pose (1). See
     *  OptimalTF_GN_Parameters::kernelPriorRefBlend. */
    double robustKernelPriorRefBlend = 0.0;

    /** Scaling of the cov-to-cov data block against the prior. See
     *  OptimalTF_GN_Parameters::cov2cov_alpha. */
    double cov2cov_alpha = 1.0;

    /** Automatic Birge-ratio balancing of the cov2cov block against the prior.
     *  See OptimalTF_GN_Parameters::cov2cov_auto_balance_with_prior. */
    bool cov2cov_auto_balance_with_prior = true;

    void initialize(const mrpt::containers::yaml& params) override;

   protected:
    // See base class docs
    bool impl_optimal_pose(
        const Pairings& pairings, OptimalTF_Result& out, const SolverContext& sc) const override;
};

}  // namespace mp2p_icp
