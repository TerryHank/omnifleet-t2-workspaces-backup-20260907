/*               _
 _ __ ___   ___ | | __ _
| '_ ` _ \ / _ \| |/ _` | Modular Optimization framework for
| | | | | | (_) | | (_| | Localization and mApping (MOLA)
|_| |_| |_|\___/|_|\__,_| https://github.com/MOLAorg/mola

 A repertory of multi primitive-to-primitive (MP2P) ICP algorithms
 and map building tools. mp2p_icp is part of MOLA.

 Copyright (C) 2018-2026 Jose Luis Blanco, University of Almeria,
                         and individual contributors.
 SPDX-License-Identifier: BSD-3-Clause
*/
/**
 * @file   Generator.h
 * @brief  Base virtual class for point cloud filters
 * @author Jose Luis Blanco Claraco
 * @date   Jun 10, 2019
 */

#pragma once

#include <mp2p_icp/Parameterizable.h>
#include <mp2p_icp/metricmap.h>
#include <mrpt/containers/yaml.h>
#include <mrpt/maps/CPointsMap.h>
#include <mrpt/math/TPoint3D.h>
#include <mrpt/obs/obs_frwds.h>
#include <mrpt/rtti/CObject.h>
#include <mrpt/system/COutputLogger.h>
#include <mrpt/system/CTimeLogger.h>

#include <regex>
#include <stdexcept>

namespace mp2p_icp_filters
{
/** \addtogroup mp2p_icp_filters_grp
 *  @{ */

/** Used in Generator
 */
struct NotImplementedError : public std::runtime_error
{
    // NotImplementedError() = default;
    template <typename T>
    NotImplementedError(T v) : std::runtime_error(v)
    {
    }
};

/** Generic base class providing process(), converting a generic
 *  mrpt::obs::CObservation into a metric_map_t with just a point cloud layer
 *  (named `raw`).
 *
 * This metric_map_t can optionally then be passed through one or more
 * FilterBase implementations to detect features, decimate it, etc.
 *
 * Specializations of Generator may exist and could be implemented to exploit
 * the structured information in the original CObservation data to be more
 * efficient in detecting features (e.g. corners, etc.).

 * Internally, different signatures exists for:
 * - 2D LiDAR range scans (mrpt::obs::CObservation2DRangeScan)
 * - 3D Velodyne scans (mrpt::obs::CObservationVelodyneScan)
 * - 3D RGBD camera images (mrpt::obs::CObservation3DRangeScan)
 * - Generic 2D/3D point clouds (mrpt::obs::CObservationPointCloud)
 * - Generic multi-beam rotating (or flash) Lidars
 *   (mrpt::obs::CObservationRotatingScan)
 *
 * Derived classes may implement all or only one of those methods. An
 * exception NotImplementedError will be thrown if an non-implemented method is
 * called.
 *
 * \note process() is not required to be thread (multientry) safe.
 *
 * A set of generators can be loaded from a YAML file and applied together using
 * mp2p_icp_filters::apply_generators().
 *
 */
class Generator : public mrpt::rtti::CObject,  // RTTI support
                  public mrpt::system::COutputLogger,  // Logging support
                  public mp2p_icp::Parameterizable  // Dynamic parameters
{
    DEFINE_MRPT_OBJECT(Generator, mp2p_icp_filters)

   public:
    Generator();

    /** \name Generator API
     *  @{ */

    /** Loads, from a YAML configuration block, all the common, and
     * implementation-specific parameters.
     * If you redefine this method, remember calling this method on the parent
     * class.
     */
    virtual void initialize(const mrpt::containers::yaml& cfg_block);

    /** See docs above for Generator.
     * This method dispatches the observation by type to the corresponding
     * virtual method
     */
    virtual bool process(
        const mrpt::obs::CObservation& input_raw, mp2p_icp::metric_map_t& inOut,
        const std::optional<mrpt::poses::CPose3D>& robotPose = std::nullopt) const;

    /** If this generator was configured with a custom `metric_map_definition` (or
     *  `metric_map_definition_ini_file`), and `out` does not already contain a layer named
     *  `target_layer`, creates an empty instance of that map class and inserts it into `out`.
     *
     *  Unlike process(), this does not require any observation to be at hand. It is used, e.g.,
     *  by the `mm-filter` CLI tool to pre-create custom-class layers (such as
     *  `mola::KeyframePointCloudMap`) directly on a `.mm` file, from a `generators:` pipeline
     *  section, so that a later `FilterMerge` filter can insert existing point cloud layers into
     *  them.
     *
     *  \return true if a new layer was actually created; false if it already existed, or if this
     *  generator uses the default point-cloud generation mode (no `metric_map_definition` given).
     */
    bool createTargetLayerIfNeeded(mp2p_icp::metric_map_t& out) const;

    struct Parameters
    {
        void load_from_yaml(const mrpt::containers::yaml& c, Generator& parent);

        /** The map layer name where the observation will be loaded into.
         *  Default: "raw" */
        std::string target_layer = mp2p_icp::metric_map_t::PT_LAYER_RAW;

        /** If empty (default), a point cloud layer will be generated of type
         *  mrpt::maps::CSimplePointCloud, and the observation will be inserted
         * via the virtual method mrpt::maps::CMetricMap::insertObservation()
         *
         * Alternatively, if this variable *or* `metric_map_definition` are set,
         * a custom metric map class can be defined via a
         * mrpt::maps::CMultiMetricMap initializer list.
         * If the CMultiMetricMap defines multiple metric maps, the first one
         * only will be taken to generate the new layer.
         *
         * This variable may be set to an external `.ini` file in the format
         * expected by mrpt::maps::TSetOfMetricMapInitializers. The recomended
         * alternative is to directly define the map setting in the YAML file.
         *
         * Refer to [example pipelines](https://docs.mola-slam.org/mp2p_icp/).
         *
         */
        std::string metric_map_definition_ini_file;

        /** Read metric_map_definition_ini_file. Defining a custom metric map
         * via this YAML structure is preferred, since parameterizable variables
         * are supported in this way, while external `.ini` files must contain
         * fixed static values only.
         */
        mrpt::containers::yaml metric_map_definition;

        /** Sensor observation class names to process. Default = ".*" (any).
         *  Example: use "mrpt::obs::CObservation2DRangeScan" if you only want
         * 2D lidar scans to be processed.
         */
        std::string process_class_names_regex = ".*";

        /** Sensor labels to process. Default = ".*" (any).
         *  Examples: "LIDAR", "FRONT_KINECT", "LIDAR_.*"
         */
        std::string process_sensor_labels_regex = ".*";

        bool throw_on_unhandled_observation_class = false;

        /** If true (default), a "view vector" field is added to the output point
         *  cloud layer if it is a mrpt::maps::CGenericPointsMap. The view vector
         *  is the unit vector pointing inwards from the point towards the sensor
         *  origin, stored as float fields named "view_x", "view_y", "view_z".
         *
         *  Generation is SIMD vectorized, with a minimal runtime cost of ~30 μs per LiDAR scan.
         */
        bool generate_view_vector = true;

        /** When processing mrpt::obs::CObservationPointCloud as inputs, this will be the class of
         * the generated layer, in which the cloud will be later inserted.
         * Set to empty means use the same class as the original cloud in the observation.
         * Default is to use the modern CGenericPointsMap which is capable of arbitrary point cloud
         * fields.
         */
        std::string default_pointcloud_class = "mrpt::maps::CGenericPointsMap";

        /** When processing mrpt::obs::CObservationPointCloud as inputs, this controls whether
         *  points with (x,y,z)=(0,0,0) should be discarded as invalid ones; e.g. typical in
         *  organized clouds from LiDAR sensors.
         */
        bool filterOutPointsAtZero = false;

        /** If not empty, it will be used instead of class name in Logger and Profiler.
         *  This is loaded from the `name` key in the YAML configuration block.
         */
        std::string name;
    };

    Parameters params;

    /** @} */

   protected:
    // To be overriden in derived classes, if implemented:
    /** Process a 2D lidar scan. \return false if not implemented */
    virtual bool filterScan2D(
        const mrpt::obs::CObservation2DRangeScan& pc, mp2p_icp::metric_map_t& out,
        const std::optional<mrpt::poses::CPose3D>& robotPose) const;
    /** Process a depth camera observation. \return false if not implemented */
    virtual bool filterScan3D(
        const mrpt::obs::CObservation3DRangeScan& pc, mp2p_icp::metric_map_t& out,
        const std::optional<mrpt::poses::CPose3D>& robotPose) const;
    /** Process a 3D lidar scan. \return false if not implemented   */
    virtual bool filterVelodyneScan(
        const mrpt::obs::CObservationVelodyneScan& pc, mp2p_icp::metric_map_t& out,
        const std::optional<mrpt::poses::CPose3D>& robotPose) const;
    /** Process a 2D/3D point-cloud. \return false if not implemented  */
    virtual bool filterPointCloud(
        const mrpt::maps::CPointsMap& pc, const mrpt::poses::CPose3D& sensorPose,
        mp2p_icp::metric_map_t& out, const std::optional<mrpt::poses::CPose3D>& robotPose) const;
    /** Process a 3D lidar scan. \return false if not implemented   */
    virtual bool filterRotatingScan(
        const mrpt::obs::CObservationRotatingScan& pc, mp2p_icp::metric_map_t& out,
        const std::optional<mrpt::poses::CPose3D>& robotPose) const;

    /** Process IMU readings: forward them to the local velocity buffer of the parameter source */
    virtual bool processIMU(const mrpt::obs::CObservationIMU& imu) const;

    bool       initialized_ = false;
    std::regex process_class_names_regex_;
    std::regex process_sensor_labels_regex_;

   private:
    bool implProcessDefault(
        const mrpt::obs::CObservation& o, mp2p_icp::metric_map_t& out,
        const std::optional<mrpt::poses::CPose3D>& robotPose = std::nullopt) const;

    bool implProcessCustomMap(
        const mrpt::obs::CObservation& o, mp2p_icp::metric_map_t& out,
        const std::optional<mrpt::poses::CPose3D>& robotPose = std::nullopt) const;

    /** Adds "view_x", "view_y", "view_z" float fields to the newly-appended
     *  points in \a pc (from index \a firstNewPtIdx onwards), containing the
     *  unit vector from each point towards \a sensorOrigin.
     *  Does nothing if \a pc is not a mrpt::maps::CGenericPointsMap.
     */
    void addViewVectorField(
        mrpt::maps::CPointsMap& pc, size_t firstNewPtIdx,
        const mrpt::math::TPoint3D& sensorOrigin) const;
};

/** A set of generators  */
using GeneratorSet = std::vector<Generator::Ptr>;

/** Applies a set of generators to a given input raw observation(s) and
 *  generates a metric_map_t.
 *
 *  \note The former contents on the output metric_map_t object are untouched,
 *  so calling this function several times can be used to accumulate point cloud
 * elements from different sensors.
 * \return true if any of the generators actually processed "obs"
 */
bool apply_generators(
    const GeneratorSet& generators, const mrpt::obs::CObservation& obs,
    mp2p_icp::metric_map_t&                              output,
    const std::optional<mrpt::poses::CPose3D>&           robotPose = std::nullopt,
    const mrpt::optional_ref<mrpt::system::CTimeLogger>& profiler  = std::nullopt);

/// \overload (functional version returning the metric_map_t)
[[nodiscard]] mp2p_icp::metric_map_t apply_generators(
    const GeneratorSet& generators, const mrpt::obs::CObservation& obs,
    const std::optional<mrpt::poses::CPose3D>& robotPose = std::nullopt);

/** \overload (version with an input CSensoryFrame)
 *  \return true if any of the generators actually processed any of the
 *          observations in the SF.
 */
bool apply_generators(
    const GeneratorSet& generators, const mrpt::obs::CSensoryFrame& sf,
    mp2p_icp::metric_map_t&                    output,
    const std::optional<mrpt::poses::CPose3D>& robotPose = std::nullopt);

/** \overload (functional version returning the metric_map_t) */
[[nodiscard]] mp2p_icp::metric_map_t apply_generators(
    const GeneratorSet& generators, const mrpt::obs::CSensoryFrame& sf,
    const std::optional<mrpt::poses::CPose3D>& robotPose = std::nullopt);

/** Creates a set of generators from a YAML configuration block (a sequence).
 *  Returns an empty generators set for an empty or null yaml node.
 *  Refer to YAML file examples.
 *  Returned generators are already initialize()'d.
 */
[[nodiscard]] GeneratorSet generators_from_yaml(
    const mrpt::containers::yaml&       c,
    const mrpt::system::VerbosityLevel& vLevel = mrpt::system::LVL_INFO);

/** \overload Taking a YAML filename as input.
 *  The file must contain with a top entry named `generators` with the sequence
 *  of generator descriptors.
 *  Returns an empty generators set for an empty or null yaml node.
 *  Refer to YAML file examples.
 *  Returned generators are already initialize()'d.
 */
[[nodiscard]] GeneratorSet generators_from_yaml_file(
    const std::string&                  filename,
    const mrpt::system::VerbosityLevel& vLevel = mrpt::system::LVL_INFO);

/** @} */

}  // namespace mp2p_icp_filters
