/*               _
 _ __ ___   ___ | | __ _
| '_ ` _ \ / _ \| |/ _` | Modular Optimization framework for
| | | | | | (_) | | (_| | Localization and mApping (MOLA)
|_| |_| |_|\___/|_|\__,_| https://github.com/MOLAorg/mola

 A repertory of multi primitive-to-primitive (MP2P) ICP algorithms
 and map building tools. mp2p_icp is part of MOLA.

 Copyright (C) 2018-2026 Jose Luis Blanco, University of Almeria,
                         and individual contributors.
 SPDX-License-Identifier: BSD-3-Clause
*/
/**
 * @file   FilterDecimateVoxels.h
 * @brief  Builds a new layer with a decimated version of an input layer.
 * @author Jose Luis Blanco Claraco
 * @date   Sep 10, 2021
 */

#pragma once

#include <mp2p_icp/metricmap.h>
#include <mp2p_icp_filters/DecimateMethod.h>
#include <mp2p_icp_filters/FilterBase.h>
#include <mp2p_icp_filters/PointCloudToVoxelGrid.h>
#include <mp2p_icp_filters/PointCloudToVoxelGridSingle.h>
#include <mrpt/maps/CPointsMap.h>

namespace mp2p_icp_filters
{
/** Builds a new layer with a decimated version of one or more input layers,
 * merging their contents.
 *
 * This builds a voxel grid from the input point cloud, and then takes either,
 * the mean of the points in the voxel, or one of the points picked at random,
 * depending on the parameter `decimate_method`.
 *
 * If the given output pointcloud layer already exists, new points will be
 * appended, without clearing the former contents.
 *
 * If the parameter `flatten_to` is defined, this filter will also "flatten" or
 * "summarize" the 3D points into a 2D planar (constant height `z`) cloud.
 *
 * Additional input point fields (ring, intensity, timestamp) will be copied
 * into the output target cloud, except when using the `flatten_to` option.
 *
 * If `minimum_input_points_to_filter` is defined, input clouds smaller than
 * that size will not be decimated at all.
 *
 * Not compatible with calling from different threads simultaneously for
 * different input point clouds. Use independent instances for each thread if
 * needed.
 *
 * \ingroup mp2p_icp_filters_grp
 */
class FilterDecimateVoxels : public mp2p_icp_filters::FilterBase
{
    DEFINE_MRPT_OBJECT(FilterDecimateVoxels, mp2p_icp_filters)
   public:
    FilterDecimateVoxels();

    // See docs in FilterBase
    void filter(mp2p_icp::metric_map_t& inOut) const override;

    struct Parameters
    {
        void load_from_yaml(const mrpt::containers::yaml& c, FilterDecimateVoxels& parent);

        /** One or more input layers, from which to read (and merge) input
         * points */
        std::vector<std::string> input_pointcloud_layer = {mp2p_icp::metric_map_t::PT_LAYER_RAW};

        /** Whether to throw an exception if the input layer does not exist, or,
         * otherwise, it should be silently ignored producing an empty output.
         */
        bool error_on_missing_input_layer = true;

        /** The output point cloud layer name */
        std::string output_pointcloud_layer;

        /** Size of each voxel edge [meters] */
        float voxel_filter_resolution = 1.0f;  // [m]

        /** Whether to use as container implementation
         * tsl::robin_map (true, default), or a std::map (false).
         * For large clouds (>10^6), std::map seems to be faster.
         */
        bool use_tsl_robin_map = true;

        /** If !=0 and there are less input points that this number,
         *  all points will be just moved through without decimation.
         */
        uint32_t minimum_input_points_to_filter = 0;

        /** Minimum number of points in each voxel to use that voxel output.
         * It applies to all `decimate_method` options, except DecimateMethod::FirstPoint
         */
        uint32_t minimum_points_per_voxel = 0;

        /// See description on top of this page.
        std::optional<double> flatten_to;

        /** The method to pick what point will be used as representative of each
         * voxel */
        DecimateMethod decimate_method = DecimateMethod::FirstPoint;
    };

    /** Algorithm parameters */
    Parameters params;

   protected:
    // See docs in base class.
    void initialize_filter(const mrpt::containers::yaml& c) override;

   private:
    mutable std::optional<PointCloudToVoxelGrid>       filter_grid_;
    mutable std::optional<PointCloudToVoxelGridSingle> filter_grid_single_;

    bool useSingleGrid() const { return params.decimate_method == DecimateMethod::FirstPoint; }
};

/** @} */

}  // namespace mp2p_icp_filters
