/*               _
 _ __ ___   ___ | | __ _
| '_ ` _ \ / _ \| |/ _` | Modular Optimization framework for
| | | | | | (_) | | (_| | Localization and mApping (MOLA)
|_| |_| |_|\___/|_|\__,_| https://github.com/MOLAorg/mola

 A repertory of multi primitive-to-primitive (MP2P) ICP algorithms
 and map building tools. mp2p_icp is part of MOLA.

 Copyright (C) 2018-2026 Jose Luis Blanco, University of Almeria,
                         and individual contributors.
 SPDX-License-Identifier: BSD-3-Clause
*/
/**
 * @file   FilterAdjustTimestamps.cpp
 * @brief  Normalizes point cloud timestamps
 * @author Jose Luis Blanco Claraco
 * @date   Jun 19, 2024
 */

#include <mp2p_icp_filters/FilterAdjustTimestamps.h>
#include <mrpt/containers/yaml.h>
#include <mrpt/version.h>

#include <optional>

IMPLEMENTS_MRPT_OBJECT(FilterAdjustTimestamps, mp2p_icp_filters::FilterBase, mp2p_icp_filters)

using namespace mp2p_icp_filters;

void FilterAdjustTimestamps::Parameters::load_from_yaml(
    const mrpt::containers::yaml& c, FilterAdjustTimestamps& parent)
{
    MCP_LOAD_REQ(c, pointcloud_layer);
    MCP_LOAD_REQ(c, method);
    MCP_LOAD_REQ(c, silently_ignore_no_timestamps);

    DECLARE_PARAMETER_IN_OPT(c, time_offset, parent);
}

FilterAdjustTimestamps::FilterAdjustTimestamps()
{
    mrpt::system::COutputLogger::setLoggerName("FilterAdjustTimestamps");
}

void FilterAdjustTimestamps::initialize_filter(const mrpt::containers::yaml& c)
{
    MRPT_START

    MRPT_LOG_DEBUG_STREAM("Loading these params:\n" << c);
    params.load_from_yaml(c, *this);

    MRPT_END
}

void FilterAdjustTimestamps::filter(mp2p_icp::metric_map_t& inOut) const
{
    MRPT_START

    checkAllParametersAreRealized();

    if (params.method == TimestampAdjustMethod::None)
    {
        // Do nothing. Also, there is no need to
        // call "ps->localVelocityBuffer.set_reference_zero_time()" since dt would be 0.
        return;
    }

    // In/out:
    auto pcPtr = inOut.point_layer(params.pointcloud_layer);
    ASSERTMSG_(
        pcPtr, mrpt::format(
                   "Input point cloud layer '%s' was not found.", params.pointcloud_layer.c_str()));

    auto& pc = *pcPtr;

    if (pc.empty())
    {
        MRPT_LOG_WARN_STREAM(
            "Skipping time adjusting in input cloud '" << params.pointcloud_layer
                                                       << "' because it is empty.");
        return;
    }

    auto* TsPtr = pc.getPointsBufferRef_float_field("t");

    if (TsPtr == nullptr || (TsPtr->empty() && !pc.empty()))
    {
        // we don't have timestamps:
        if (params.silently_ignore_no_timestamps)
        {
            MRPT_LOG_DEBUG_STREAM(
                "Skipping time adjusting in input cloud '" << params.pointcloud_layer
                                                           << "' with contents: " << pc.asString()
                                                           << " due to missing timestamps.");
            return;
        }

        THROW_EXCEPTION_FMT(
            "Cannot do time adjusting for input cloud '%s' "
            "with contents: %s due to missing timestamps.",
            params.pointcloud_layer.c_str(), pc.asString().c_str());
    }

    auto& Ts = *TsPtr;

    std::optional<float> minT, maxT;

    for (size_t i = 0; i < Ts.size(); i++)
    {
        const float t = Ts[i];

        if (!minT || t < *minT)
        {
            minT = t;
        }
        if (!maxT || t > *maxT)
        {
            maxT = t;
        }
    }
    ASSERT_(minT && maxT);

    auto  ps = this->attachedSource();
    float dt = 0;

    switch (params.method)
    {
        case TimestampAdjustMethod::MiddleIsZero:
        {
            dt = 0.5f * (*maxT + *minT) + static_cast<float>(params.time_offset);
            for (auto& t : Ts)
            {
                t -= dt;
            }
        }
        break;
        case TimestampAdjustMethod::EarliestIsZero:
        {
            dt = *minT + static_cast<float>(params.time_offset);
            for (auto& t : Ts)
            {
                t -= dt;
            }
        }
        break;
        case TimestampAdjustMethod::Normalize:
        {
            const float m = *minT;
            const float k = *maxT != *minT ? 1.0f / (*maxT - *minT) : 1.0f;
            for (auto& t : Ts)
            {
                t = (t - m) * k + static_cast<float>(params.time_offset);
            }
        }
        break;

        default:
            THROW_EXCEPTION("Unknown value for 'method'");
    }

    if (ps)
    {
#if defined(MP2P_ICP_HAS_MOLA_IMU_PREINTEGRATION)
        ps->localVelocityBuffer.set_reference_zero_time(
            ps->localVelocityBuffer.get_reference_zero_time() + dt);
#endif
    }

    MRPT_END
}
