/*               _
 _ __ ___   ___ | | __ _
| '_ ` _ \ / _ \| |/ _` | Modular Optimization framework for
| | | | | | (_) | | (_| | Localization and mApping (MOLA)
|_| |_| |_|\___/|_|\__,_| https://github.com/MOLAorg/mola

 A repertory of multi primitive-to-primitive (MP2P) ICP algorithms
 and map building tools. mp2p_icp is part of MOLA.

 Copyright (C) 2018-2026 Jose Luis Blanco, University of Almeria,
                         and individual contributors.
 SPDX-License-Identifier: BSD-3-Clause
*/
/**
 * @file   FilterBoundingBox.cpp
 * @brief  Builds a new layer with a decimated version of an input layer.
 * @author Jose Luis Blanco Claraco
 * @date   Sep 10, 2021
 */

#include <mp2p_icp/pointcloud_field_utils.h>
#include <mp2p_icp_filters/FilterBoundingBox.h>
#include <mp2p_icp_filters/GetOrCreatePointLayer.h>
#include <mrpt/containers/yaml.h>
#include <mrpt/math/ops_containers.h>  // dotProduct
#include <mrpt/version.h>

IMPLEMENTS_MRPT_OBJECT(FilterBoundingBox, mp2p_icp_filters::FilterBase, mp2p_icp_filters)

using namespace mp2p_icp_filters;

void FilterBoundingBox::Parameters::load_from_yaml(
    const mrpt::containers::yaml& c, FilterBoundingBox& parent)
{
    MCP_LOAD_OPT(c, input_pointcloud_layer);
    MCP_LOAD_OPT(c, inside_pointcloud_layer);
    MCP_LOAD_OPT(c, outside_pointcloud_layer);

    ASSERTMSG_(
        !inside_pointcloud_layer.empty() || !outside_pointcloud_layer.empty(),
        "At least one 'inside_pointcloud_layer' or "
        "'outside_pointcloud_layer' must be provided.");

    ASSERT_(
        c.has("bounding_box_min") && c["bounding_box_min"].isSequence() &&
        c["bounding_box_min"].asSequence().size() == 3);
    ASSERT_(
        c.has("bounding_box_max") && c["bounding_box_max"].isSequence() &&
        c["bounding_box_max"].asSequence().size() == 3);

    const auto bboxMin = c["bounding_box_min"].asSequence();
    const auto bboxMax = c["bounding_box_max"].asSequence();

    for (int i = 0; i < 3; i++)
    {
        parent.parseAndDeclareParameter(bboxMin.at(i).as<std::string>(), bounding_box.min[i]);
        parent.parseAndDeclareParameter(bboxMax.at(i).as<std::string>(), bounding_box.max[i]);
    }
}

FilterBoundingBox::FilterBoundingBox()
{
    mrpt::system::COutputLogger::setLoggerName("FilterBoundingBox");
}

void FilterBoundingBox::initialize_filter(const mrpt::containers::yaml& c)
{
    MRPT_START

    MRPT_LOG_DEBUG_STREAM("Loading these params:\n" << c);
    params.load_from_yaml(c, *this);

    MRPT_END
}

void FilterBoundingBox::filter(mp2p_icp::metric_map_t& inOut) const
{
    MRPT_START

    // In:
    const auto pcPtr = inOut.point_layer(params.input_pointcloud_layer);
    ASSERTMSG_(
        pcPtr,
        mrpt::format(
            "Input point cloud layer '%s' was not found.", params.input_pointcloud_layer.c_str()));

    const auto& pc = *pcPtr;

    // Create if new: Append to existing layer, if already existed.
    mrpt::maps::CPointsMap::Ptr insidePc = GetOrCreatePointLayer(
        inOut, params.inside_pointcloud_layer, true /*allow empty for nullptr*/,
        /* create cloud of the same type */
        pcPtr->GetRuntimeClass()->className);

    if (insidePc)
    {
        insidePc->reserve(insidePc->size() + pc.size() / 10);
    }

    mrpt::maps::CPointsMap::Ptr outsidePc = GetOrCreatePointLayer(
        inOut, params.outside_pointcloud_layer, true /*allow empty for nullptr*/,
        /* create cloud of the same type */
        pcPtr->GetRuntimeClass()->className);

    if (outsidePc)
    {
        outsidePc->reserve(outsidePc->size() + pc.size() / 10);
    }

    mrpt::maps::CPointsMap::InsertCtx ctxOutside, ctxInside;
    if (insidePc)
    {
        insidePc->registerPointFieldsFrom(pc);
        ctxInside = insidePc->prepareForInsertPointsFrom(pc);
        mp2p_icp::warn_on_field_padding_mismatch(pc, *insidePc, *this);
    }
    if (outsidePc)
    {
        outsidePc->registerPointFieldsFrom(pc);
        ctxOutside = outsidePc->prepareForInsertPointsFrom(pc);
        mp2p_icp::warn_on_field_padding_mismatch(pc, *outsidePc, *this);
    }

    const auto& xs = pc.getPointsBufferRef_x();
    const auto& ys = pc.getPointsBufferRef_y();
    const auto& zs = pc.getPointsBufferRef_z();

    for (size_t i = 0; i < xs.size(); i++)
    {
        const bool isInside = params.bounding_box.containsPoint({xs[i], ys[i], zs[i]});

        auto* targetPc = isInside ? insidePc.get() : outsidePc.get();
        auto* ctx      = isInside ? &ctxInside : &ctxOutside;
        if (targetPc)
        {
            targetPc->insertPointFrom(i, *ctx);
        }
    }

    MRPT_END
}
