/*               _
 _ __ ___   ___ | | __ _
| '_ ` _ \ / _ \| |/ _` | Modular Optimization framework for
| | | | | | (_) | | (_| | Localization and mApping (MOLA)
|_| |_| |_|\___/|_|\__,_| https://github.com/MOLAorg/mola

 A repertory of multi primitive-to-primitive (MP2P) ICP algorithms
 and map building tools. mp2p_icp is part of MOLA.

 Copyright (C) 2018-2026 Jose Luis Blanco, University of Almeria,
                         and individual contributors.
 SPDX-License-Identifier: BSD-3-Clause
*/
/**
 * @file   FilterDeskew.cpp
 * @brief  Deskew (motion compensate) a pointcloud from a moving LIDAR
 * @author Jose Luis Blanco Claraco
 * @date   Dec 13, 2023
 */

#if defined(MP2P_ICP_HAS_MOLA_IMU_PREINTEGRATION)
#include <mola_imu_preintegration/ImuIntegrationParams.h>
#include <mola_imu_preintegration/ImuTransformer.h>
#include <mola_imu_preintegration/trajectory_from_buffer.h>

#include <stdexcept>
#endif

#include <mp2p_icp/pointcloud_field_utils.h>
#include <mp2p_icp_filters/FilterDeskew.h>
#include <mp2p_icp_filters/GetOrCreatePointLayer.h>
#include <mrpt/containers/yaml.h>
#include <mrpt/core/Clock.h>
#include <mrpt/core/exceptions.h>
#include <mrpt/poses/Lie/SO.h>
#include <mrpt/version.h>

#if defined(MP2P_HAS_TBB)
#include <tbb/parallel_for.h>
#endif

IMPLEMENTS_MRPT_OBJECT(FilterDeskew, mp2p_icp_filters::FilterBase, mp2p_icp_filters)

using namespace mp2p_icp_filters;

FilterDeskew::FilterDeskew() { mrpt::system::COutputLogger::setLoggerName("FilterDeskew"); }

void FilterDeskew::initialize_filter(const mrpt::containers::yaml& c)
{
    MRPT_LOG_DEBUG_STREAM("Loading these params:\n" << c);

    MCP_LOAD_REQ(c, input_pointcloud_layer);
    MCP_LOAD_OPT(c, output_pointcloud_layer);

    MCP_LOAD_OPT(c, silently_ignore_no_timestamps);
    MCP_LOAD_OPT(c, output_layer_class);
    MCP_LOAD_OPT(c, method);
    MCP_LOAD_OPT(c, in_place);

    MCP_LOAD_OPT(c, points_already_global);
    MCP_LOAD_OPT(c, ignore_accelerometer);

    auto handleVectorParam = [&](const std::string& key, auto& vec, const std::size_t dim)
    {
        if (c.has(key))
        {
            ASSERT_(c[key].isSequence() && c[key].asSequence().size() == dim);
            const auto& seq = c[key].asSequenceRange();

            for (size_t i = 0; i < dim; i++)
            {
                parseAndDeclareParameter(seq.at(i).as<std::string>(), vec[i]);
            }
        }
    };

    handleVectorParam("robot_pose", robot_pose, 6);

    handleVectorParam("bias_acc", bias_acc, 3);
    handleVectorParam("bias_gyro", bias_gyro, 3);
    handleVectorParam("gravity_vector", gravity_vector, 3);

    if (in_place)
    {
        ASSERTMSG_(
            output_pointcloud_layer.empty(),
            "If using `in_place=true`, `output_pointcloud_layer` cannot be defined.");
    }
    else
    {
        ASSERTMSG_(
            !output_pointcloud_layer.empty(),
            "If using `in_place=false`, `output_pointcloud_layer` must be defined.");
    }

    if (c.has("twist"))
    {
        twist.emplace();  // Define a constant twist model for deskewing

        handleVectorParam("twist", *twist, 6);
    }
}

// Minimal fake class for when building without IMU library:
#if !defined(MP2P_ICP_HAS_MOLA_IMU_PREINTEGRATION)
namespace mola::imu
{
struct TrajectoryPoint
{
};
using Trajectory = std::map<double, TrajectoryPoint>;
}  // namespace mola::imu
#endif

namespace
{
#if defined(MP2P_ICP_HAS_MOLA_IMU_PREINTEGRATION)

auto findBeforeAfter(const mola::imu::Trajectory& trajectory, const double t)
    -> std::pair<mola::imu::Trajectory::const_iterator, mola::imu::Trajectory::const_iterator>
{
    using Iterator = mola::imu::Trajectory::const_iterator;

    // Don't check for "!trajectory.empty()", it's done in the caller.

    Iterator lower = trajectory.lower_bound(t);

    if (lower == trajectory.end())
    {
        // key is larger than all elements
        Iterator last = std::prev(trajectory.end());
        return {last, last};
    }

    if (lower->first == t)
    {
        // Exact match: before = prev, after = next (clamped)
        Iterator before = (lower == trajectory.begin()) ? lower : std::prev(lower);
        Iterator after  = std::next(lower);
        if (after == trajectory.end())
        {
            after = lower;
        }
        return {before, after};
    }

    if (lower == trajectory.begin())
    {
        // key is smaller than all elements
        return {lower, lower};
    }

    // General case: key lies between prev(lower) and lower
    Iterator before = std::prev(lower);
    return {before, lower};
}
#endif  // MP2P_ICP_HAS_MOLA_IMU_PREINTEGRATION

struct CorrectPointsArguments
{
    mrpt::aligned_std_vector<float>&       xs;
    mrpt::aligned_std_vector<float>&       ys;
    mrpt::aligned_std_vector<float>&       zs;
    size_t                                 n;
    size_t                                 n0;
    const mrpt::aligned_std_vector<float>* Ts;
    mrpt::maps::CPointsMap*                outPc              = nullptr;
    mrpt::maps::CPointsMap::InsertCtx*     ctxCopyPointFields = nullptr;
    const mrpt::math::TTwist3D*            constant_twist;
    const mola::imu::Trajectory&           reconstructed_trajectory;
    bool                                   points_already_global;
    const mrpt::math::TPose3D&             global_robot_pose;
};

// Optimized templated version for compile-time optimization for each method
template <MotionCompensationMethod method>
void correctPointsLoop(const CorrectPointsArguments& args)
{
    // Capturing these bindings requires C++20.
    auto& [xs, ys, zs, n, n0, Ts, outPc, ctxCopyPointFields, constant_twist, reconstructed_trajectory, points_already_global, global_robot_pose_t] =
        args;

    const auto global_robot_pose = mrpt::poses::CPose3D(global_robot_pose_t);

    const bool in_place = (outPc == nullptr);

    if (!in_place)
    {
        ASSERT_(ctxCopyPointFields != nullptr);
    }

    ASSERT_(Ts != nullptr);
    ASSERT_EQUAL_(Ts->size(), xs.size());

    // Note: emptiness of reconstructed_trajectory is checked by the caller
    // (FilterDeskew::filter), which gracefully bypasses deskew with a
    // throttled warning instead of throwing, to keep robustness against
    // transient sensor data gaps.

    // Is it worth to first build a cache with unique point stamps to pose corrections?
    // From initial benchmarking, it seems it doesn't...

#if defined(MP2P_HAS_TBB)
    tbb::parallel_for(
        static_cast<size_t>(0), n,
        [&](size_t i)
#else
    for (size_t i = 0; i < n; i++)
#endif
        {
            const auto pt = mrpt::math::TPoint3Df(xs[i], ys[i], zs[i]);
            if (pt.x == 0 && pt.y == 0 && pt.z == 0)
            {
#if defined(MP2P_HAS_TBB)
                return;
#else
            continue;
#endif
            }

            mrpt::poses::CPose3D pose_increment;

            // Compile-time "switch":
            if constexpr (method == MotionCompensationMethod::Linear)
            {
                // Forward integrate constant twist:
                const auto v = mrpt::math::TVector3D(
                    constant_twist->vx, constant_twist->vy, constant_twist->vz);
                const auto w = mrpt::math::TVector3D(
                    constant_twist->wx, constant_twist->wy, constant_twist->wz);

                const mrpt::math::TVector3D v_dt = v * (*Ts)[i];
                const mrpt::math::TVector3D w_dt = w * (*Ts)[i];

                pose_increment = mrpt::poses::CPose3D::FromRotationAndTranslation(
                    // Rotation: From Lie group SO(3) exponential:
                    mrpt::poses::Lie::SO<3>::exp(mrpt::math::CVectorFixedDouble<3>(w_dt)),
                    // Translation: simple constant velocity model:
                    v_dt);
            }
#if defined(MP2P_ICP_HAS_MOLA_IMU_PREINTEGRATION)
            else if constexpr (method == MotionCompensationMethod::IMU)
            {
                const auto t_point    = (*Ts)[i];
                const auto [it0, it1] = findBeforeAfter(reconstructed_trajectory, t_point);

                const auto   t_prev  = it0->first;
                const double dt      = t_point - t_prev;
                const auto&  tp_prev = it0->second;

                if (std::abs(dt) > 0.1)
                {
                    thread_local double last_warning = mrpt::Clock::nowDouble();
                    const auto          tNow         = mrpt::Clock::nowDouble();
                    if (tNow - last_warning > 5.0)
                    {
                        last_warning = tNow;
                        fprintf(
                            stderr,
                            "[FilterDeskew|WARN]: Excessive time between point stamp and "
                            "trajectory point (dt=%.03f s)\n",
                            dt);
                    }
                }

                // v was already in the t=0 frame of reference:
                const mrpt::math::TVector3D v_dt = *tp_prev.v * dt;
                const mrpt::math::TVector3D w_dt = *tp_prev.w_b * dt;

                pose_increment = mrpt::poses::CPose3D::FromRotationAndTranslation(
                    // Rotation: From Lie group SO(3) exponential:
                    tp_prev.pose.getRotationMatrix() *
                        mrpt::poses::Lie::SO<3>::exp(mrpt::math::CVectorFixedDouble<3>(w_dt)),
                    // Translation: simple constant velocity model:
                    tp_prev.pose.translation() + v_dt);
            }
            else if constexpr (method == MotionCompensationMethod::IMUt)
            {
                const auto t_point    = (*Ts)[i];
                const auto [it0, it1] = findBeforeAfter(reconstructed_trajectory, t_point);

                const auto   t_prev  = it0->first;
                const double dt      = t_point - t_prev;
                const auto&  tp_prev = it0->second;
                const auto&  tp_next = it1->second;

                // v was already in the t=0 frame of reference:
                const mrpt::math::TVector3D v_dt = (*tp_prev.v + *tp_next.v) * dt * 0.5;
                const mrpt::math::TVector3D w_dt = (*tp_prev.w_b + *tp_next.w_b) * dt * 0.5;

                pose_increment = mrpt::poses::CPose3D::FromRotationAndTranslation(
                    // Rotation: From Lie group SO(3) exponential:
                    tp_prev.pose.getRotationMatrix() *
                        mrpt::poses::Lie::SO<3>::exp(mrpt::math::CVectorFixedDouble<3>(w_dt)),
                    // Translation: simple constant velocity model:
                    tp_prev.pose.translation() + v_dt);
            }
            else if constexpr (method == MotionCompensationMethod::IMUh)
            {
                const auto t_point    = (*Ts)[i];
                const auto [it0, it1] = findBeforeAfter(reconstructed_trajectory, t_point);

                const auto   t_prev  = it0->first;
                const double dt      = t_point - t_prev;
                const double dt2     = dt * dt;
                const double dt3     = dt2 * dt;
                const auto&  tp_prev = it0->second;

                // v was already in the t=0 frame of reference:
                const mrpt::math::TVector3D delta_t =
                    *tp_prev.v * dt +
                    tp_prev.pose.rotateVector(
                        tp_prev.ac_b.value() * 0.5 * dt2 + tp_prev.j_b * (1.0 / 6.0) * dt3);

                const mrpt::math::TVector3D delta_w =
                    *tp_prev.w_b * dt + tp_prev.alpha_b * 0.5 * dt2;

                pose_increment = mrpt::poses::CPose3D::FromRotationAndTranslation(
                    // Rotation: From Lie group SO(3) exponential:
                    tp_prev.pose.getRotationMatrix() *
                        mrpt::poses::Lie::SO<3>::exp(mrpt::math::CVectorFixedDouble<3>(delta_w)),
                    // Translation: simple constant velocity model:
                    tp_prev.pose.translation() + delta_t);
            }
#endif
            else
            {
                // Should never arrive here
                THROW_EXCEPTION("Unhandled MotionCompensationMethod method (!)");
            }

            // Correct point XYZ coordinates.
            mrpt::math::TPoint3Df corrPt;

            if (!points_already_global)
            {
                // Simple case: points are local wrt the vehicle:
                corrPt = pose_increment.composePoint(pt).cast<float>();
            }
            else
            {
                // Points are already projected into global coordinates.
                // We must apply the deskew correction to the local point coordinates and project
                // again:
                const auto localPt = global_robot_pose.inverseComposePoint(pt.cast<double>());
                corrPt = (global_robot_pose + pose_increment).composePoint(localPt).cast<float>();
            }

            if (in_place)
            {
                xs[i] = corrPt.x;
                ys[i] = corrPt.y;
                zs[i] = corrPt.z;
            }
            else
            {
                outPc->setPointFast(n0 + i, corrPt.x, corrPt.y, corrPt.z);

                // Copy additional fields using the insertion context:
                for (auto& [src, dst] : ctxCopyPointFields->double_fields)
                {
                    (*dst)[n0 + i] = src ? (*src)[i] : 0.0;
                }
                for (auto& [src, dst] : ctxCopyPointFields->uint8_fields)
                {
                    (*dst)[n0 + i] = src ? (*src)[i] : uint8_t{0};
                }
                for (auto& [src, dst] : ctxCopyPointFields->float_fields)
                {
                    (*dst)[n0 + i] = src ? (*src)[i] : 0.0f;
                }
                for (auto& [src, dst] : ctxCopyPointFields->uint16_fields)
                {
                    (*dst)[n0 + i] = src ? (*src)[i] : uint16_t{0};
                }
            }
        }
#if defined(MP2P_HAS_TBB)
    );
#endif
}

}  // namespace

void FilterDeskew::filter(mp2p_icp::metric_map_t& inOut) const
{
    MRPT_START

    checkAllParametersAreRealized();

    // Create if new: Append to existing layer, if already existed.
    mrpt::maps::CPointsMap::Ptr outPc;
    if (!in_place)
    {
        outPc = GetOrCreatePointLayer(
            inOut, output_pointcloud_layer, false /*dont allow empty names*/, output_layer_class);
    }

    // In:
    ASSERT_(!input_pointcloud_layer.empty());

    mrpt::maps::CPointsMap* inPc = nullptr;

    if (auto itLy = inOut.layers.find(input_pointcloud_layer); itLy != inOut.layers.end())
    {
        inPc = mp2p_icp::MapToPointsMap(*itLy->second);
        if (!inPc)
        {
            THROW_EXCEPTION_FMT(
                "Layer '%s' must be of point cloud type.", input_pointcloud_layer.c_str());
        }

        // Reserve memory in output layer:
        if (!in_place)
        {
            outPc->reserve(outPc->size() + inPc->size());
        }
    }
    else
    {
        // Input layer doesn't exist:
        THROW_EXCEPTION_FMT(
            "Input layer '%s' not found on input map.", input_pointcloud_layer.c_str());
    }

    // optional fields: get insertion context only if we are not doing in-place correction:
    std::optional<mrpt::maps::CPointsMap::InsertCtx> insert_ctx;
    if (outPc)
    {
        // Copy all point fields from the source:
        outPc->registerPointFieldsFrom(*inPc);

        // and then, prepare structures for fast copying:
        insert_ctx = outPc->prepareForInsertPointsFrom(*inPc);
        mp2p_icp::warn_on_field_padding_mismatch(*inPc, *outPc, *this);
    }

    // If the input is empty, just move on:
    if (inPc->empty())
    {
        MRPT_LOG_DEBUG_STREAM(
            "Silently ignoring empty input layer: '" << input_pointcloud_layer << "'");
        return;
    }

    MRPT_LOG_DEBUG_STREAM("Running on input layer: " << inPc->asString());

    // mandatory fields:
    auto&        xs = const_cast<mrpt::aligned_std_vector<float>&>(inPc->getPointsBufferRef_x());
    auto&        ys = const_cast<mrpt::aligned_std_vector<float>&>(inPc->getPointsBufferRef_y());
    auto&        zs = const_cast<mrpt::aligned_std_vector<float>&>(inPc->getPointsBufferRef_z());
    const size_t n  = xs.size();

    const auto* Ts = inPc->getPointsBufferRef_float_field("t");

    // A "t" field with all points sharing the exact same value (e.g. an
    // idealized "flash" LiDAR simulator that captures the whole cloud at a
    // single instant, such as MVSIM's Lidar3D) carries zero span: there is
    // nothing to compensate for (every point really was captured at the same
    // time), so treat it exactly like "no timestamps" below rather than
    // falling through to the IMU/twist reconstruction path with a
    // degenerate, zero-width time window (that path would need a *span* of
    // per-point times to reconstruct a sub-scan trajectory, and a zero-width
    // window is fragile to float/double rounding in the reference-time
    // comparison, causing deskew to spuriously "fail" every single scan).
    const bool hasZeroTimeSpan = Ts && !Ts->empty() &&
                                 (*std::max_element(Ts->cbegin(), Ts->cend()) ==
                                  *std::min_element(Ts->cbegin(), Ts->cend()));

    // No (meaningful) timestamps available, or deskewing disabled:
    const bool noTimestamps   = !Ts || Ts->empty() || hasZeroTimeSpan;
    const bool deskewDisabled = (method == MotionCompensationMethod::None);

    if (noTimestamps || deskewDisabled)
    {
        if (silently_ignore_no_timestamps || deskewDisabled || hasZeroTimeSpan)
        {
            if (!in_place)
            {
                outPc->insertAnotherMap(inPc, mrpt::poses::CPose3D::Identity());
            }

            if (!deskewDisabled)
            {
                MRPT_LOG_DEBUG_STREAM(
                    "Skipping de-skewing in input cloud '"
                    << input_pointcloud_layer << "' with contents: " << inPc->asString());
            }
            return;
        }

        THROW_EXCEPTION_FMT(
            "Input layer '%s' does not contain per-point timestamps, cannot do scan deskew. Set "
            "'silently_ignore_no_timestamps=true' to skip de-skew. Input map contents: '%s'",
            input_pointcloud_layer.c_str(), inPc->asString().c_str());
    }

    ASSERT_EQUAL_(Ts->size(), n);

    // Yes, we have timestamps, apply de-skew:
    const size_t n0 = outPc ? outPc->size() : 0;
    if (outPc)
    {
        outPc->resize(n0 + n);
    }

    // Used for precise deskew-only. This contains relative poses of the vehicle frame ("base_link")
    // with t=0 being the reference time when t=0 in the point cloud timestamp field:
    mola::imu::Trajectory reconstructed_trajectory;

#if defined(MP2P_ICP_HAS_MOLA_IMU_PREINTEGRATION)
    mola::imu::ImuIntegrationParams imu_params;
    imu_params.bias_acc       = bias_acc;
    imu_params.bias_gyro      = bias_gyro;
    imu_params.gravity_vector = gravity_vector;
#endif

    const mrpt::math::TTwist3D* constant_twist = nullptr;

    // Set if trajectory reconstruction threw: used below to avoid emitting a
    // second, misleading "empty buffer" warning for the same failure.
    bool trajectory_reconstruction_failed = false;

    switch (method)
    {
        case MotionCompensationMethod::IMU:
        case MotionCompensationMethod::IMUh:
        case MotionCompensationMethod::IMUt:
        {
#if defined(MP2P_ICP_HAS_MOLA_IMU_PREINTEGRATION)
            const auto* ps = attachedSource();
            ASSERTMSG_(ps, "A ParameterSource must be attached if IMU-based methods are enabled");

            const auto [it_min, it_max] = std::minmax_element(Ts->cbegin(), Ts->cend());
            ASSERT_(it_min != Ts->cend());
            ASSERT_(it_max != Ts->cend());

            const double scan_time_span = *it_max - *it_min;

            // Recall, the reference time should have been set already by the Generator and/or
            // FilterAdjustTimestamps:
            // Note: "non-const" just for the "ignore_accelerometer" filter below.
            auto sample_history =
                ps->localVelocityBuffer.collect_samples_around_reference_time(2 * scan_time_span);

            const bool use_higher_order = (method == MotionCompensationMethod::IMUh);

            if (!sample_history.by_time.empty())
            {
                // Optionally suppress accelerometer contribution entirely.
                // Zeroing a_b here makes trajectory_from_buffer integrate with
                // ac_b = gravity_b only (gravity cancels out in the body frame),
                // reducing position integration to gyro + constant-velocity-per-interval.
                // This avoids lever-arm noise from corrupting the deskew path when the
                // IMU/LiDAR offset is large and the accelerometer signal is unreliable.
                if (ignore_accelerometer)
                {
                    // Zero every a_b in by_type (used by find_closest fallback in
                    // trajectory_from_buffer) — do NOT clear the map, as find_closest
                    // on an empty map would crash.
                    for (auto& [stamp, val] : sample_history.by_type.a_b)
                    {
                        val = {0, 0, 0};
                    }
                    for (auto& [stamp, sample] : sample_history.by_time)
                    {
                        sample.a_b = {0, 0, 0};
                    }
                }

                // Defense-in-depth: trajectory_from_buffer() reports insufficient
                // sensor data by returning an empty trajectory, which is handled
                // gracefully below. Catch any other unexpected exception too and
                // funnel it into the same skip path, so a transient integration
                // failure never crashes the whole pipeline.
                try
                {
                    reconstructed_trajectory = mola::imu::trajectory_from_buffer(
                        sample_history, imu_params, use_higher_order);
                }
                catch (const std::exception& e)
                {
                    trajectory_reconstruction_failed = true;
                    reconstructed_trajectory.clear();

                    thread_local double last_warning_t = 0;
                    const auto          tNow           = mrpt::Clock::nowDouble();
                    if (tNow - last_warning_t > 5.0)
                    {
                        last_warning_t = tNow;
                        MRPT_LOG_WARN_STREAM(
                            "Exception while reconstructing trajectory for deskew; "
                            "skipping deskew for this scan. Details: "
                            << e.what());
                    }
                }
            }

#if 0  // For *really* in-depth debugging
            std::cout << "\n\n ==== INPUT BUFFER:\n" << ps->localVelocityBuffer.toYAML();
            std::cout << "\n\n ==== INPUT SAMPLES:\n" << sample_history.by_type.asString();
            std::cout << "\n\n ==== RECONSTRUCTED:\n"
                      << mola::imu::trajectory_as_string(reconstructed_trajectory);
            std::cout << "\n\n\n ------------------------------------------ \n";
#endif

#else
            THROW_EXCEPTION(
                "Only Linear deskew method is available when building mp2p_icp without "
                "mola_imu_preintegration");
#endif
        }
        break;

        case MotionCompensationMethod::Linear:
        {
            ASSERTMSG_(
                twist.has_value(),
                "`MotionCompensationMethod::Linear` needs defining a constant 'twist' field in "
                "this filter parameters");

            constant_twist = &twist.value();
        }
        break;

        case mp2p_icp_filters::MotionCompensationMethod::None:
        {
            // Should have been handled above!
            THROW_EXCEPTION("Shouldn't reach here!");
            break;
        }
    };

    // Graceful degradation: if an IMU-based method was selected but the local
    // velocity buffer yielded no trajectory (e.g., a transient sensor data
    // gap), skip deskew for this scan rather than throwing. Points are copied
    // through uncorrected, with a throttled WARN trace so users can see it
    // happening without flooding the log.
    const bool needsTrajectory = (method == MotionCompensationMethod::IMU) ||
                                 (method == MotionCompensationMethod::IMUh) ||
                                 (method == MotionCompensationMethod::IMUt);

    if (needsTrajectory && reconstructed_trajectory.empty())
    {
        // Skip this warning if reconstruction threw: the catch above already
        // logged the actual cause, and blaming an empty buffer here would be
        // misleading.
        if (!trajectory_reconstruction_failed)
        {
            thread_local double last_warning_t = 0;
            const auto          tNow           = mrpt::Clock::nowDouble();
            if (tNow - last_warning_t > 5.0)
            {
                last_warning_t = tNow;
                MRPT_LOG_WARN_STREAM(
                    "Local velocity buffer is empty (likely a transient sensor "
                    "data gap); skipping deskew for this scan. Points will be "
                    "passed through uncorrected.");
            }
        }

        if (!in_place)
        {
            // Resize back: we will let insertAnotherMap handle the append
            // (which manages size and per-point fields consistently).
            outPc->resize(n0);
            outPc->insertAnotherMap(inPc, mrpt::poses::CPose3D::Identity());
        }
        return;
    }

    // Prepare call arguments:
    const CorrectPointsArguments args = {
        xs,
        ys,
        zs,
        n,
        n0,
        Ts,
        outPc.get(),
        insert_ctx ? &(*insert_ctx) : nullptr,
        constant_twist,
        reconstructed_trajectory,
        points_already_global,
        robot_pose};

    // compile-time optimized code for each method:
    switch (method)
    {
        case MotionCompensationMethod::Linear:
            correctPointsLoop<MotionCompensationMethod::Linear>(args);
            break;

        case MotionCompensationMethod::IMU:
            correctPointsLoop<MotionCompensationMethod::IMU>(args);
            break;

        case MotionCompensationMethod::IMUh:
            correctPointsLoop<MotionCompensationMethod::IMUh>(args);
            break;

        case MotionCompensationMethod::IMUt:
            correctPointsLoop<MotionCompensationMethod::IMUt>(args);
            break;

        default:
            // Should never arrive here
            throw std::runtime_error("Unknown MotionCompensationMethod method");
    }

    MRPT_END
}
