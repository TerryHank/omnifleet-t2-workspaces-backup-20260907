/*               _
 _ __ ___   ___ | | __ _
| '_ ` _ \ / _ \| |/ _` | Modular Optimization framework for
| | | | | | (_) | | (_| | Localization and mApping (MOLA)
|_| |_| |_|\___/|_|\__,_| https://github.com/MOLAorg/mola

 A repertory of multi primitive-to-primitive (MP2P) ICP algorithms
 and map building tools. mp2p_icp is part of MOLA.

 Copyright (C) 2018-2026 Jose Luis Blanco, University of Almeria,
                         and individual contributors.
 SPDX-License-Identifier: BSD-3-Clause
*/
/**
 * @file   metric_map.cpp
 * @brief  Generic representation of pointcloud(s) and/or extracted features.
 * @author Jose Luis Blanco Claraco
 * @date   Jun 10, 2019
 */

#include <mp2p_icp/MetricMapMergeCapable.h>
#include <mp2p_icp/metricmap.h>
#include <mrpt/containers/yaml.h>
#include <mrpt/maps/CGenericPointsMap.h>
#include <mrpt/maps/CVoxelMap.h>
#include <mrpt/maps/CVoxelMapRGB.h>
#include <mrpt/obs/customizable_obs_viz.h>
#include <mrpt/opengl/CGridPlaneXY.h>
#include <mrpt/opengl/CPointCloud.h>
#include <mrpt/opengl/CPointCloudColoured.h>
#include <mrpt/opengl/CSetOfLines.h>
#include <mrpt/opengl/CSetOfObjects.h>
#include <mrpt/serialization/CArchive.h>
#include <mrpt/serialization/optional_serialization.h>
#include <mrpt/serialization/stl_serialization.h>
#include <mrpt/system/string_utils.h>  // unitsFormat()
#include <mrpt/version.h>

#if MRPT_VERSION >= 0x020f07
#include <mrpt/io/CCompressedInputStream.h>
#include <mrpt/io/CCompressedOutputStream.h>
#else
#include <mrpt/io/CFileGZInputStream.h>
#include <mrpt/io/CFileGZOutputStream.h>
#endif

#include <algorithm>
#include <cmath>
#include <iterator>
#include <sstream>

IMPLEMENTS_MRPT_OBJECT(metric_map_t, mrpt::serialization::CSerializable, mp2p_icp)

using namespace mp2p_icp;

namespace
{
/** Returns a copy of `src` holding only its finite points, or an empty smart
 *  pointer if every point is already finite (so callers can keep using the
 *  original map and pay no copy in the usual case).
 *
 *  Some point map classes expose storage slots that hold no point: e.g.
 *  mola::IncrementalPointCloud blanks recycled slots to NaN so that generic
 *  code walking the inherited buffers does not resurrect evicted geometry.
 *  MRPT's point cloud render objects copy such slots verbatim, and a single
 *  non-finite coordinate makes the LOD octree split criterion degenerate: the
 *  node mean becomes NaN, every comparison against it is false, so all points
 *  land in the same child and the recursive split never terminates.
 */
mrpt::maps::CPointsMap::Ptr onlyFinitePoints(const mrpt::maps::CPointsMap& src)
{
    const auto&  xs = src.getPointsBufferRef_x();
    const auto&  ys = src.getPointsBufferRef_y();
    const auto&  zs = src.getPointsBufferRef_z();
    const size_t n  = src.size();

    const auto isFinitePt = [&](size_t i)
    { return std::isfinite(xs[i]) && std::isfinite(ys[i]) && std::isfinite(zs[i]); };

    size_t nFinite = 0;
    for (size_t i = 0; i < n; i++)
    {
        if (isFinitePt(i)) nFinite++;
    }

    if (nFinite == n) return {};  // usual case: nothing to filter out

    auto out = mrpt::maps::CGenericPointsMap::Create();
    out->reserve(nFinite);
    out->registerPointFieldsFrom(src);

    const auto ctx = out->prepareForInsertPointsFrom(src);
    for (size_t i = 0; i < n; i++)
    {
        if (isFinitePt(i)) out->insertPointFrom(i, ctx);
    }

    return out;
}

inline bool isFiniteXYZ(const mrpt::math::TPoint3Df& p)
{
    return std::isfinite(p.x) && std::isfinite(p.y) && std::isfinite(p.z);
}

/** Drops the non-finite points of an already-built render object, in place,
 *  keeping each surviving point's own color.
 *
 *  This is the counterpart of onlyFinitePoints() for the render path that
 *  delegates to the map's own getVisualizationInto(): there the map draws
 *  itself, so there is no source cloud to filter beforehand, and replacing it
 *  with a filtered copy would lose the very renderer that path exists to use.
 */
void dropNonFinitePoints(mrpt::opengl::CPointCloudColoured& glPts)
{
    const size_t n   = glPts.size();
    size_t       dst = 0;
    for (size_t src = 0; src < n; src++)
    {
        const auto p = glPts.getPoint3Df(src);
        if (!isFiniteXYZ(p)) continue;

        if (dst != src)
        {
            const auto c = glPts.getPointColor(src);
            glPts.setPoint_fast(dst, {p.x, p.y, p.z, c.R, c.G, c.B, c.A});
        }
        dst++;
    }
    if (dst != n) glPts.resize(dst);
}

void dropNonFinitePoints(mrpt::opengl::CPointCloud& glPts)
{
    const size_t n   = glPts.size();
    size_t       dst = 0;
    for (size_t src = 0; src < n; src++)
    {
        const auto p = glPts[src];
        if (!isFiniteXYZ(p)) continue;

        if (dst != src) glPts.setPoint_fast(dst, p.x, p.y, p.z);
        dst++;
    }
    if (dst != n) glPts.resize(dst);
}
}  // namespace

// Implementation of the CSerializable virtual interface:
uint8_t metric_map_t::serializeGetVersion() const { return 5; }
void    metric_map_t::serializeTo(mrpt::serialization::CArchive& out) const
{
    out << lines;

    out.WriteAs<uint32_t>(planes.size());
    for (const auto& p : planes)
    {
        out << p.plane << p.centroid;
    }

    out.WriteAs<uint32_t>(lines.size());
    for (const auto& l : lines)
    {
        out << l;
    }

    out.WriteAs<uint32_t>(layers.size());
    for (const auto& l : layers)
    {
        out << l.first << *l.second.get();
    }

    out << id << label;  // new in v1

    // new in v4: delegate to external function:
    out << georeferencing;

    // new in v5:
    bool hasMetadata = !metadata.isNullNode() && !metadata.empty();
    out << hasMetadata;
    if (hasMetadata)
    {
        std::stringstream ss;
        metadata.printAsYAML(ss);
        out << ss.str();
    }

    // Optional user data:
    derivedSerializeTo(out);
}
void metric_map_t::serializeFrom(mrpt::serialization::CArchive& in, uint8_t version)
{
    switch (version)
    {
        case 0:
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        {
            in >> lines;
            const auto nPls = in.ReadAs<uint32_t>();
            planes.resize(nPls);
            for (auto& pl : planes)
            {
                in >> pl.plane >> pl.centroid;
            }

            const auto nLins = in.ReadAs<uint32_t>();
            lines.resize(nLins);
            for (auto& l : lines)
            {
                in >> l;
            }

            const auto nPts = in.ReadAs<uint32_t>();
            layers.clear();
            for (std::size_t i = 0; i < nPts; i++)
            {
                std::string name;
                in >> name;
                layers[name] = mrpt::ptr_cast<mrpt::maps::CMetricMap>::from(in.ReadObject());
            }

            if (version >= 1)
            {
                in >> id >> label;
            }
            else
            {
                id.reset();
                label.reset();
            }

            georeferencing.reset();

            if ((version >= 2 && version < 4) && in.ReadAs<bool>())
            {
                auto& g = georeferencing.emplace();
                in >> g.geo_coord.lat.decimal_value >> g.geo_coord.lon.decimal_value >>
                    g.geo_coord.height;
                if (version >= 3)
                {
                    in >> g.T_enu_to_map;
                }
                else
                {
                    in >> g.T_enu_to_map.mean;
                }
            }

            // delegated function:
            if (version >= 4)
            {
                in >> georeferencing;
            }

            metadata.clear();
            if (version >= 5)
            {
                // new in v5:
                const bool hasMetadata = in.ReadAs<bool>();
                if (hasMetadata)
                {
                    std::string metadata_str;
                    in >> metadata_str;
                    std::stringstream ss(metadata_str);
                    metadata.loadFromStream(ss);
                }
            }

            // Optional user data:
            derivedSerializeFrom(in);
        }
        break;
        default:
            MRPT_THROW_UNKNOWN_SERIALIZATION_VERSION(version);
    };
}

auto metric_map_t::get_visualization(const render_params_t& p) const
    -> std::shared_ptr<mrpt::opengl::CSetOfObjects>
{
    MRPT_START
    auto o = mrpt::opengl::CSetOfObjects::Create();

    get_visualization_planes(*o, p.planes);
    get_visualization_lines(*o, p.lines);
    get_visualization_points(*o, p.points);

    return o;
    MRPT_END
}

void metric_map_t::get_visualization_planes(
    mrpt::opengl::CSetOfObjects& o, const render_params_planes_t& p) const
{
    MRPT_START
    if (!p.visible)
    {
        return;
    }

    const auto pw = static_cast<float>(p.halfWidth);
    const auto pf = static_cast<float>(p.gridSpacing);

    for (const auto& plane : planes)
    {
        auto gl_pl = mrpt::opengl::CGridPlaneXY::Create(-pw, pw, -pw, pw, .0, pf);
        gl_pl->setColor_u8(p.color);
        mrpt::math::TPose3D planePose;
        plane.plane.getAsPose3DForcingOrigin(plane.centroid, planePose);
        gl_pl->setPose(planePose);
        o.insert(gl_pl);
    }

    MRPT_END
}

void metric_map_t::get_visualization_lines(
    mrpt::opengl::CSetOfObjects& o, const render_params_lines_t& p) const
{
    MRPT_START

    auto glLin = mrpt::opengl::CSetOfLines::Create();
    glLin->setColor_u8(p.color);

    for (size_t idxLine = 0; idxLine < lines.size(); idxLine++)
    {
        const auto& line    = lines[idxLine];
        double      linLen  = p.length;
        const auto  halfSeg = line.director * (0.5 * linLen);
        glLin->appendLine(line.pBase - halfSeg, line.pBase + halfSeg);
    }
    o.insert(glLin);

    MRPT_END
}

void metric_map_t::get_visualization_points(
    mrpt::opengl::CSetOfObjects& o, const render_params_points_t& p) const
{
    MRPT_START
    // Planes:
    if (!p.visible)
    {
        return;
    }

    if (!p.perLayer.empty())
    {
        // render only these layers:
        for (const auto& kv : p.perLayer)
        {
            const auto itPts = layers.find(kv.first);
            if (itPts == layers.end())
            {
                THROW_EXCEPTION_FMT(
                    "Rendering parameters given for layer '%s' which does not "
                    "exist in this metric_map_t object",
                    kv.first.c_str());
            }

            get_visualization_map_layer(o, kv.second, itPts->second);
        }
    }
    else
    {
        // render all layers with the same params:
        for (const auto& kv : layers)
        {
            get_visualization_map_layer(o, p.allLayers, kv.second);
        }
    }

    MRPT_END
}

void metric_map_t::get_visualization_map_layer(
    mrpt::opengl::CSetOfObjects& o, const render_params_point_layer_t& p,
    const mrpt::maps::CMetricMap::Ptr& map)
{
    mrpt::maps::CPointsMap::Ptr pts;

    auto voxelMap    = std::dynamic_pointer_cast<mrpt::maps::CVoxelMap>(map);
    auto voxelRGBMap = std::dynamic_pointer_cast<mrpt::maps::CVoxelMapRGB>(map);
    if (voxelMap || voxelRGBMap)
    {
        if (p.render_voxelmaps_as_points)
        {
            // get occupied voxel XYZ coordinates only:
            if (voxelMap)
            {
                pts = voxelMap->getOccupiedVoxels();
            }
            if (voxelRGBMap)
            {
                pts = voxelRGBMap->getOccupiedVoxels();
            }
        }
        else
        {
            // Render as real voxelmaps:
            if (voxelMap)
            {
                voxelMap->renderingOptions.generateFreeVoxels = p.render_voxelmaps_free_space;
            }
            else if (voxelRGBMap)
            {
                voxelRGBMap->renderingOptions.generateFreeVoxels = p.render_voxelmaps_free_space;
            }

            // regular render method:
            map->getVisualizationInto(o);
            return;
        }
    }
    else
    {
        pts = std::dynamic_pointer_cast<mrpt::maps::CPointsMap>(map);
    }

    if (!pts || (p.colorMode.has_value() && p.colorMode->keep_original_cloud_color))
    {
        // Not convertible to point maps or user selected their original colors,
        // use its own default renderer:
        map->getVisualizationInto(o);

        // apply the point size to ALL point cloud objects (a map type such as
        // KeyframePointCloudMap inserts one object per keyframe), and drop the
        // non-finite points the map may have drawn (see dropNonFinitePoints()):
        for (size_t ith = 0;; ith++)
        {
            auto glPtsCol = o.getByClass<mrpt::opengl::CPointCloudColoured>(ith);
            if (!glPtsCol)
            {
                break;
            }
            dropNonFinitePoints(*glPtsCol);
            glPtsCol->setPointSize(p.pointSize);
            if (p.force_alpha_channel)
            {
                glPtsCol->setAllPointsAlpha(p.color.A);
            }
        }
        for (size_t ith = 0;; ith++)
        {
            auto glPts = o.getByClass<mrpt::opengl::CPointCloud>(ith);
            if (!glPts)
            {
                break;
            }
            dropNonFinitePoints(*glPts);
            glPts->setPointSize(p.pointSize);
        }

        return;
    }

    if (pts && pts->empty())
    {
        // quick return if empty point cloud
        return;
    }

    // Both render paths below copy the raw point buffers into an OpenGL object
    // that cannot cope with non-finite coordinates (see onlyFinitePoints()).
    // Filtering the *source* map, rather than the render object, is what keeps
    // the point counts of the two equal, as recolorize3Dpc() requires.
    if (auto finitePts = onlyFinitePoints(*pts); finitePts)
    {
        pts = finitePts;
        if (pts->empty()) return;
    }

    if (p.colorMode.has_value())
    {
        // color point cloud:
        auto glPts = mrpt::opengl::CPointCloudColoured::Create();
        glPts->loadFromPointsMap(pts.get());

        glPts->setPointSize(p.pointSize);
        if (p.force_alpha_channel)
        {
            glPts->setAllPointsAlpha(p.color.A);
        }

        ASSERT_(p.colorMode->recolorizeByField.has_value());

        mrpt::obs::PointCloudRecoloringParameters vizParams;
        vizParams.colorMapMinCoord = p.colorMode->colorMapMinCoord;
        vizParams.colorMapMaxCoord = p.colorMode->colorMapMaxCoord;

        vizParams.colorizeByField = p.colorMode->recolorizeByField.value();
        vizParams.colorMap        = p.colorMode->colorMap;

#if MRPT_VERSION >= 0x020f0d
        vizParams.outlierRejectionPercentile = p.colorMode->autoBoundingBoxOutliersPercentile;
#endif

        mrpt::obs::recolorize3Dpc(glPts, pts.get(), vizParams);

        o.insert(glPts);
    }
    else
    {
        // uniform color point cloud:
        auto glPts = mrpt::opengl::CPointCloud::Create();
        glPts->loadFromPointsMap(pts.get());

        glPts->setPointSize(p.pointSize);
        glPts->setColor_u8(p.color);

        o.insert(glPts);
    }
}

bool metric_map_t::empty() const { return layers.empty() && lines.empty() && planes.empty(); }
void metric_map_t::clear() { *this = metric_map_t(); }

// TODO(JLBC): Write unit test for mergeWith()

void metric_map_t::merge_with(
    const metric_map_t& otherPc, const std::optional<mrpt::math::TPose3D>& otherRelativePose)
{
    auto pose = mrpt::poses::CPose3D::Identity();

    if (otherRelativePose.has_value())
    {
        pose = mrpt::poses::CPose3D(otherRelativePose.value());
    }

    // Lines:
    if (otherRelativePose.has_value())
    {
        std::transform(
            otherPc.lines.begin(), otherPc.lines.end(), std::back_inserter(lines),
            [&](const mrpt::math::TLine3D& l)
            {
                return mrpt::math::TLine3D::FromPointAndDirector(
                    pose.composePoint(l.pBase), pose.rotateVector(l.getDirectorVector()));
            });
    }
    else
    {
        std::copy(otherPc.lines.begin(), otherPc.lines.end(), std::back_inserter(lines));
    }

    // Planes:
    if (otherRelativePose.has_value())
    {
        std::transform(
            otherPc.planes.begin(), otherPc.planes.end(), std::back_inserter(planes),
            [&](const plane_patch_t& l)
            {
                plane_patch_t g;
                g.centroid = pose.composePoint(l.centroid);

                // TODO(JLBC): Finish rotating planes
                // ...
                THROW_EXCEPTION("To-do");
                return g;
            });
    }
    else
    {
        std::copy(otherPc.planes.begin(), otherPc.planes.end(), std::back_inserter(planes));
    }

    // Generic map layers:
    for (const auto& layer : otherPc.layers)
    {
        const auto& name     = layer.first;
        const auto& otherMap = layer.second;

        // New layer?
        if (layers.count(name) == 0)
        {
            // Make a copy and transform (if applicable):
            layers[name] =
                std::dynamic_pointer_cast<mrpt::maps::CMetricMap>(otherMap->duplicateGetSmartPtr());

            if (otherRelativePose.has_value())
            {
                if (auto pts = std::dynamic_pointer_cast<mrpt::maps::CPointsMap>(layers[name]); pts)
                {
                    // Transform:
                    pts->changeCoordinatesReference(pose);
                    continue;
                }

                if (auto mrg = std::dynamic_pointer_cast<MetricMapMergeCapable>(layers[name]); mrg)
                {
                    // Transform:
                    mrg->transform_map_left_multiply(pose);
                    continue;
                }
                THROW_EXCEPTION(
                    "Merging with SE(3) transform only available for metric maps of point "
                    "cloud types or MetricMapMergeCapable.");
            }
        }
        else
        {  // merge with existing layer:
            if (auto pts = std::dynamic_pointer_cast<mrpt::maps::CPointsMap>(layers[name]); pts)
            {
                pts->insertAnotherMap(
                    std::dynamic_pointer_cast<mrpt::maps::CPointsMap>(otherMap).get(), pose);
                continue;
            }
            auto mrg_trg = std::dynamic_pointer_cast<MetricMapMergeCapable>(layers[name]);
            auto mrg_src = std::dynamic_pointer_cast<const MetricMapMergeCapable>(otherMap);

            if (mrg_trg && mrg_src)
            {
                // Transform:
                mrg_trg->merge_with(*mrg_src, pose);
                continue;
            }

            THROW_EXCEPTION(
                "Merging with SE(3) transform only available for metric maps of point "
                "cloud types or MetricMapMergeCapable");
        }
    }
}

size_t metric_map_t::size() const
{
    size_t n = 0;

    n += lines.size();
    n += planes.size();
    n += size_points_only();

    return n;
}
size_t metric_map_t::size_points_only() const
{
    size_t n = 0;
    for (const auto& layer : layers)
    {
        if (auto pts = std::dynamic_pointer_cast<mrpt::maps::CPointsMap>(layer.second); pts)
        {
            n += pts->size();
        }
    }
    return n;
}

std::string metric_map_t::contents_summary() const
{
    using namespace std::string_literals;

    std::string ret;

    if (id)
    {
        ret += "id="s + std::to_string(*id) + " "s;
    }
    if (label)
    {
        ret += "label='"s + *label + "' "s;
    }

    if (georeferencing)
    {
        const auto& gc = georeferencing->geo_coord;
        ret +=
            "georeferenced: "s + "lat="s + gc.lat.getAsString() + " lon="s + gc.lon.getAsString() +
            mrpt::format(" (%.09f  %.09f) ", gc.lat.getDecimalValue(), gc.lon.getDecimalValue()) +
            " h="s + std::to_string(gc.height) + " T_enu_map="s +
            georeferencing->T_enu_to_map.mean.asString();

        const auto& cov = georeferencing->T_enu_to_map.cov;
        ret += mrpt::format(
            " std_x=%.03f std_y=%.03f std_z=%.03f std_yaw=%.02f deg std_pitch=%.02f "
            "deg std_roll=%.02f deg\n",
            std::sqrt(cov(0, 0)), std::sqrt(cov(1, 1)), std::sqrt(cov(2, 2)),
            mrpt::RAD2DEG(std::sqrt(cov(3, 3))), mrpt::RAD2DEG(std::sqrt(cov(4, 4))),
            mrpt::RAD2DEG(std::sqrt(cov(5, 5))));
    }

    if (empty())
    {
        return {ret + "empty"s};
    }

    const auto retAppend = [&ret](const std::string& s)
    {
        if (!ret.empty())
        {
            ret += ", "s;
        }
        ret += s;
    };

    if (!lines.empty())
    {
        retAppend(std::to_string(lines.size()) + " lines"s);
    }
    if (!planes.empty())
    {
        retAppend(std::to_string(planes.size()) + " planes"s);
    }

    size_t nPts = 0, nVoxels = 0;
    bool   otherLayers = false;
    for (const auto& layer : layers)
    {
        ASSERT_(layer.second);
        if (auto pts = std::dynamic_pointer_cast<mrpt::maps::CPointsMap>(layer.second); pts)
        {
            nPts += pts->size();
        }
        else if (auto vxs = std::dynamic_pointer_cast<mrpt::maps::CVoxelMap>(layer.second); vxs)
        {
            nVoxels += vxs->grid().activeCellsCount();
        }
        else
        {
            otherLayers = true;
        }
    }

    if (nPts != 0 || nVoxels != 0 || otherLayers)
    {
        retAppend(
            mrpt::system::unitsFormat(static_cast<double>(nPts), 2, false) + " points, "s +
            mrpt::system::unitsFormat(static_cast<double>(nVoxels), 2, false) + " voxels in "s +
            std::to_string(layers.size()) + " layers ("s);

        for (const auto& layer : layers)
        {
            ret += "\""s + layer.first + "\":"s + layer.second->asString() + " "s;
        }
        ret += ")";
    }

    if (!metadata.isNullNode())
    {
        std::stringstream                 ss;
        mrpt::containers::YamlEmitOptions eo;
        eo.emitHeader   = false;
        eo.emitComments = false;
        metadata.printAsYAML(ss, eo);
        retAppend("metadata: '"s + ss.str() + "' "s);
    }

    return ret;
}

bool metric_map_t::save_to_file(
#if MRPT_VERSION >= 0x020f07
    const std::string& fileName, const mrpt::io::CompressionOptions& co
#else
    const std::string& fileName
#endif
) const
{
#if MRPT_VERSION >= 0x020f07
    auto f = mrpt::io::CCompressedOutputStream(fileName, mrpt::io::OpenMode::TRUNCATE, co);
#else
    auto f = mrpt::io::CFileGZOutputStream(fileName);
#endif
    if (!f.is_open())
    {
        return false;
    }
    try
    {
        auto arch = mrpt::serialization::archiveFrom(f);
        arch << *this;

        return true;
    }
    catch (const std::exception& e)
    {
        std::cerr << "[metric_map_t::save_to_file] Error: " << e.what();
        return false;
    }
}

bool metric_map_t::load_from_file(
    const std::string& fileName, const mrpt::optional_ref<std::string>& outErrorMsg)
{
    using namespace std::string_literals;

#if MRPT_VERSION >= 0x020f07
    auto f = mrpt::io::CCompressedInputStream(fileName);
#else
    auto f = mrpt::io::CFileGZInputStream(fileName);
#endif
    if (!f.is_open())
    {
        if (outErrorMsg)
        {
            outErrorMsg->get() = "Cannot open file: "s + fileName;
        }
        return false;
    }

    try
    {
        auto arch = mrpt::serialization::archiveFrom(f);
        arch >> *this;
    }
    catch (const std::exception& e)
    {
        if (outErrorMsg)
        {
            outErrorMsg->get() = "Exception loading file '"s + fileName + "':\n"s + e.what();
        }
        else
        {
            std::cerr << "[mp2p_icp::metric_map_t::load_from_file()] Exception loading file '"s +
                             fileName + "':\n"s + e.what()
                      << std::endl;
        }
        return false;
    }

    return true;
}

metric_map_t::Ptr metric_map_t::get_shared_from_this()
{
    try
    {
        return shared_from_this();
    }
    catch (const std::bad_weak_ptr&)
    {
        // Not created as a shared_ptr.
        return {};
    }
}

metric_map_t::Ptr metric_map_t::get_shared_from_this_or_clone()
{
    Ptr ret = get_shared_from_this();
    if (!ret)
    {
        ret = std::make_shared<metric_map_t>(*this);
    }
    return ret;
}

metric_map_t::ConstPtr metric_map_t::get_shared_from_this() const
{
    try
    {
        return shared_from_this();
    }
    catch (const std::bad_weak_ptr&)
    {
        // Not created as a shared_ptr.
        return {};
    }
}

metric_map_t::ConstPtr metric_map_t::get_shared_from_this_or_clone() const
{
    ConstPtr ret = get_shared_from_this();
    if (!ret)
    {
        ret = std::make_shared<metric_map_t>(*this);
    }
    return ret;
}

mrpt::maps::CPointsMap::Ptr metric_map_t::point_layer(const layer_name_t& name) const
{
    auto it = layers.find(name);
    if (it == layers.end())
    {
        THROW_EXCEPTION_FMT("Layer '%s' does not exist.", name.c_str());
    }

    const auto& ptr = it->second;
    if (!ptr)
    {
        return {};  // empty shared_ptr.
    }

    auto ret = std::dynamic_pointer_cast<mrpt::maps::CPointsMap>(ptr);
    if (!ret)
    {
        THROW_EXCEPTION_FMT(
            "Layer '%s' is not a point cloud (actual class:'%s').", name.c_str(),
            ptr->GetRuntimeClass()->className);
    }

    return ret;
}

const mrpt::maps::CPointsMap* mp2p_icp::MapToPointsMap(const mrpt::maps::CMetricMap& map)
{
    if (auto ptsMap = dynamic_cast<const mrpt::maps::CPointsMap*>(&map); ptsMap)
    {
        return ptsMap;
    }
    if (auto voxelMap = dynamic_cast<const mrpt::maps::CVoxelMap*>(&map); voxelMap)
    {
        return voxelMap->getOccupiedVoxels().get();
    }
    if (auto voxelRGBMap = dynamic_cast<const mrpt::maps::CVoxelMapRGB*>(&map); voxelRGBMap)
    {
        return voxelRGBMap->getOccupiedVoxels().get();
    }
    return {};
}

mrpt::maps::CPointsMap* mp2p_icp::MapToPointsMap(mrpt::maps::CMetricMap& map)
{
    if (auto ptsMap = dynamic_cast<mrpt::maps::CPointsMap*>(&map); ptsMap)
    {
        return ptsMap;
    }
    if (auto voxelMap = dynamic_cast<mrpt::maps::CVoxelMap*>(&map); voxelMap)
    {
        return voxelMap->getOccupiedVoxels().get();
    }
    if (auto voxelRGBMap = dynamic_cast<mrpt::maps::CVoxelMapRGB*>(&map); voxelRGBMap)
    {
        return voxelRGBMap->getOccupiedVoxels().get();
    }
    return {};
}

const mrpt::maps::NearestNeighborsCapable* mp2p_icp::MapToNN(
    const mrpt::maps::CMetricMap& map, bool throwIfNotImplemented)
{
    const auto* ptr = dynamic_cast<const mrpt::maps::NearestNeighborsCapable*>(&map);

    if (ptr)
    {
        return ptr;
    }
    if (!throwIfNotImplemented)
    {
        return nullptr;
    }

    THROW_EXCEPTION_FMT(
        "The map of type '%s' does not implement the expected interface "
        "mrpt::maps::NearestNeighborsCapable",
        map.GetRuntimeClass()->className);
}

const mp2p_icp::NearestPlaneCapable* mp2p_icp::MapToNP(
    const mrpt::maps::CMetricMap& map, bool throwIfNotImplemented)
{
    const auto* ptr = dynamic_cast<const mp2p_icp::NearestPlaneCapable*>(&map);

    if (ptr)
    {
        return ptr;
    }
    if (!throwIfNotImplemented)
    {
        return nullptr;
    }

    THROW_EXCEPTION_FMT(
        "The map of type '%s' does not implement the expected interface "
        "mp2p_icp::NearestPlaneCapable",
        map.GetRuntimeClass()->className);
}

// Serialization of geo-reference information:
constexpr const char* GEOREF_MAGIC_STR = "mp2p_icp::Georeferencing";

mrpt::serialization::CArchive& mp2p_icp::operator>>(
    mrpt::serialization::CArchive& in, std::optional<metric_map_t::Georeferencing>& g)
{
    std::string georef_stream_signature;
    in >> georef_stream_signature;
    ASSERT_EQUAL_(georef_stream_signature, std::string(GEOREF_MAGIC_STR));
    const uint8_t version = in.ReadAs<uint8_t>();
    switch (version)
    {
        case 0:
            if (in.ReadAs<bool>())
            {
                auto& gg = g.emplace();
                in >> gg.geo_coord.lat.decimal_value >> gg.geo_coord.lon.decimal_value >>
                    gg.geo_coord.height;
                in >> gg.T_enu_to_map;
            }
            break;
        default:
            MRPT_THROW_UNKNOWN_SERIALIZATION_VERSION(version);
    };

    return in;
}

mrpt::serialization::CArchive& mp2p_icp::operator<<(
    mrpt::serialization::CArchive& out, const std::optional<metric_map_t::Georeferencing>& g)
{
    out << std::string(GEOREF_MAGIC_STR);
    constexpr uint8_t serial_version = 0;
    out.WriteAs<uint8_t>(serial_version);

    out.WriteAs<bool>(g.has_value());
    if (g)
    {
        out << g->geo_coord.lat.decimal_value << g->geo_coord.lon.decimal_value
            << g->geo_coord.height;
        out << g->T_enu_to_map;
    }
    return out;
}

std::optional<metric_map_t::Georeferencing> mp2p_icp::FromYAML(
    const mrpt::containers::yaml& yaml_data)
{
    ASSERT_(yaml_data.isMap());
    ASSERT_(yaml_data.has("type"));
    ASSERT_(yaml_data.has("defined"));

    ASSERT_EQUAL_(yaml_data["type"].as<std::string>(), GEOREF_MAGIC_STR);
    const bool defined = yaml_data["defined"].as<bool>();
    if (!defined)
    {  // empty:
        return {};
    }

    std::optional<metric_map_t::Georeferencing> georef;

    auto& g                       = georef.emplace();
    g.geo_coord.lon.decimal_value = yaml_data["geo_coord"]["lon"].as<double>();
    g.geo_coord.lat.decimal_value = yaml_data["geo_coord"]["lat"].as<double>();
    g.geo_coord.height            = yaml_data["geo_coord"]["altitude"].as<double>();

    const auto& ym      = yaml_data["T_enu_to_map"]["mean"];
    g.T_enu_to_map.mean = mrpt::poses::CPose3D::FromXYZYawPitchRoll(
        ym["x"].as<double>(), ym["y"].as<double>(), ym["z"].as<double>(),
        mrpt::DEG2RAD(ym["yaw_deg"].as<double>()), mrpt::DEG2RAD(ym["pitch_deg"].as<double>()),
        mrpt::DEG2RAD(ym["roll_deg"].as<double>()));

    yaml_data["T_enu_to_map"]["cov"].toMatrix(g.T_enu_to_map.cov);

    return georef;
}

mrpt::containers::yaml mp2p_icp::ToYAML(const std::optional<metric_map_t::Georeferencing>& geoRef)
{
    mrpt::containers::yaml data = mrpt::containers::yaml::Map();

    data["type"]    = GEOREF_MAGIC_STR;
    data["defined"] = geoRef.has_value();
    if (geoRef)
    {
        {
            mrpt::containers::yaml geoCoord = mrpt::containers::yaml::Map();
            geoCoord["lon"]                 = geoRef->geo_coord.lon;
            geoCoord["lat"]                 = geoRef->geo_coord.lat;
            geoCoord["altitude"]            = geoRef->geo_coord.height;

            data["geo_coord"] = geoCoord;
        }

        mrpt::containers::yaml pose_mean = mrpt::containers::yaml::Map();
        const auto&            p         = geoRef->T_enu_to_map.mean;

        pose_mean["x"]         = p.x();
        pose_mean["y"]         = p.y();
        pose_mean["z"]         = p.z();
        pose_mean["yaw_deg"]   = mrpt::RAD2DEG(p.yaw());
        pose_mean["pitch_deg"] = mrpt::RAD2DEG(p.pitch());
        pose_mean["roll_deg"]  = mrpt::RAD2DEG(p.roll());

        mrpt::containers::yaml pose = mrpt::containers::yaml::Map();
        pose["mean"]                = pose_mean;
        pose["cov"]                 = mrpt::containers::yaml::FromMatrix(geoRef->T_enu_to_map.cov);
        pose["cov"].comment("Covariance in order [x,y,z,yaw,pitch,roll]");
        data["T_enu_to_map"] = pose;
    }
    return data;
}
