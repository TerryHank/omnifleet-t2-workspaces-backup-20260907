[![CI Build colcon](https://github.com/MOLAorg/mola_lidar_odometry/actions/workflows/build-ros.yml/badge.svg)](https://github.com/MOLAorg/mola_lidar_odometry/actions/workflows/build-ros.yml)
[![CI clang-format](https://github.com/MOLAorg/mola_lidar_odometry/actions/workflows/check-clang-format.yml/badge.svg)](https://github.com/MOLAorg/mola_lidar_odometry/actions/workflows/check-clang-format.yml)
[![Docs](https://img.shields.io/badge/docs-latest-brightgreen.svg)]([https://docs.mola-slam.org/latest/](https://docs.mola-slam.org/latest/mola_state_estimators.html))
[![codecov](https://codecov.io/gh/MOLAorg/mola_lidar_odometry/graph/badge.svg?token=C11VFFK0NW)](https://codecov.io/gh/MOLAorg/mola_lidar_odometry)

# mola_lidar_odometry
LIDAR odometry component based on the MOLA and MRPT frameworks,
compatible with ROS 2.

## Contents
This repository provides a C++ library `mola_lidar_odometry` implementing LIDAR
odometry. Sensor input is provided via MOLA components, and ROS 2 example launch files are
provided in [ros2-launchs](ros2-launchs/).

A CLI interface `mola-lidar-odometry-cli` is also provided for running on
offline datasets.

## Build and install
Refer to: https://docs.mola-slam.org/latest/#installing

Lidar Inertial Odometry (LIO) demo with Oxford Spires:
![Peek 2025-08-31 11-36](https://github.com/user-attachments/assets/b99d99de-9178-4fda-bf85-cb926f8c5d87)


Lidar Odometry (LO) demo with KITTI:
![mola-slam-kitti-demo](https://github.com/user-attachments/assets/45255aba-6ea2-44eb-b5e4-4cc52e8e7615)

## Documentation and tutorials
See: https://docs.mola-slam.org/

## ROS build farm status

| Distro | Develop branch | Releases | Stable release |
| ---    | ---            | ---      |  ---      |
| ROS2 Humble  (u22.04) |  [![Build Status](https://build.ros2.org/job/Hdev__mola_lidar_odometry__ubuntu_jammy_amd64/badge/icon)](https://build.ros2.org/job/Hdev__mola_lidar_odometry__ubuntu_jammy_amd64/) | amd64 [![Build Status](https://build.ros2.org/job/Hbin_uJ64__mola_lidar_odometry__ubuntu_jammy_amd64__binary/badge/icon)](https://build.ros2.org/job/Hbin_uJ64__mola_lidar_odometry__ubuntu_jammy_amd64__binary/) <br> arm64 [![Build Status](https://build.ros2.org/job/Hbin_ujv8_uJv8__mola_lidar_odometry__ubuntu_jammy_arm64__binary/badge/icon)](https://build.ros2.org/job/Hbin_ujv8_uJv8__mola_lidar_odometry__ubuntu_jammy_arm64__binary/) | [![Version](https://img.shields.io/ros/v/humble/mola_lidar_odometry)](https://index.ros.org/?search_packages=true&pkgs=mola_lidar_odometry) |
| ROS 2 Jazzy @ u24.04 | [![Build Status](https://build.ros2.org/job/Jdev__mola_lidar_odometry__ubuntu_noble_amd64/badge/icon)](https://build.ros2.org/job/Jdev__mola_lidar_odometry__ubuntu_noble_amd64/) | amd64 [![Build Status](https://build.ros2.org/job/Jbin_uN64__mola_lidar_odometry__ubuntu_noble_amd64__binary/badge/icon)](https://build.ros2.org/job/Jbin_uN64__mola_lidar_odometry__ubuntu_noble_amd64__binary/) <br> arm64 [![Build Status](https://build.ros2.org/job/Jbin_unv8_uNv8__mola_lidar_odometry__ubuntu_noble_arm64__binary/badge/icon)](https://build.ros2.org/job/Jbin_unv8_uNv8__mola_lidar_odometry__ubuntu_noble_arm64__binary/)| [![Version](https://img.shields.io/ros/v/jazzy/mola_lidar_odometry)](https://index.ros.org/?search_packages=true&pkgs=mola_lidar_odometry) | 
| ROS 2 Kilted @ u24.04 | [![Build Status](https://build.ros2.org/job/Kdev__mola_lidar_odometry__ubuntu_noble_amd64/badge/icon)](https://build.ros2.org/job/Kdev__mola_lidar_odometry__ubuntu_noble_amd64/) | amd64 [![Build Status](https://build.ros2.org/job/Kbin_uN64__mola_lidar_odometry__ubuntu_noble_amd64__binary/badge/icon)](https://build.ros2.org/job/Kbin_uN64__mola_lidar_odometry__ubuntu_noble_amd64__binary/) <br> arm64 [![Build Status](https://build.ros2.org/job/Kbin_unv8_uNv8__mola_lidar_odometry__ubuntu_noble_arm64__binary/badge/icon)](https://build.ros2.org/job/Kbin_unv8_uNv8__mola_lidar_odometry__ubuntu_noble_arm64__binary/)| [![Version](https://img.shields.io/ros/v/kilted/mola_lidar_odometry)](https://index.ros.org/?search_packages=true&pkgs=mola_lidar_odometry) | 
| ROS 2 Lyrical (u26.04) | [![Build Status](https://build.ros2.org/job/Ldev__mola_lidar_odometry__ubuntu_resolute_amd64/badge/icon)](https://build.ros2.org/job/Ldev__mola_lidar_odometry__ubuntu_resolute_amd64/) | amd64 [![Build Status](https://build.ros2.org/job/Lbin_uR64__mola_lidar_odometry__ubuntu_resolute_amd64__binary/badge/icon)](https://build.ros2.org/job/Lbin_uR64__mola_lidar_odometry__ubuntu_resolute_amd64__binary/) <br> arm64 [![Build Status](https://build.ros2.org/job/Lbin_armv8_uRv8__mola_lidar_odometry__ubuntu_resolute_arm64__binary/badge/icon)](https://build.ros2.org/job/Lbin_armv8_uRv8__mola_lidar_odometry__ubuntu_resolute_arm64__binary/) | [![Version](https://img.shields.io/ros/v/lyrical/mola_lidar_odometry)](https://index.ros.org/?search_packages=true&pkgs=mola_lidar_odometry) |
| ROS 2 Rolling (u26.04) | [![Build Status](https://build.ros2.org/job/Rdev__mola_lidar_odometry__ubuntu_resolute_amd64/badge/icon)](https://build.ros2.org/job/Rdev__mola_lidar_odometry__ubuntu_resolute_amd64/) | amd64 [![Build Status](https://build.ros2.org/job/Rbin_uR64__mola_lidar_odometry__ubuntu_resolute_amd64__binary/badge/icon)](https://build.ros2.org/job/Rbin_uR64__mola_lidar_odometry__ubuntu_resolute_amd64__binary/) <br> arm64 [![Build Status](https://build.ros2.org/job/Rbin_unv8_uRv8__mola_lidar_odometry__ubuntu_resolute_arm64__binary/badge/icon)](https://build.ros2.org/job/Rbin_unv8_uRv8__mola_lidar_odometry__ubuntu_resolute_arm64__binary/) | [![Version](https://img.shields.io/ros/v/rolling/mola_lidar_odometry)](https://index.ros.org/?search_packages=true&pkgs=mola_lidar_odometry) |

| EOL Distro | Last release |
| ---    |  ---      |
| ROS2 Iron  (u22.04)   | [![Version](https://img.shields.io/ros/v/iron/mola_lidar_odometry)](https://index.ros.org/?search_packages=true&pkgs=mola_lidar_odometry) |


## Citation

The latest publication on MOLA is ([ArXiV](https://arxiv.org/abs/2407.20465)).

```bibtex
@article{blanco2025mola_lo,
    author = {Blanco-Claraco, Jose Luis},
    title ={{A flexible framework for accurate LiDAR odometry, map manipulation, and localization}},
    journal = {The International Journal of Robotics Research},
    volume = {44},
    number = {9},
    pages = {1553--1599},
    year = {2025},
    doi = {10.1177/02783649251316881},
    URL = { https://doi.org/10.1177/02783649251316881},
    eprint = {2407.20465},
}
```

## License
Copyright (C) 2018-2026 Jose Luis Blanco <jlblanco@ual.es>, University of Almeria

This package is released under the GNU GPL v3 license as open source, with the main 
intention of being useful for research and evaluation purposes.
Commercial licenses [available upon request](https://docs.mola-slam.org/latest/solutions.html).

Contributions require acceptance of the Contributor License Agreement (CLA).
