/*               _
 _ __ ___   ___ | | __ _
| '_ ` _ \ / _ \| |/ _` | Modular Optimization framework for
| | | | | | (_) | | (_| | Localization and mApping (MOLA)
|_| |_| |_|\___/|_|\__,_| https://github.com/MOLAorg/mola

 Copyright (C) 2018-2026 Jose Luis Blanco, University of Almeria,
                         and individual contributors.
 SPDX-License-Identifier: GPL-3.0
 See LICENSE for full license information.
 Closed-source licenses available upon request, for this odometry package
 alone or in combination with the complete SLAM system.
*/

/**
 * @file   LidarOdometry.cpp
 * @brief  Main C++ class exposing LIDAR odometry
 * @author Jose Luis Blanco Claraco
 * @date   Sep 16, 2023
 */

// This module:
#include <mola_lidar_odometry/LidarOdometry.h>
#include <mrpt/obs/CObservationIMU.h>

namespace mola
{

void LidarOdometry::handleInitialLocalizationDoInitFromPose(
  const mrpt::poses::CPose3DPDFGaussian & initPose, bool resetStateEstimator)
{
  if (resetStateEstimator) {
    ASSERT_(state_.navstate_fuse);
    state_.navstate_fuse->reset();  // needed after a re-localization to forget the past

    // Fake an evolution to be able to have an initial velocity estimation:
    // Use a tiny time step to let the filter remain with a large uncertainty about twist:
    ASSERT_(state_.last_obs_timestamp.has_value());
    const auto t1 =
      mrpt::Clock::fromDouble(mrpt::Clock::toDouble(*state_.last_obs_timestamp) - 2e-3);
    const auto t2 =
      mrpt::Clock::fromDouble(mrpt::Clock::toDouble(*state_.last_obs_timestamp) - 1e-3);
    state_.navstate_fuse->fuse_pose(t1, initPose, params_.publish_reference_frame);
    state_.navstate_fuse->fuse_pose(t2, initPose, params_.publish_reference_frame);

    // Also skip fusing the next few ICP corrections into the state estimator
    // (same safeguard used by relocalize_near_pose_pdf()/relocalize_from_gnss()):
    // the very first ICP correction after this reset is only a tiny "dt" away
    // from the fake evolution above, so dividing its position delta by that
    // dt can produce a huge, spurious velocity. Skipping a few steps lets ICP
    // re-converge on a stable pose before velocity is derived again.
    state_.step_counter_post_relocalization = std::max(
      params_.initial_localization.additional_uncertainty_after_reloc_how_many_timesteps,
      params_.initial_localization.additional_map_freeze_after_reloc_how_many_timesteps);
  }

  // also, keep it as the last pose for subsequent ICP runs:
  state_.last_lidar_pose = initPose;
}

void LidarOdometry::handleInitialLocalization()
{
  auto & il = params_.initial_localization;

  switch (params_.initial_localization.method) {
      // FIXED POSE INITIALIZATION
      // ------------------------------
    case mola::InitLocalization::FixedPose: {
      mrpt::poses::CPose3DPDFGaussian initPose;
      initPose.mean = mrpt::poses::CPose3D(il.fixed_initial_pose);
      if (!il.initial_pose_cov) {
        initPose.cov.setDiagonal(1e-12);
      } else {
        initPose.cov = *il.initial_pose_cov;
      }

      handleInitialLocalizationDoInitFromPose(initPose, true);
      doRemoveCloudsWithDecay();

      MRPT_LOG_INFO_STREAM("Initial re-localization done with pose: " << initPose.mean);

      state_.initial_localization_done = true;
    } break;

      // INITIALIZATION FROM STATE ESTIMATOR (GNSS, ETC.)
      // ---------------------------------------------------
    case mola::InitLocalization::FromStateEstimator: {
      handleInitialLocalizationStateEstimation();
    } break;

      // INITIALIZATION FROM IMU FOR PITCH & ROLL ONLY
      // ---------------------------------------------------
    case mola::InitLocalization::PitchAndRollFromIMU: {
      // imu_initializer is created here but fed from the LiDAR worker thread:
      auto lckImu = mrpt::lockHelper(imu_state_mtx_);

      // Construct the IMU averager object:
      if (!state_.imu_initializer) {
        state_.imu_initializer = mola::imu::ImuInitialCalibrator();
        auto & ip = state_.imu_initializer->parameters;

        ip.max_samples_age = il.imu_initial_calibration_max_age;
        ip.required_samples = il.imu_initial_calibration_sample_count;
#if defined(MOLA_IMU_PREINT_HAS_USE_IMU_ORIENT_PARAM)  // Remove in a few months from Dec 2025
        ip.use_imu_orientation = il.use_imu_orientation;
#endif

#if defined(MOLA_IMU_PREINT_HAS_INIT_TIME_WINDOW)
        if (il.imu_initial_calibration_legacy_mode) {
          MRPT_LOG_WARN_FMT(
            "initial_localization.imu_initial_calibration_sample_count is deprecated: it ties the "
            "averaging time to the IMU rate (%u samples is %.2f s at 400 Hz but %.2f s at 100 Hz) "
            "and cannot be reached at all below ~%.0f Hz within "
            "imu_initial_calibration_max_age=%.1f s. Use "
            "imu_initial_calibration_window_seconds instead.",
            static_cast<unsigned>(il.imu_initial_calibration_sample_count),
            il.imu_initial_calibration_sample_count / 400.0,
            il.imu_initial_calibration_sample_count / 100.0,
            il.imu_initial_calibration_sample_count / il.imu_initial_calibration_max_age,
            il.imu_initial_calibration_max_age);
        } else {
          ip.window_seconds = il.imu_initial_calibration_window_seconds;
          ip.required_samples = il.imu_initial_calibration_min_samples;
          ip.max_direction_dispersion =
            mrpt::DEG2RAD(il.imu_initial_calibration_max_dispersion_deg);
          ip.dispersion_timeout = il.imu_initial_calibration_dispersion_timeout;
        }
#else
        if (!il.imu_initial_calibration_legacy_mode) {
          MRPT_LOG_WARN_FMT(
            "Built against a mola_imu_preintegration without time-window support: "
            "imu_initial_calibration_window_seconds is ignored and %u samples are used instead.",
            static_cast<unsigned>(il.imu_initial_calibration_sample_count));
        }
#endif
      }

#if defined(MOLA_IMU_PREINT_HAS_INIT_TIME_WINDOW)
      const auto imuReadiness = state_.imu_initializer->readiness();
      const bool imuIsReady = imuReadiness.ready;
#else
      const bool imuIsReady = state_.imu_initializer->isReady();
#endif

      // Already collected enough samples?
      if (imuIsReady) {
        // Get the average pitch & roll:
        const auto & imu_calib_opt = state_.imu_initializer->getCalibration();
        ASSERT_(imu_calib_opt);

#if defined(MOLA_IMU_PREINT_HAS_INIT_TIME_WINDOW)
        MRPT_LOG_INFO_FMT(
          "IMU initial attitude averaged over %.3f s (%zu samples, dispersion %.2f deg)%s",
          imuReadiness.span, imuReadiness.samples,
          mrpt::RAD2DEG(imuReadiness.dispersion.value_or(0.0)),
          imuReadiness.timed_out ? ", accepted on gate timeout: the platform never became still, "
                                   "so this attitude includes its motion"
                                 : "");
#endif

        MRPT_LOG_INFO_STREAM("IMU automatic calibration done: " << imu_calib_opt->asString());

        // Overwrite pitch & roll from the IMU, keeping the configured x/y/z/yaw prior:
        il.fixed_initial_pose.pitch = imu_calib_opt->pitch;
        il.fixed_initial_pose.roll = imu_calib_opt->roll;

        MRPT_LOG_INFO_STREAM(
          "Initial re-localization done from IMU pitch/roll with pose: "
          << il.fixed_initial_pose.asString());

        mrpt::poses::CPose3DPDFGaussian initPose;
        initPose.mean = mrpt::poses::CPose3D(il.fixed_initial_pose);
        initPose.cov.setDiagonal(1e-12);
        handleInitialLocalizationDoInitFromPose(initPose, true);
        doRemoveCloudsWithDecay();

        // Only wipe the local map / simplemap if no preexisting map is
        // loaded (from start-up config, or via a runtime map_load() service
        // call): otherwise this would discard a map inherited from a
        // previous mapping session (multisession/multi-robot mapping).
        if (!state_.map_has_been_loaded) {
          {
            auto lckMapContents = mrpt::lockHelper(local_map_content_mtx_);
            state_.local_map->clear();
          }
          state_.gravity_calib_pitch_roll.reset();  // new map origin: recapture at next first KF
          state_.gravity_calib_pose.reset();
          state_.gravity_calib_first_available_time.reset();
          ASSERT_(state_.local_map->empty());
          {
            auto lckSM = mrpt::lockHelper(state_simplemap_mtx_);
            state_.reconstructed_simplemap.clear();
          }
        }

        state_.initial_localization_done = true;
        state_.imu_initializer.reset();  // no longer needed

      } else {
#if defined(MOLA_IMU_PREINT_HAS_INIT_TIME_WINDOW)
        MRPT_LOG_THROTTLE_INFO_FMT(
          5.0,
          "Waiting to initialize pitch & roll from the IMU: %s (%zu samples spanning %.3f s, "
          "dispersion %.2f deg, %.1f s elapsed)",
          imuReadiness.reason.c_str(), imuReadiness.samples, imuReadiness.span,
          mrpt::RAD2DEG(imuReadiness.dispersion.value_or(0.0)), imuReadiness.elapsed);
#else
        MRPT_LOG_THROTTLE_INFO(
          5.0, "Waiting for enough IMU samples to initialize pitch & roll while stationary...");
#endif
      }
    } break;

    default:
      THROW_EXCEPTION("Unknown value for initial_localization.method");
  };
}

void LidarOdometry::onExternalMapUpdate(const MapSourceBase::MapUpdate & mu)
{
  // We're interested in geo-referencing updates
  if (!mu.georeferencing.has_value()) {
    return;
  }

  auto lck = mrpt::lockHelper(state_mtx_);

  // Store the external geo-reference
  state_.external_georef = mu.georeferencing;

  MRPT_LOG_INFO_STREAM(
    "Received external geo-referencing from state estimator: "
    << "lat=" << mu.georeferencing->geo_coord.lat.getAsString()
    << ", lon=" << mu.georeferencing->geo_coord.lon.getAsString()
    << ", T_enu_to_map=" << mu.georeferencing->T_enu_to_map.mean.asString());

  // If we don't have geo-ref in local map yet, set it:
  if (!state_.local_map->georeferencing.has_value()) {
    state_.local_map->georeferencing.emplace();
    state_.local_map->georeferencing->geo_coord = mu.georeferencing->geo_coord;
    state_.local_map->georeferencing->T_enu_to_map = mu.georeferencing->T_enu_to_map;

    state_.mark_local_map_georef_as_updated();
    MRPT_LOG_INFO("Applied external geo-referencing to local map");
  }
}

void LidarOdometry::onExternalLocalizationUpdate(  // NOLINT
  const LocalizationSourceBase::LocalizationUpdate & lu)
{
  // This callback could be used for real-time monitoring of state estimator
  // convergence, but the main check happens in handleInitialLocalization()
  (void)lu;
}

void LidarOdometry::handleInitialLocalizationStateEstimation()
{
  auto & il = params_.initial_localization;

  ASSERT_(state_.navstate_fuse);

  // Track when we started waiting
  if (!state_.waiting_for_state_estimator_since) {
    state_.waiting_for_state_estimator_since = mrpt::Clock::now();
    MRPT_LOG_INFO("Waiting for state estimator to converge (GNSS+IMU fusion)...");
  }

  // Check timeout
  const double elapsed =
    mrpt::system::timeDifference(*state_.waiting_for_state_estimator_since, mrpt::Clock::now());

  if (il.from_state_estimator_timeout > 0 && elapsed > il.from_state_estimator_timeout) {
    MRPT_LOG_ERROR_FMT(
      "Timeout (%.1f s) waiting for state estimator to converge. "
      "Check GNSS/IMU sensors.",
      il.from_state_estimator_timeout);
    state_.waiting_for_state_estimator_since.reset();
    return;
  }

  // Check if state estimator has converged
  mrpt::poses::CPose3DPDFGaussian estimatedPose;

  // Note: state_mtx_ is already held by the caller (processLidarScan), which
  // also serializes us against onExternalMapUpdate (writes
  // state_.external_georef from another thread under the same mutex).
  {
    const bool hasGeoRef =
      state_.local_map->georeferencing.has_value() || state_.external_georef.has_value();

    if (!hasGeoRef) {
      MRPT_LOG_THROTTLE_INFO(
        5.0, "Waiting for geo-referencing (from loaded map or state estimator)...");
      return;  // Not ready yet
    }

    // Apply external georef to local map if needed
    if (!state_.local_map->georeferencing.has_value() && state_.external_georef.has_value()) {
      state_.local_map->georeferencing.emplace();
      state_.local_map->georeferencing->geo_coord = state_.external_georef->geo_coord;
      state_.local_map->georeferencing->T_enu_to_map = state_.external_georef->T_enu_to_map;
      state_.mark_local_map_georef_as_updated();
    }
  }

  // Now check if state estimator has converged
#if MOLA_VERSION_CHECK(2, 5, 0)
  bool converged = state_.navstate_fuse->has_converged_localization(estimatedPose);
#else
  bool converged = false;
  MRPT_LOG_THROTTLE_WARN(5.0, "Initialization from state estimation requires mola_kernel >= 2.5.0");
#endif

  // Additional covariance check with our own thresholds
  if (converged) {
    const double pos_sigma_max = std::sqrt(
      std::max({estimatedPose.cov(0, 0), estimatedPose.cov(1, 1), estimatedPose.cov(2, 2)}));
    const double ori_sigma_max_deg = mrpt::RAD2DEG(std::sqrt(
      std::max({estimatedPose.cov(3, 3), estimatedPose.cov(4, 4), estimatedPose.cov(5, 5)})));

    if (
      pos_sigma_max > il.from_state_estimator_max_position_sigma ||
      ori_sigma_max_deg > il.from_state_estimator_max_orientation_sigma_deg) {
      converged = false;
      MRPT_LOG_THROTTLE_DEBUG_FMT(
        5.0,
        "State estimator converged but uncertainty too high: "
        "pos_sigma=%.3f m (max=%.3f), ori_sigma=%.2f deg (max=%.2f)",
        pos_sigma_max, il.from_state_estimator_max_position_sigma, ori_sigma_max_deg,
        il.from_state_estimator_max_orientation_sigma_deg);
    }
  }

  if (!converged) {
    MRPT_LOG_THROTTLE_INFO_FMT(
      5.0, "Waiting for state estimator to converge (elapsed: %.1f s)...", elapsed);
    return;  // Not ready yet
  }

  // State estimator has converged - initialize!
  MRPT_LOG_INFO_STREAM(
    "State estimator converged after "
    << elapsed
    << " s. "
       "Initializing LiDAR odometry with pose: "
    << estimatedPose.mean << " (sigmas: " << std::sqrt(estimatedPose.cov(0, 0)) << ", "
    << std::sqrt(estimatedPose.cov(1, 1)) << ", " << std::sqrt(estimatedPose.cov(2, 2)) << " m)");

  handleInitialLocalizationDoInitFromPose(estimatedPose, false);
  doRemoveCloudsWithDecay();

  state_.initial_localization_done = true;
  state_.waiting_for_state_estimator_since.reset();

  // Auto-transition into active after convergence:
  {
    auto lckStateFlags = mrpt::lockHelper(state_flags_mtx_);
    if (!state_.active) {
      state_.active = true;
      MRPT_LOG_INFO("Auto-transitioning to active mode after state estimator convergence.");
    }
  }
}

}  // namespace mola
