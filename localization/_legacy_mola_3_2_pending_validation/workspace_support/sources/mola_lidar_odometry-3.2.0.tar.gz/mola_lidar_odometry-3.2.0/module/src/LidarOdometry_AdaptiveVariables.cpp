/*               _
 _ __ ___   ___ | | __ _
| '_ ` _ \ / _ \| |/ _` | Modular Optimization framework for
| | | | | | (_) | | (_| | Localization and mApping (MOLA)
|_| |_| |_|\___/|_|\__,_| https://github.com/MOLAorg/mola

 Copyright (C) 2018-2026 Jose Luis Blanco, University of Almeria,
                         and individual contributors.
 SPDX-License-Identifier: GPL-3.0
 See LICENSE for full license information.
 Closed-source licenses available upon request, for this odometry package
 alone or in combination with the complete SLAM system.
*/

/**
 * @file   LidarOdometry.cpp
 * @brief  Main C++ class exposing LIDAR odometry
 * @author Jose Luis Blanco Claraco
 * @date   Sep 16, 2023
 */

// This module:
#include <mola_lidar_odometry/LidarOdometry.h>

// MRPT:
#include <mrpt/core/bits_math.h>
#include <mrpt/core/exceptions.h>
#include <mrpt/maps/CPointsMap.h>
#include <mrpt/math/TTwist3D.h>
#include <mrpt/obs/CObservation.h>
#include <mrpt/poses/Lie/SO.h>
#include <mrpt/system/COutputLogger.h>
#include <mrpt/system/datetime.h>

// mp2p_icp
#include <mp2p_icp/metricmap.h>
#include <mp2p_icp_filters/Generator.h>

// Std:
#include <algorithm>
#include <cmath>
#include <memory>

namespace
{
[[nodiscard]] bool isNormalPoint(const mrpt::math::TPoint3Df & pt)
{
  return std::isnormal(pt.x) && std::isnormal(pt.y) && std::isnormal(pt.z);
}
}  // namespace

namespace mola
{

void LidarOdometry::updatePipelineDynamicVariablesRobotPoseOnly()
{
  auto lckImu = mrpt::lockHelper(imu_state_mtx_);

  const auto & p = state_.last_lidar_pose.mean;
  state_.parameter_source.updateVariable("robot_x", p.x());
  state_.parameter_source.updateVariable("robot_y", p.y());
  state_.parameter_source.updateVariable("robot_z", p.z());
  state_.parameter_source.updateVariable("robot_yaw", p.yaw());
  state_.parameter_source.updateVariable("robot_pitch", p.pitch());
  state_.parameter_source.updateVariable("robot_roll", p.roll());
}

void LidarOdometry::updatePipelineDynamicVariables(const mrpt::Clock::time_point & stamp)
{
  // Writes the localVelocityBuffer the IMU thread also appends to, and ends
  // with realize(), which flips the "evaluated" flags that thread reads:
  auto lckImu = mrpt::lockHelper(imu_state_mtx_);

  const auto stamp_s = mrpt::Clock::toDouble(stamp);

  // Set dynamic variables for twist usage within ICP pipelines
  // (e.g. de-skew methods)
  {
    mrpt::math::TTwist3D twistForIcpVars = {0, 0, 0, 0, 0, 0};
    if (state_.last_motion_model_output) {
      twistForIcpVars = state_.last_motion_model_output->twist;
    }

    this->updatePipelineTwistVariables(twistForIcpVars);

    state_.parameter_source.localVelocityBuffer.add_linear_velocity(
      stamp_s, {twistForIcpVars.vx, twistForIcpVars.vy, twistForIcpVars.vz});
    state_.parameter_source.localVelocityBuffer.add_angular_velocity(
      stamp_s, {twistForIcpVars.wx, twistForIcpVars.wy, twistForIcpVars.wz});
  }

  // robot pose:
  updatePipelineDynamicVariablesRobotPoseOnly();
  const auto & p = state_.last_lidar_pose.mean;

  state_.parameter_source.localVelocityBuffer.add_orientation(stamp_s, p.getRotationMatrix());

  state_.parameter_source.updateVariable(
    "ADAPTIVE_THRESHOLD_SIGMA", state_.adapt_thres_sigma != 0
                                  ? state_.adapt_thres_sigma
                                  : params_.adaptive_threshold.initial_sigma);

  state_.parameter_source.updateVariable("ICP_ITERATION", 0);

  const auto ensureVarIsDefined = [&](const std::string & varName) {
    if (!state_.parameter_source.getVariableValues().count(varName)) {
      state_.parameter_source.updateVariable(varName, 0);
    }
  };

  // For stats generation in CSV
  ensureVarIsDefined("icp_iterations");
  ensureVarIsDefined("SENSOR_TIME_OFFSET");
  ensureVarIsDefined("twistCorrectionCount");
  ensureVarIsDefined("icp_quality");

  if (state_.estimated_observation_radius) {
    state_.parameter_source.updateVariable(
      "ESTIMATED_OBSERVATION_RADIUS", *state_.estimated_observation_radius);
    // Deprecated alias kept for one release cycle so user pipelines that
    // still reference the old name keep working unchanged. A one-shot
    // warning is emitted at init (see initialize()) when the loaded YAML
    // still uses the legacy name.
    state_.parameter_source.updateVariable(
      "ESTIMATED_SENSOR_MAX_RANGE", *state_.estimated_observation_radius);
  }

  const double instRadius = state_.instantaneous_observation_radius
                              ? *state_.instantaneous_observation_radius
                              : 20.0 /*default, only used once*/;
  state_.parameter_source.updateVariable("INSTANTANEOUS_OBSERVATION_RADIUS", instRadius);
  // Deprecated alias, see comment above.
  state_.parameter_source.updateVariable("INSTANTANEOUS_SENSOR_MAX_RANGE", instRadius);

  if (state_.last_obs_timestamp && state_.first_ever_timestamp) {
    state_.parameter_source.updateVariable(
      "current_relative_timestamp",
      mrpt::system::timeDifference(*state_.first_ever_timestamp, *state_.last_obs_timestamp));
  }

  // Make all changes effective and evaluate the variables now:
  state_.parameter_source.realize();
}

void LidarOdometry::doUpdateAdaptiveThreshold()
{
  if (!state_.estimated_observation_radius.has_value()) {
    return;
  }

  // Initialization guard FIRST
  if (state_.adapt_thres_sigma == 0) {
    state_.adapt_thres_sigma = params_.adaptive_threshold.initial_sigma;
  }

  const double ALPHA = params_.adaptive_threshold.alpha;
  const double KP = params_.adaptive_threshold.kp;
  ASSERT_(KP > 0.0);  // any positive gain is valid

  // Additive P-controller: positive error → increase sigma
  const double error =
    params_.adaptive_threshold.icp_quality_controller_setpoint - state_.last_icp_quality;
  const double delta = std::clamp(
    KP * error, -params_.adaptive_threshold.max_sigma_step,
    params_.adaptive_threshold.max_sigma_step);
  const double new_sigma = state_.adapt_thres_sigma + delta;

  // EMA smoothing
  state_.adapt_thres_sigma = ALPHA * state_.adapt_thres_sigma + (1.0 - ALPHA) * new_sigma;

  // Hard bounds last
  mrpt::saturate(
    state_.adapt_thres_sigma, params_.adaptive_threshold.min_motion,
    params_.adaptive_threshold.maximum_sigma);

  MRPT_LOG_DEBUG_FMT(
    "delta: %+.4f ICP q=%.3f sigma=%.4f", delta, state_.last_icp_quality, state_.adapt_thres_sigma);
}

namespace
{
/** Radius of the observation, as either the bounding-box max-norm (the
 * historical behavior, `quantile` = 1) or a quantile of the per-point norms.
 *
 * The max-norm is set by a single point, so a stray far return decides the
 * scale of the whole scene; six shipped parameters are derived from this
 * number. The quantile path samples with a stride instead of reading every
 * point: it needs the shape of the distribution, not all of it.
 */
/** The quantile path only. The default (`quantile` = 1) is deliberately NOT
 * routed through here: see the call sites.
 */
double observationRadiusQuantile(
  const mrpt::maps::CPointsMap & pts, double quantile, uint32_t maxSamples)
{
  const auto bb = pts.boundingBox();
  const double maxNorm = std::max(bb.max.norm(), bb.min.norm());

  const auto & xs = pts.getPointsBufferRef_x();
  const auto & ys = pts.getPointsBufferRef_y();
  const auto & zs = pts.getPointsBufferRef_z();
  const size_t n = xs.size();
  if (n < 2) {
    return maxNorm;
  }

  const size_t stride = std::max<size_t>(1, n / std::max<uint32_t>(1, maxSamples));
  std::vector<double> norms;
  norms.reserve(n / stride + 1);
  for (size_t i = 0; i < n; i += stride) {
    const double r2 = static_cast<double>(xs[i]) * xs[i] + static_cast<double>(ys[i]) * ys[i] +
                      static_cast<double>(zs[i]) * zs[i];
    if (std::isfinite(r2)) {
      norms.push_back(std::sqrt(r2));
    }
  }
  if (norms.empty()) {
    return maxNorm;
  }

  const size_t k =
    std::min(norms.size() - 1, static_cast<size_t>(quantile * (norms.size() - 1) + 0.5));
  std::nth_element(norms.begin(), norms.begin() + k, norms.end());
  return norms[k];
}
}  // namespace

void LidarOdometry::doInitializeEstimatedObservationRadius(const mrpt::obs::CObservation & o)
{
  auto & maxRange = state_.estimated_observation_radius;
  ASSERT_(!maxRange.has_value());  // this method is for 1st call only

  mp2p_icp_filters::Generator gen;
  gen.params.target_layer = "raw";
  gen.initialize({});

  mp2p_icp::metric_map_t map;
  gen.process(o, map);

  auto pts = map.point_layer("raw");

  if (pts->empty()) {
    return;
  }

  // The default keeps the original expression, in its original place: moving
  // it into a function changes its inlining context, and a last-ULP
  // difference in R is enough to flip one point across a range threshold on
  // a pipeline this sensitive to its input. Measured: routing the default
  // through the helper changed the trajectory on 2 of 14 sequences.
  const auto bb = pts->boundingBox();

  double radius = params_.observation_radius_quantile >= 1.0
                    ? std::max(bb.max.norm(), bb.min.norm())
                    : observationRadiusQuantile(
                        *pts, params_.observation_radius_quantile,
                        params_.observation_radius_quantile_max_samples);

  // check for NaN, Infinities, etc.: See: https://github.com/MOLAorg/mola_lidar_odometry/issues/10
  if (!std::isnormal(radius)) {
    MRPT_LOG_WARN_STREAM(
      "NaN bounding box for observation point cloud. Using default observation radius.");
    radius = params_.absolute_minimum_observation_radius;
  } else {
    mrpt::keep_max(radius, params_.absolute_minimum_observation_radius);
  }

  maxRange = radius;

  MRPT_LOG_DEBUG_STREAM(
    "Estimated observation radius=" << *state_.estimated_observation_radius
                                    << " (instantaneous=" << radius << ")");
}

void LidarOdometry::doUpdateEstimatedObservationRadius(const mp2p_icp::metric_map_t & m)
{
  const double ALPHA = params_.observation_radius_filter_coefficient;

  auto & maxRange = state_.estimated_observation_radius;
  ASSERT_(maxRange.has_value());  // this method is for subsequent calls only

  for (const auto & [layerName, layer] : m.layers) {
    auto pts = std::dynamic_pointer_cast<mrpt::maps::CPointsMap>(layer);
    if (!pts || pts->empty()) {
      continue;
    }

    const auto bb = pts->boundingBox();
    if (!isNormalPoint(bb.min) || !isNormalPoint(bb.max)) {
      continue;  // skip NaN, INF, etc.
    }

    // The default keeps the original expression, in its original place: moving
    // it into a function changes its inlining context, and a last-ULP
    // difference in R is enough to flip one point across a range threshold on
    // a pipeline this sensitive to its input. Measured: routing the default
    // through the helper changed the trajectory on 2 of 14 sequences.
    double radius = params_.observation_radius_quantile >= 1.0
                      ? std::max(bb.max.norm(), bb.min.norm())
                      : observationRadiusQuantile(
                          *pts, params_.observation_radius_quantile,
                          params_.observation_radius_quantile_max_samples);

    mrpt::keep_max(radius, params_.absolute_minimum_observation_radius);

    state_.instantaneous_observation_radius = radius;

    // low-pass filter update:
    maxRange = (maxRange.value() * ALPHA) + (radius * (1.0 - ALPHA));

    MRPT_LOG_DEBUG_STREAM(
      "Estimated observation radius=" << *state_.estimated_observation_radius
                                      << " (instantaneous=" << radius << ")");

    // one layer is enough:
    return;
  }
  MRPT_LOG_DEBUG(
    "Estimated observation radius could NOT be updated, no points layer "
    "found in observation metric_map_t");
}

void LidarOdometry::updatePipelineTwistVariables(const mrpt::math::TTwist3D & tw)
{
  auto lckImu = mrpt::lockHelper(imu_state_mtx_);

  state_.parameter_source.updateVariable("vx", tw.vx);
  state_.parameter_source.updateVariable("vy", tw.vy);
  state_.parameter_source.updateVariable("vz", tw.vz);
  state_.parameter_source.updateVariable("wx", tw.wx);
  state_.parameter_source.updateVariable("wy", tw.wy);
  state_.parameter_source.updateVariable("wz", tw.wz);
}

}  // namespace mola
